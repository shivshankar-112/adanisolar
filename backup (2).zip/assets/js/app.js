// App.js - RevenueLink CRM
const router = require('express').Router();
const fs = require('fs');
const path = require('path');

const BASE_URL = process.env.BASE_URL || '/';

// Helper for proper URL handling
function url($path) {
    if (!path) return '';
    if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
    return BASE_URL + path;
}

// Helper functions for domain separation
function paymentUrl($path) { return BASE_URL + $path; }
function invoiceUrl($path) { return BASE_URL + $path; }
function portalUrl($path) { return BASE_URL + '/portal' + $path; }

// Error handling middleware
router.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        status: 'error',
        message: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message
    });
});

// 404 handling
router.use((req, res, next) => {
    res.status(404).json({
        status: 'error',
        message: 'Not found'
    });
});

module.exports = router;
