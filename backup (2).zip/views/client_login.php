<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Portal Login - <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        :root {
            --primary-orange: #F36D21;
            --primary-orange-dark: #E05A10;
            --dark-navy: #0B1120;
            --dark-navy-light: #112240;
            --card-bg: #13203A;
            --card-bg-hover: #1A2D50;
            --white: #ffffff;
            --gray-text: #a3a6ab;
            --gray-body: #cbd5e1;
            --gradient-orange: linear-gradient(135deg, #F38621 0%, #F36D21 100%);
            --gradient-dark: linear-gradient(180deg, #0B1120 0%, #112240 100%);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --radius-md: 12px;
            --radius-lg: 16px;
        }

        *, *::before, *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--gradient-dark);
            background-attachment: fixed;
            min-height: 100vh;
            overflow-x: hidden;
        }

        .auth-page {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            position: relative;
            overflow: hidden;
        }

        .auth-bg {
            position: absolute;
            inset: 0;
            z-index: 0;
            background: radial-gradient(circle at 20% 30%, rgba(243,109,33,0.15) 0%, transparent 40%),
                        radial-gradient(circle at 80% 70%, rgba(243,109,33,0.1) 0%, transparent 40%);
        }

        .auth-content {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 440px;
        }

        .auth-card {
            background: var(--card-bg);
            border: 1px solid rgba(243,109,33,0.15);
            border-radius: var(--radius-lg);
            padding: 48px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.4);
            position: relative;
            overflow: hidden;
        }

        .auth-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: var(--gradient-orange);
        }

        .auth-header {
            text-align: center;
            margin-bottom: 32px;
        }

        .auth-logo {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 16px;
        }

        .auth-logo-icon {
            width: 48px;
            height: 48px;
            background: var(--gradient-orange);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: var(--white);
            font-weight: 800;
            font-family: 'Montserrat', sans-serif;
        }

        .auth-logo-text {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 24px;
            color: var(--white);
            line-height: 1.2;
        }

        .auth-logo-text span { color: var(--primary-orange); }

        .auth-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 28px;
            font-weight: 800;
            color: var(--white);
            margin-bottom: 8px;
        }

        .auth-subtitle {
            font-size: 15px;
            color: var(--gray-text);
            margin-bottom: 4px;
        }

        .auth-divider {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 24px 0;
        }

        .auth-divider-line {
            flex: 1;
            height: 1px;
            background: rgba(255,255,255,0.08);
        }

        .auth-divider-text {
            font-size: 11px;
            color: var(--gray-text);
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 600;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            font-size: 11px;
            font-weight: 700;
            color: var(--gray-text);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 8px;
            display: block;
        }

        .form-input {
            width: 100%;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: var(--radius-md);
            padding: 14px 18px;
            color: var(--white);
            font-family: 'Poppins', sans-serif;
            font-size: 15px;
            outline: none;
            transition: var(--transition);
        }

        .form-input:focus {
            border-color: var(--primary-orange);
            box-shadow: 0 0 0 3px rgba(243,109,33,0.15);
        }

        .form-input::placeholder {
            color: rgba(255,255,255,0.3);
        }

        .form-row {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-bottom: 24px;
        }

        .form-checkbox {
            width: 18px;
            height: 18px;
            accent-color: var(--primary-orange);
            cursor: pointer;
        }

        .form-checkbox-label {
            font-size: 14px;
            color: var(--gray-body);
            cursor: pointer;
        }

        .btn-primary {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            width: 100%;
            padding: 14px 28px;
            border-radius: var(--radius-md);
            background: var(--gradient-orange);
            color: var(--white);
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
            font-size: 15px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: var(--transition);
            box-shadow: 0 4px 15px rgba(243,109,33,0.3);
        }

        .btn-primary:hover {
            background: var(--primary-orange-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(243,109,33,0.4);
        }

        .btn-primary:active {
            transform: translateY(0);
        }

        .error-text {
            font-size: 13px;
            color: #f87171;
            margin-bottom: 16px;
            text-align: center;
            font-weight: 500;
        }

        .auth-footer {
            text-align: center;
            margin-top: 32px;
            padding-top: 24px;
            border-top: 1px solid rgba(255,255,255,0.08);
        }

        .auth-footer-text {
            font-size: 14px;
            color: var(--gray-text);
        }

        .auth-footer-link {
            color: var(--primary-orange);
            text-decoration: none;
            font-weight: 600;
            transition: var(--transition);
        }

        .auth-footer-link:hover {
            color: #FF8C42;
            text-decoration: underline;
        }

        @media (max-width: 480px) {
            .auth-card {
                padding: 36px 24px;
            }
            .auth-title {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>
    <div class="auth-page">
        <div class="auth-bg"></div>
        <div class="auth-content">
            <div class="auth-card">
                <div class="auth-header">
                    <div class="auth-logo">
                        <?php if (!empty($settings['logo_url'])): ?>
                            <img src="<?= url($settings['logo_url']) ?>" alt="Logo" class="h-8 w-8 object-contain" style="max-height: 40px;" />
                        <?php else: ?>
                            <div class="auth-logo-icon">☀</div>
                            <div class="auth-logo-text">Bright<span>Future</span>Solar</div>
                        <?php endif; ?>
                    </div>
                    <h1 class="auth-title">Client Portal</h1>
                    <p class="auth-subtitle">Sign in to access your approvals and invoices</p>
                </div>

                <div class="auth-divider">
                    <div class="auth-divider-line"></div>
                    <div class="auth-divider-text">Login</div>
                    <div class="auth-divider-line"></div>
                </div>

                <form @submit.prevent="login()" class="space-y-4">
                    <div class="form-group">
                        <label class="form-label">Email Address</label>
                        <input type="email" x-model="email" class="form-input" required placeholder="john@example.com">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Password</label>
                        <input type="password" x-model="password" class="form-input" required placeholder="••••••••">
                    </div>

                    <div class="form-row">
                        <input type="checkbox" x-model="remember" id="remember" class="form-checkbox">
                        <label for="remember" class="form-checkbox-label">Remember me</label>
                    </div>

                    <template x-if="error">
                        <p class="error-text" x-text="error"></p>
                    </template>

                    <button type="submit" class="btn-primary">
                        <span>Sign In</span>
                    </button>
                </form>

                <div class="auth-footer">
                    <p class="auth-footer-text">Don't have an account? <a href="/register" class="auth-footer-link">Register here</a></p>
                    <p class="auth-footer-text mt-3"><a href="<?= url('/') ?>" class="auth-footer-link">&larr; Back to Home</a></p>
                </div>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('alpine:init', () => {
        Alpine.data('loginPage', () => ({
            email: '',
            password: '',
            remember: false,
            error: '',
            async login() {
                this.error = '';
                const res = await fetch(url('/login'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ 
                        email: this.email, 
                        password: this.password,
                        remember: this.remember
                    })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    window.location.href = url('/portal/dashboard');
                } else {
                    this.error = data.message || 'Login failed';
                }
            }
        }))
    })
    </script>
</body>
</html>