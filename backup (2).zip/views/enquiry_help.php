<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Embed Enquiry Form - <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?></title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24); }
    </style>
</head>
<body class="text-gray-800">

<div class="min-h-screen flex flex-col">

    <?php 
    $activePage = 'enquiries';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <main class="flex-grow p-8 max-w-4xl mx-auto w-full space-y-12">
        <header class="space-y-2">
            <h1 class="text-3xl font-bold text-gray-900">Capture Leads Anywhere</h1>
            <p class="text-gray-500">Copy the snippet below to embed a professional enquiry form on your marketing website.</p>
        </header>

        <section class="space-y-4">
            <h2 class="text-xl font-bold flex items-center">
                <span class="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center mr-3 text-sm">1</span>
                The Integration Code
            </h2>
            <div class="bg-gray-900 text-gray-300 p-6 rounded-xl overflow-x-auto shadow-2xl relative group">
                <button onclick="copyCode()" class="absolute top-4 right-4 bg-gray-800 hover:bg-gray-700 text-white text-[10px] font-bold py-1 px-3 rounded border border-gray-600 transition opacity-0 group-hover:opacity-100">Copy Code</button>
<pre><code id="embed-code">&lt;!-- dadmin Enquiry Form --&gt;
&lt;div id="dadmin-enquiry-container"&gt;&lt;/div&gt;

&lt;script&gt;
(function() {
    const CONFIG = {
        api_url: '<?php echo url('/api/enquiry'); ?>',
        primary_color: '#1a73e8',
        success_message: 'Thank you! Your enquiry has been received.'
    };

    const container = document.getElementById('dadmin-enquiry-container');
    container.innerHTML = `
        &lt;form id="dadmin-form" style="max-width: 600px; padding: 30px; border: 1px solid #e0e0e0; border-radius: 12px; background: #fff; font-family: 'Google Sans', sans-serif; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1);"&gt;
            &lt;h3 style="margin-top: 0; margin-bottom: 25px; color: #1a1a1a; font-size: 20px; border-bottom: 2px solid #f0f0f0; padding-bottom: 10px;"&gt;Request a Quote&lt;/h3&gt;
            
            &lt;div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;"&gt;
                &lt;div&gt;
                    &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Your Name *&lt;/label&gt;
                    &lt;input type="text" name="client_name" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;"&gt;
                &lt;/div&gt;
                &lt;div&gt;
                    &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Email ID: *&lt;/label&gt;
                    &lt;input type="email" name="email" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;"&gt;
                &lt;/div&gt;
            &lt;/div&gt;

            &lt;div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;"&gt;
                &lt;div&gt;
                    &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Phone Number:&lt;/label&gt;
                    &lt;input type="text" name="phone" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;"&gt;
                &lt;/div&gt;
                &lt;div&gt;
                    &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Select Service: *&lt;/label&gt;
                    &lt;select name="service" required style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; background: white;"&gt;
                        &lt;option value=""&gt;Select Service&lt;/option&gt;
                        &lt;option value="Web Design"&gt;Web Design&lt;/option&gt;
                        &lt;option value="App Development"&gt;App Development&lt;/option&gt;
                        &lt;option value="Marketing"&gt;Digital Marketing&lt;/option&gt;
                    &lt;/select&gt;
                &lt;/div&gt;
            &lt;/div&gt;

            &lt;div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;"&gt;
                &lt;div&gt;
                    &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Budget:&lt;/label&gt;
                    &lt;input type="text" name="budget" placeholder="e.g. ₹50,000" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;"&gt;
                &lt;/div&gt;
                &lt;div&gt;
                    &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;State:&lt;/label&gt;
                    &lt;input type="text" name="state" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;"&gt;
                &lt;/div&gt;
            &lt;/div&gt;

            &lt;div style="margin-bottom: 15px;"&gt;
                &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Address:&lt;/label&gt;
                &lt;input type="text" name="address" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box;"&gt;
            &lt;/div&gt;

            &lt;div style="margin-bottom: 20px;"&gt;
                &lt;label style="display:block; font-size: 11px; font-weight: bold; text-transform: uppercase; margin-bottom: 5px; color: #777;"&gt;Message:&lt;/label&gt;
                &lt;textarea name="message" rows="3" style="width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 6px; box-sizing: border-box; resize: vertical;"&gt;&lt;/textarea&gt;
            &lt;/div&gt;

            &lt;button type="submit" id="dadmin-submit" style="width: 100%; padding: 14px; background: ${CONFIG.primary_color}; color: #fff; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 15px; transition: opacity 0.2s;"&gt;Submit Enquiry&lt;/button&gt;
            &lt;div id="dadmin-status" style="margin-top: 15px; font-size: 13px; text-align: center; display: none; padding: 10px; border-radius: 6px;"&gt;&lt;/div&gt;
        &lt;/form&gt;
    `;

    const form = document.getElementById('dadmin-form');
    const status = document.getElementById('dadmin-status');
    const btn = document.getElementById('dadmin-submit');

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        btn.disabled = true;
        btn.style.opacity = '0.7';
        btn.innerText = 'Sending...';
        status.style.display = 'none';

        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());

        try {
            const response = await fetch(CONFIG.api_url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            const result = await response.json();
            
            if (result.status === 'success') {
                form.reset();
                status.innerText = CONFIG.success_message;
                status.style.color = '#155724';
                status.style.background = '#d4edda';
                status.style.border = '1px solid #c3e6cb';
            } else {
                status.innerText = result.message || 'Error sending enquiry.';
                status.style.color = '#721c24';
                status.style.background = '#f8d7da';
                status.style.border = '1px solid #f5c6cb';
            }
        } catch (err) {
            status.innerText = 'Connection error. Please try again.';
            status.style.color = '#721c24';
            status.style.background = '#f8d7da';
        } finally {
            status.style.display = 'block';
            btn.disabled = false;
            btn.style.opacity = '1';
            btn.innerText = 'Submit Enquiry';
        }
    });
})();
&lt;/script&gt;</code></pre>
            </div>
        </section>

        <section class="space-y-4">
            <h2 class="text-xl font-bold flex items-center">
                <span class="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center mr-3 text-sm">2</span>
                Field Mapping Reference
            </h2>
            <div class="card overflow-hidden">
                <table class="w-full text-left text-sm">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-6 py-3 text-gray-500 font-bold uppercase tracking-wider">Form Label</th>
                            <th class="px-6 py-3 text-gray-500 font-bold uppercase tracking-wider">Mapped Admin Field</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <tr><td class="px-6 py-4">Your Name</td><td class="px-6 py-4 font-medium">Client Name</td></tr>
                        <tr><td class="px-6 py-4">Email ID:</td><td class="px-6 py-4 font-medium">Email Address</td></tr>
                        <tr><td class="px-6 py-4">Phone Number:</td><td class="px-6 py-4 font-medium">Phone Number</td></tr>
                        <tr><td class="px-6 py-4">Select Service:</td><td class="px-6 py-4 font-medium">Service</td></tr>
                        <tr><td class="px-6 py-4">Budget:</td><td class="px-6 py-4 font-medium">Budget Range</td></tr>
                        <tr><td class="px-6 py-4">Address:</td><td class="px-6 py-4 font-medium">Full Address</td></tr>
                        <tr><td class="px-6 py-4">State:</td><td class="px-6 py-4 font-medium">State/Province</td></tr>
                        <tr><td class="px-6 py-4">Message:</td><td class="px-6 py-4 font-medium">Detailed Message</td></tr>
                    </tbody>
                </table>
            </div>
        </section>
    </main>

    <?php include __DIR__ . '/partials/footer.php'; ?>
</div>

<script>
function copyCode() {
    const code = document.getElementById('embed-code').innerText;
    navigator.clipboard.writeText(code);
    alert('Code copied to clipboard!');
}
</script>

</body>
</html>
