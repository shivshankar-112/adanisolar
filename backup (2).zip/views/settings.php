<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link rel="stylesheet" href="<?= url('/assets/css/jodit.min.css') ?>"/>
    <script src="<?= url('/assets/js/jodit.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .tab-active { color: #1a73e8; border-bottom: 2px solid #1a73e8; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
        .jodit-container { border-radius: 8px !important; border: 1px solid #e5e7eb !important; }
        .jodit-wysiwyg b, .jodit-wysiwyg strong { font-weight: bold !important; }
        .jodit-wysiwyg i, .jodit-wysiwyg em { font-style: italic !important; }
        .jodit-wysiwyg u { text-decoration: underline !important; }
        .jodit-wysiwyg h1 { font-size: 2em !important; font-weight: bold !important; margin-bottom: 0.5em !important; }
        .jodit-wysiwyg h2 { font-size: 1.5em !important; font-weight: bold !important; margin-bottom: 0.5em !important; }
        .jodit-wysiwyg h3 { font-size: 1.17em !important; font-weight: bold !important; margin-bottom: 0.5em !important; }
        .jodit-wysiwyg ul { list-style-type: disc !important; padding-left: 40px !important; }
        .jodit-wysiwyg ol { list-style-type: decimal !important; padding-left: 40px !important; }
        .jodit-wysiwyg p { margin-bottom: 1em !important; }
        .jodit-wysiwyg table { border-collapse: collapse !important; width: 100% !important; border: 1px solid #ccc !important; }
        .jodit-wysiwyg table td, .jodit-wysiwyg table th { border: 1px solid #ccc !important; padding: 5px !important; }
        .custom-scrollbar::-webkit-scrollbar { height: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f1f1f1; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="settingsPage" class="min-h-screen flex flex-col">

    <?php 
    $activePage = 'settings';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <!-- Responsive Top Bar -->
    <div class="bg-white border-b px-4 py-3 flex flex-col sm:flex-row items-center justify-between space-y-3 sm:space-y-0 sticky top-0 z-30 shadow-sm">
        <div class="flex items-center space-x-2 self-start sm:self-auto">
           <h1 class="text-xl md:text-2xl tracking-tight">Organization Settings</h1>
        </div>
        <div class="flex items-center space-x-4 w-full sm:w-auto justify-between sm:justify-end">
            <a href="/settings/backup" class="text-xs text-blue-600 hover:underline flex items-center">
                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Backup
            </a>
            <button type="button" @click="saveSettings()" class="btn-google text-sm py-2 px-4 md:px-6 shadow-lg shadow-blue-100 transform active:scale-95 transition">Save Changes</button>
        </div>
    </div>

    <main class="flex-grow p-4 md:p-8 w-full mx-auto max-w-full">

        <div class="flex border-b mb-8 space-x-8 overflow-x-auto custom-scrollbar pb-1">
            <button type="button" @click="activeTab = 'details'" :class="{'tab-active': activeTab === 'details'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Org Details</button>
            <button type="button" @click="activeTab = 'services'" :class="{'tab-active': activeTab === 'services'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Services</button>
            <button type="button" @click="activeTab = 'budgets'" :class="{'tab-active': activeTab === 'budgets'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Budgets</button>
            <button type="button" @click="activeTab = 'banks'" :class="{'tab-active': activeTab === 'banks'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Bank Accounts</button>
            <button type="button" @click="activeTab = 'formats'" :class="{'tab-active': activeTab === 'formats'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Number Formats</button>
            <button type="button" @click="activeTab = 'smtp'" :class="{'tab-active': activeTab === 'smtp'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">SMTP Config</button>
            <button type="button" @click="activeTab = 'templates'" :class="{'tab-active': activeTab === 'templates'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Email Templates</button>
            <button type="button" @click="activeTab = 'approval_templates'" :class="{'tab-active': activeTab === 'approval_templates'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Approval Templates</button>
            <button type="button" @click="activeTab = 'logs'; fetchLogs()" :class="{'tab-active': activeTab === 'logs'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Activity Logs</button>
            <button type="button" @click="activeTab = 'email_logs'; fetchEmailLogs()" :class="{'tab-active': activeTab === 'email_logs'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Email Logs</button>
            <button type="button" @click="activeTab = 'changelog'" :class="{'tab-active': activeTab === 'changelog'}" class="pb-3 px-1 text-sm font-medium text-gray-500 hover:text-gray-700 transition whitespace-nowrap">Changelog</button>
            <button type="button" @click="activeTab = 'cleanup'" :class="{'tab-active': activeTab === 'cleanup'}" class="pb-3 px-1 text-sm font-medium text-red-600 hover:text-red-800 transition whitespace-nowrap">DB Cleanup</button>
        </div>

        <!-- Details Tab -->
        <div x-show="activeTab === 'details'" class="card p-6 space-y-6">
            <div class="flex items-center space-x-8 pb-6 border-b">
                <div class="relative group">
                    <img :src="url(settings.logo_url) || url('/assets/img/placeholder.svg')" class="w-24 h-24 rounded-lg object-contain border bg-gray-50">
                    <label class="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 text-white text-xs opacity-0 group-hover:opacity-100 cursor-pointer rounded-lg transition">Change Logo<input type="file" @change="uploadLogo" class="hidden" accept="image/*"></label>
                </div>
                <div><h3 class="font-medium text-lg">Organization Branding</h3><p class="text-sm text-gray-500">Upload your logo to personalize emails and the dashboard.</p></div>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Organization Name</label><input type="text" x-model="settings.org_name" class="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"></div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Website URL</label><input type="url" x-model="settings.website_url" class="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"></div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Email Address</label><input type="email" x-model="settings.email" class="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"></div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Phone Number</label><input type="text" x-model="settings.phone" class="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"></div>
                <div class="space-y-1">
                    <label class="text-sm font-medium text-gray-600 flex items-center">
                        <input type="checkbox" x-model="settings.hide_invoice_until_payment" class="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                        <span class="ml-2">Don't show Invoice to clients until payment is done</span>
                    </label>
                    <p class="text-xs text-gray-400 mt-1">When enabled, clients will only see invoices that have at least one payment recorded.</p>
                </div>
            </div>
        </div>

        <!-- Services Tab -->
        <div x-show="activeTab === 'services'" class="space-y-6">
            <div class="flex justify-between items-center"><h2 class="text-lg font-medium">Manage Services</h2><button type="button" @click="addService()" class="btn-google">+ Add Service</button></div>
            <div class="grid grid-cols-1 gap-6">
                <template x-for="service in settings.services" :key="service.id">
                    <div class="card p-6 relative group">
                        <button type="button" @click="removeService(service.id)" class="absolute top-4 right-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase tracking-wider">Service Name</label><input type="text" x-model="service.name" class="w-full border-b border-gray-200 focus:border-blue-600 outline-none py-1 font-medium bg-transparent"></div>
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase tracking-wider">Short Description</label><input type="text" x-model="service.description" class="w-full border-b border-gray-200 focus:border-blue-600 outline-none py-1 text-sm text-gray-600 bg-transparent"></div>
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase tracking-wider">Price (₹)</label><input type="number" x-model="service.price" class="w-full border-b border-gray-200 focus:border-blue-600 outline-none py-1 font-medium text-right bg-transparent"></div>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <!-- Budgets Tab -->
        <div x-show="activeTab === 'budgets'" class="space-y-6">
            <div class="flex justify-between items-center"><h2 class="text-lg font-medium">Budget Ranges</h2><button type="button" @click="addBudget()" class="btn-google">+ Add Range</button></div>
            <div class="grid grid-cols-1 gap-6">
                <template x-for="budget in settings.budgets" :key="budget.id">
                    <div class="card p-6 relative group">
                        <button type="button" @click="removeBudget(budget.id)" class="absolute top-4 right-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase tracking-wider">Label (e.g. Premium)</label><input type="text" x-model="budget.name" class="w-full border-b border-gray-200 focus:border-blue-600 outline-none py-1 font-medium bg-transparent"></div>
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase tracking-wider">Price Range (e.g. ₹50k+)</label><input type="text" x-model="budget.range" class="w-full border-b border-gray-200 focus:border-blue-600 outline-none py-1 text-sm text-gray-600 bg-transparent"></div>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <!-- Banks Tab -->
        <div x-show="activeTab === 'banks'" class="space-y-6">
            <div class="flex justify-between items-center"><h2 class="text-lg font-medium">Bank Accounts</h2><button type="button" @click="addBank()" class="btn-google">+ Add Account</button></div>
            <div class="grid grid-cols-1 gap-6">
                <template x-for="bank in settings.bank_accounts" :key="bank.id">
                    <div class="card p-6 relative group">
                        <button type="button" @click="removeBank(bank.id)" class="absolute top-4 right-4 text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase">Account Name</label><input type="text" x-model="bank.account_name" class="w-full border-b focus:border-blue-600 outline-none py-1 font-medium"></div>
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase">Account Number</label><input type="text" x-model="bank.account_no" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm text-gray-600"></div>
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase">IFSC Code</label><input type="text" x-model="bank.ifsc" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm text-gray-600 uppercase"></div>
                            <div class="space-y-1"><label class="text-xs font-medium text-gray-500 uppercase">Branch Details</label><input type="text" x-model="bank.branch" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm text-gray-600"></div>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <!-- Formats Tab -->
        <div x-show="activeTab === 'formats'" class="card p-6 space-y-8">
            <template x-for="(label, key) in {enquiry: 'Enquiry', approval: 'Approval', invoice: 'Invoice', payment: 'Payment'}">
                <div class="border-b pb-6 last:border-0 last:pb-0">
                    <h3 class="font-medium text-lg mb-4" x-text="label + ' Number Format'"></h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Prefix</label><input type="text" x-model="settings[key + '_format'].prefix" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                        <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Starting Number</label><input type="number" x-model="settings[key + '_format'].start" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                        <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Strategy</label><select x-model="settings[key + '_format'].type" class="w-full border rounded-md px-3 py-2 outline-none"><option value="sequential">Sequential</option><option value="random">Random Number</option></select></div>
                    </div>
                    <div class="mt-4 text-sm text-gray-500 italic">Preview: <span class="font-bold text-blue-600" x-text="settings[key + '_format'].prefix + settings[key + '_format'].start"></span></div>
                </div>
            </template>
        </div>

        <!-- SMTP Tab -->
        <div x-show="activeTab === 'smtp'" class="card p-6 space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">SMTP Host</label><input type="text" x-model="settings.smtp.host" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">SMTP Port</label><input type="number" x-model="settings.smtp.port" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Username</label><input type="text" x-model="settings.smtp.user" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Password</label><input type="password" x-model="settings.smtp.pass" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                <div class="space-y-1">
                    <label class="text-sm font-medium text-gray-600">Encryption</label>
                    <select x-model="settings.smtp.encryption" class="w-full border rounded-md px-3 py-2 outline-none">
                        <option value="tls">TLS (Recommended)</option>
                        <option value="ssl">SSL</option>
                        <option value="none">None</option>
                    </select>
                </div>
                <div class="space-y-1"><label class="text-sm font-medium text-gray-600">From Email</label><input type="email" x-model="settings.smtp.from_email" placeholder="e.g. info@yourcompany.com" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                <div class="space-y-1 md:col-span-2"><label class="text-sm font-medium text-gray-600">Sender Name</label><input type="text" x-model="settings.smtp.from_name" placeholder="e.g. iAdmin Support" class="w-full border rounded-md px-3 py-2 outline-none"></div>
            </div>
            <div class="flex flex-col sm:flex-row items-center gap-3">
                <button type="button" @click="saveSettings()" class="w-full sm:w-auto bg-blue-600 text-white px-8 py-2 rounded font-bold hover:bg-blue-700 transition shadow-lg">Save Configuration</button>
                <button type="button" @click="testSmtpModal = true" class="w-full sm:w-auto bg-white border border-gray-300 text-gray-700 px-8 py-2 rounded font-bold hover:bg-gray-50 transition shadow-sm">Test SMTP</button>
            </div>
        </div>

        <!-- Approval Templates Tab -->
        <div x-show="activeTab === 'approval_templates'" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div class="card p-4 space-y-2 col-span-1 h-fit">
                    <div class="flex justify-between items-center mb-4"><h2 class="font-medium">Templates</h2><button type="button" @click="addApprovalTemplate()" class="text-blue-600 hover:text-blue-800"><svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg></button></div>
                    <template x-for="tpl in settings.approval_templates" :key="tpl.id">
                        <div class="group flex items-center justify-between px-3 py-2 rounded-md transition cursor-pointer" :class="selectedTpl?.id === tpl.id ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50 text-gray-700'" @click="selectTemplate(tpl)">
                            <span class="text-sm font-medium flex-grow truncate" x-text="tpl.name"></span>
                            <button type="button" @click.stop="removeApprovalTemplate(tpl.id)" class="text-red-400 hover:text-red-600 opacity-0 group-hover:opacity-100 ml-2"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                        </div>
                    </template>
                </div>
                <div class="col-span-3 space-y-6">
                    <template x-if="selectedTpl">
                        <div class="space-y-6">
                            <div class="card p-6 space-y-4">
                                <div class="flex justify-between items-center"><div class="space-y-1 flex-grow mr-4"><label class="text-xs font-medium text-gray-500 uppercase">Template Name</label><input type="text" x-model="selectedTpl.name" class="w-full border-b focus:border-blue-600 outline-none py-1 font-medium"></div><div class="flex items-center space-x-2"><label class="text-xs font-medium text-gray-500 uppercase">Default Template</label><button type="button" @click="setDefaultTemplate(selectedTpl.id)" class="relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none" :class="selectedTpl.is_default ? 'bg-blue-600' : 'bg-gray-200'"><span :class="selectedTpl.is_default ? 'translate-x-6' : 'translate-x-1'" class="inline-block h-4 w-4 transform rounded-full bg-white transition-transform"></span></button></div></div>
                                <div class="flex flex-col xl:flex-row gap-6">
                                    <div class="flex-grow space-y-1 min-w-0">
                                        <div class="flex justify-between items-end mb-1">
                                            <label class="text-xs font-medium text-gray-500 uppercase">Content Editor</label>
                                            <span class="text-[10px] text-gray-400 hidden sm:inline">A4 Standard Visualization</span>
                                        </div>
                                        <div class="border rounded-md bg-gray-100 p-2 sm:p-4 md:p-8 overflow-x-auto custom-scrollbar">
                                            <div class="min-w-[800px] xl:min-w-0 mx-auto">
                                                <textarea id="approval-editor"></textarea>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="w-full xl:w-48 shrink-0 space-y-3">
                                        <label class="text-xs font-medium text-gray-500 uppercase">Shortcodes</label>
                                        <div class="grid grid-cols-2 xl:grid-cols-1 gap-1.5">
                                            <template x-for="code in ['{{client_name}}', '{{email}}', '{{phone}}', '{{address}}', '{{state}}', '{{service}}', '{{budget}}', '{{approval_no}}', '{{amount}}', '{{date}}', '{{org_name}}', '{{org_website}}', '{{org_email}}', '{{org_phone}}', '{{org_logo}}', '{{client_photo}}', '{{items}}']">
                                                <button type="button" @click="insertShortcode(code)" class="text-[10px] bg-gray-50 hover:bg-blue-100 hover:text-blue-700 px-2 py-1.5 rounded border transition text-left truncate" x-text="code"></button>
                                            </template>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="card p-6 space-y-4">
                                    <h3 class="text-xs font-medium text-gray-500 uppercase">Page Graphics</h3>
                                    <div class="space-y-3">
                                        <template x-for="key in ['bg_graphic', 'header_graphic', 'footer_graphic']">
                                            <div><label class="block text-[11px] text-gray-500 mb-1" x-text="key.replace('_', ' ').toUpperCase()"></label><div class="flex items-center space-x-2"><input type="text" x-model="selectedTpl[key]" class="flex-grow text-xs border rounded px-2 py-1 bg-gray-50" readonly><button x-show="selectedTpl[key]" @click="removeAsset(selectedTpl, key)" class="text-red-500 hover:text-red-700 p-1"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button><label class="cursor-pointer bg-blue-50 text-blue-600 px-3 py-1 rounded text-xs hover:bg-blue-100 transition">Upload<input type="file" @change="uploadAsset($event, (url) => selectedTpl[key] = url, selectedTpl[key])" class="hidden" accept="image/*"></label></div></div>
                                        </template>
                                    </div>
                                </div>
                                <div class="card p-6 space-y-4">
                                    <div class="flex justify-between items-center"><h3 class="text-xs font-medium text-gray-500 uppercase">Stamp & Signature</h3><button x-show="selectedTpl.stamp_sign" @click="removeAsset(selectedTpl, 'stamp_sign')" class="text-red-500 hover:text-red-700 text-xs flex items-center">Remove</button></div>
                                    <div class="border-2 border-dashed rounded-lg h-32 flex items-center justify-center relative overflow-hidden bg-gray-50"><template x-if="selectedTpl.stamp_sign"><img :src="url(selectedTpl.stamp_sign)" class="max-h-full object-contain"></template><template x-if="!selectedTpl.stamp_sign"><span class="text-xs text-gray-400">No Stamp/Sign Uploaded</span></template><label class="absolute inset-0 cursor-pointer flex items-center justify-center bg-black bg-opacity-0 hover:bg-opacity-10 transition"><input type="file" @change="uploadAsset($event, (url) => selectedTpl.stamp_sign = url, selectedTpl.stamp_sign)" class="hidden" accept="image/*"></label></div>
                                </div>
                            </div>
                        </div>
                    </template>
                    <template x-if="!selectedTpl"><div class="card h-64 flex items-center justify-center text-gray-400 italic">Select or create a template to begin editing</div></template>
                </div>
            </div>
        </div>

        <!-- Email Templates Tab -->
        <div x-show="activeTab === 'templates'" class="space-y-6">
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div class="card p-4 space-y-2 col-span-1">
                    <template x-for="tpl in settings.templates">
                        <button type="button" @click="selectedEmailTpl = tpl" :class="selectedEmailTpl?.id === tpl.id ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50 text-gray-700'" class="w-full text-left px-4 py-2 rounded-md text-sm font-medium transition" x-text="tpl.name"></button>
                    </template>
                </div>
                <div class="card p-6 col-span-2 space-y-4">
                    <template x-if="selectedEmailTpl">
                        <div class="space-y-4">
                            <h3 class="font-medium text-lg" x-text="'Edit: ' + selectedEmailTpl.name"></h3>
                            <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Subject Line</label><input type="text" x-model="selectedEmailTpl.subject" class="w-full border rounded-md px-3 py-2 outline-none"></div>
                            <div class="space-y-1"><label class="text-sm font-medium text-gray-600">Email Body</label><textarea x-model="selectedEmailTpl.body" rows="6" class="w-full border rounded-md px-3 py-2 outline-none"></textarea></div>
                            <p class="text-xs text-gray-500">Available variables: {{name}}, {{approval_no}}, {{invoice_no}}, {{amount}}</p>
                        </div>
                    </template>
                    <template x-if="!selectedEmailTpl"><div class="h-full flex items-center justify-center text-gray-400 italic">Select a template to edit</div></template>
                </div>
            </div>
        </div>

        <!-- Logs Tab -->
        <div x-show="activeTab === 'logs'" class="space-y-6">
            <div class="flex justify-between items-center">
                <h2 class="text-lg font-medium">Activity Logs</h2>
                <div class="flex items-center space-x-4"><button type="button" @click="clearLogs('audit')" class="text-red-600 hover:underline text-sm font-bold">Clear All Logs</button><button type="button" @click="fetchLogs()" class="text-blue-600 hover:underline text-sm">Refresh</button></div>
            </div>
            <div class="card overflow-hidden overflow-x-auto">
                <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Timestamp</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">User</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Action</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Collection</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Details</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <template x-for="log in logs" :key="log.id">
                            <tr class="hover:bg-gray-50 transition group text-sm md:text-base">
                                <td class="px-3 md:px-4 py-4 text-[10px] md:text-sm text-gray-500 whitespace-nowrap" x-text="log.timestamp"></td>
                                <td class="px-3 md:px-4 py-4 font-medium text-gray-900 whitespace-nowrap" x-text="log.username"></td>
                                <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                    <span class="px-3 py-1 rounded-full text-[10px] md:text-xs uppercase font-bold border" 
                                          :class="{'bg-green-100 text-green-700 border-green-200': log.action === 'create' || log.action === 'login',
                                                   'bg-blue-100 text-blue-700 border-blue-200': log.action === 'update',
                                                   'bg-red-100 text-red-700 border-red-200': log.action === 'delete' || log.action === 'login_failure'}" 
                                          x-text="log.action"></span>
                                </td>
                                <td class="px-3 md:px-4 py-4 text-xs md:text-sm text-gray-600 whitespace-nowrap" x-text="log.collection"></td>
                                <td class="px-3 md:px-4 py-4 text-xs md:text-sm text-gray-500 truncate max-w-[200px]" x-text="'ID: ' + log.record_id"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>

        <div x-show="activeTab === 'email_logs'" class="space-y-6">
            <div class="flex justify-between items-center">
                <h2 class="text-lg font-medium">Email History</h2>
                <div class="flex items-center space-x-4"><button type="button" @click="clearLogs('email')" class="text-red-600 hover:underline text-sm font-bold">Clear Email History</button><button type="button" @click="fetchEmailLogs()" class="text-blue-600 hover:underline text-sm">Refresh</button></div>
            </div>
            <div class="card overflow-hidden overflow-x-auto">
                <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Timestamp</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Recipient</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Subject</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Status</th>
                            <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Error</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <template x-for="log in emailLogs" :key="log.id">
                            <tr class="hover:bg-gray-50 transition group text-sm md:text-base">
                                <td class="px-3 md:px-4 py-4 text-[10px] md:text-sm text-gray-500 whitespace-nowrap" x-text="log.timestamp"></td>
                                <td class="px-3 md:px-4 py-4 font-medium text-gray-900 whitespace-nowrap" x-text="log.recipient"></td>
                                <td class="px-3 md:px-4 py-4 text-xs md:text-sm text-gray-600 truncate max-w-xs" x-text="log.subject"></td>
                                <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                    <span class="px-3 py-1 rounded-full text-[10px] md:text-xs font-bold border" 
                                          :class="log.status === 'sent' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-red-100 text-red-700 border-red-200'" 
                                          x-text="log.status"></span>
                                </td>
                                <td class="px-3 md:px-4 py-4 text-xs md:text-sm text-red-500 italic" x-text="log.error || '-'"></td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Changelog Tab -->
        <div x-show="activeTab === 'changelog'" class="space-y-6">
            <div class="card p-8">
                <div class="flex items-center justify-between mb-8 pb-4 border-b">
                    <div><h2 class="text-xl font-bold">System Changelog</h2><p class="text-sm text-gray-500">Track versions and feature updates for <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?> CRM.</p></div>
                    <div class="bg-blue-50 text-blue-700 px-4 py-1.5 rounded-full text-sm font-bold border border-blue-100 shadow-sm">Version 1.6.0 (Stable)</div>
                </div>
                <div class="space-y-12">
                    <!-- Version 1.5.1 -->
                    <div class="relative pl-8 border-l-2 border-blue-600">
                        <div class="absolute -left-[9px] top-0 w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-sm"></div>
                        <h3 class="text-lg font-bold mb-4 flex items-center">
                            v1.5.1 - Security & UI Fixes
                            <span class="ml-3 text-xs font-normal text-gray-400">June 18, 2026</span>
                        </h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <div class="text-xs font-bold text-red-600 uppercase tracking-widest mb-2">Security Fixes</div>
                                <ul class="text-sm text-gray-600 space-y-1.5 list-disc pl-4">
                                    <li>**Client Photo XSS Protection**: Added strict regex validation to prevent javascript:/data: URL injection.</li>
                                    <li>**Strong Default Passwords**: Replaced phone‑number‑based passwords with cryptographically strong random passwords (12‑char, uppercase/lowercase/numbers/special chars).</li>
                                </ul>
                            </div>
                            <div>
                                <div class="text-xs font-bold text-blue-600 uppercase tracking-widest mb-2">UI Improvements</div>
                                <ul class="text-sm text-gray-600 space-y-1.5 list-disc pl-4">
                                    <li>**Added Reset Button**: Staff filter section now includes a Reset button matching Clients and Enquiries pages.</li>
                                    <li>**Fixed Enquiry Modal Scroll**: Changed overflow to hidden to eliminate horizontal scroll bar in edit modal.</li>
</ul>
                             </div>
                         </div>
                     </div>

                     <!-- Version 1.6.0 -->
                     <div class="relative pl-8 border-l-2 border-blue-600">
                         <div class="absolute -left-[9px] top-0 w-4 h-4 bg-blue-600 rounded-full border-4 border-white shadow-sm"></div>
                         <h3 class="text-lg font-bold mb-4 flex items-center">
                             v1.6.0 - Template & Invoice Fixes
                             <span class="ml-3 text-xs font-normal text-gray-400">June 26, 2026</span>
                         </h3>
                         <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <div>
                                 <div class="text-xs font-bold text-blue-600 uppercase tracking-widest mb-2">Template Fixes</div>
                                 <ul class="text-sm text-gray-600 space-y-1.5 list-disc pl-4">
                                     <li>**Approval Shortcodes**: Added missing shortcodes (phone, address, state, budget, org_website, org_email, org_phone) to approval template rendering.</li>
                                     <li>**Professional Templates**: Updated approval and invoice templates with clean, consistent layout showing org details on right (Logo, Name, Phone, Email, Website).</li>
                                 </ul>
                             </div>
                             <div>
                                 <div class="text-xs font-bold text-green-600 uppercase tracking-widest mb-2">Invoice & Payment Fixes</div>
                                 <ul class="text-sm text-gray-600 space-y-1.5 list-disc pl-4">
                                     <li>**Payment Permission Fix**: Fixed PaymentController permission check (`can` → `check`) enabling payment recording.</li>
                                     <li>**Create Invoice Fix**: Added template_id to invoice creation and error handling for better feedback.</li>
                                     <li>**Logo Display**: Fixed logo URLs across all views (approvals, invoices, payments, client portal) using `url()` function for proper path resolution.</li>
                                     <li>**Invoice Templates**: Added invoice template support with template selector in invoice preview modal.</li>
                                 </ul>
                             </div>
                         </div>
                     </div>

                     <!-- Version 1.3.0 -->
                    <div class="relative pl-8 border-l-2 border-gray-300">
                        <div class="absolute -left-[9px] top-0 w-4 h-4 bg-gray-400 rounded-full border-4 border-white"></div>
                        <h3 class="text-lg font-bold text-gray-700 mb-4 flex items-center">
                            v1.3.0 - Web Integration & Document Flow
                            <span class="ml-3 text-xs font-normal text-gray-400">June 15, 2026</span>
                        </h3>
                        <p class="text-sm text-gray-500 mb-2">Professional landing page, lead capture forms, and public API integration.</p>
                    </div>

                    <!-- Version 1.2.0 -->
                    <div class="relative pl-8 border-l-2 border-gray-300">
                        <div class="absolute -left-[9px] top-0 w-4 h-4 bg-gray-400 rounded-full border-4 border-white"></div>
                        <h3 class="text-lg font-bold text-gray-700 mb-4 flex items-center">v1.2.0 - UI Standardization</h3>
                        <ul class="text-sm text-gray-500 space-y-1 list-disc pl-4">
                            <li>Custom professional confirmation modals globally.</li>
                            <li>Full mobile responsiveness for Settings panel.</li>
                            <li>Standardized headers with icon-based navigation.</li>
                        </ul>
                    </div>
                    <div class="relative pl-8 border-l-2 border-gray-200">
                        <div class="absolute -left-[9px] top-0 w-4 h-4 bg-gray-200 rounded-full border-4 border-white"></div>
                        <h3 class="text-lg font-bold text-gray-700 mb-2">v1.0.0 - Initial Release</h3>
                        <p class="text-sm text-gray-500">Core CRM modules: Enquiries, Clients, Approvals, Invoices, and Payments with JSON-NoSql storage engine.</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- DB Cleanup Tab -->
        <div x-show="activeTab === 'cleanup'" class="space-y-6">
            <div class="card p-8 border-t-4 border-red-600">
                <div class="mb-6"><h2 class="text-xl font-bold text-red-600">Database Cleanup Module</h2><p class="text-sm text-gray-500">Select the modules you want to wipe. This action is permanent and cannot be undone.</p></div>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                    <template x-for="(label, key) in {enquiries: 'Enquiries', approvals: 'Approvals', invoices: 'Invoices', payments: 'Payments', clients: 'Clients'}">
                        <label class="flex items-center space-x-3 p-4 bg-gray-50 rounded-lg border hover:border-red-300 transition cursor-pointer">
                            <input type="checkbox" x-model="cleanupOptions[key]" class="w-5 h-5 text-red-600 rounded border-gray-300">
                            <span class="font-medium text-gray-700" x-text="label"></span>
                        </label>
                    </template>
                </div>
                <div class="flex items-center justify-between p-4 bg-red-50 rounded-lg border border-red-100">
                    <button type="button" @click="runCleanup()" class="bg-red-600 text-white px-6 py-2 rounded font-bold hover:bg-red-700 transition shadow-lg">Execute Selected Cleanup</button>
                </div>
            </div>
        </div>
    </main>

    <!-- Global Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-[100] flex items-center justify-center p-4" style="display: none;">
        <div @click="confirmModal.show = false" class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
        <div class="inline-block w-full max-w-sm p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-[110]">
            <h3 class="text-lg font-medium mb-2">Confirm Action</h3>
            <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
            <div class="flex justify-end space-x-3">
                <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
                <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 px-6 py-3 rounded-full text-white shadow-lg z-50" :class="toast.type === 'success' ? 'bg-gray-900' : 'bg-red-600'" x-text="toast.message"></div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('settingsPage', () => ({
        activeTab: 'details',
        settings: <?php echo json_encode($settings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        toast: { show: false, message: '', type: 'success' },
        editor: null,
        selectedTpl: null,
        selectedEmailTpl: null,
        logs: [],
        emailLogs: [],
        confirmModal: { show: false, message: '', callback: null },
        cleanupOptions: { enquiries: false, approvals: false, invoices: false, payments: false, clients: false },

        selectTemplate(tpl) { this.selectedTpl = tpl; this.initEditor(tpl); },
        initEditor(tpl) {
            if (!tpl) return;
            this.$nextTick(() => {
                if (this.editor) this.editor.destruct();
                let bgImages = []; let bgSizes = []; let bgPositions = [];
                bgImages.push(`linear-gradient(to bottom, transparent 296.7mm, #cbd5e1 296.7mm, #cbd5e1 297mm)`);
                bgSizes.push('100% 297mm'); bgPositions.push('top left');
                if (tpl.bg_graphic) { bgImages.push(`url('${url(tpl.bg_graphic)}')`); bgSizes.push('cover'); bgPositions.push('center'); }
                let bgStyles = `background-image: ${bgImages.join(', ')}; background-size: ${bgSizes.join(', ')}; background-position: ${bgPositions.join(', ')}; background-repeat: repeat-y; background-color: white; `;
                let extraStyles = '';
                if (tpl.header_graphic) { extraStyles += `body::before { content: ''; display: block; width: 100%; height: 150px; background: url('${url(tpl.header_graphic)}') no-repeat center / contain; margin-bottom: 20mm; } `; }
                if (tpl.footer_graphic || tpl.stamp_sign) {
                    let footerBg = []; let footerPos = []; let footerSize = [];
                    if (tpl.stamp_sign) { footerBg.push(`url('${url(tpl.stamp_sign)}')`); footerPos.push('right bottom 20px'); footerSize.push('auto 100px'); }
                    if (tpl.footer_graphic) { footerBg.push(`url('${url(tpl.footer_graphic)}')`); footerPos.push('left bottom'); footerSize.push('contain'); }
                    extraStyles += `body::after { content: ''; display: block; width: 100%; height: 150px; background-image: ${footerBg.join(', ')}; background-position: ${footerPos.join(', ')}; background-size: ${footerSize.join(', ')}; background-repeat: no-repeat; margin-top: 20mm; position: relative; z-index: 100; } `;
                }
                this.editor = new Jodit('#approval-editor', { height: 'auto', minHeight: 1122, width: '100%', toolbarAdaptive: false, theme: 'default', iframe: true, iframeStyle: `html { background: #eee; } body { font-family: sans-serif; font-size: 14px; padding: 20mm; color: #000; margin: 20px auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); width: 210mm; min-height: 297mm; ${bgStyles} } b, strong { font-weight: 700 !important; } i, em { font-style: italic !important; } u { text-decoration: underline !important; } h1 { font-size: 24px; font-weight: 700; } h2 { font-size: 20px; font-weight: 700; } h3 { font-size: 18px; font-weight: 700; } ${extraStyles}`, buttons: 'undo,redo,|,bold,strikethrough,underline,italic,|,superscript,subscript,|,ul,ol,|,outdent,indent,|,font,fontsize,brush,paragraph,|,image,video,table,link,|,align,undo,redo,|,hr,eraser,copyformat,|,fullsize,selectall,print,source', uploader: { insertImageAsBase64URI: true } });
                this.editor.value = tpl.content || '';
                this.editor.events.on('change', (newValue) => { tpl.content = newValue; });
            });
        },
        removeAsset(tpl, key) { tpl[key] = ''; this.showToast('Graphic removed'); this.initEditor(tpl); },
        insertShortcode(code) { if (this.editor) { this.editor.s.insertHTML(code); } },
        showToast(msg, type = 'success') { this.toast.message = msg; this.toast.type = type; this.toast.show = true; setTimeout(() => this.toast.show = false, type === 'error' ? 6000 : 3000); },
        async saveSettings() {
            try {
                const res = await fetch(url('/settings'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: this.encodePayload(this.settings) });
                const text = await res.text();
                let data = {};
                try { data = JSON.parse(text); } catch (e) {}
                if (res.ok && data.status !== 'error') {
                    this.showToast(data.message || 'Settings updated successfully');
                } else {
                    let msg = data.message || ('Save failed (HTTP ' + res.status + ')');
                    if (data.diagnostics) {
                        const d = data.diagnostics;
                        msg += ' | ' + Object.entries(d).filter(([,v]) => v !== null && v !== undefined).map(([k,v]) => k + ': ' + v).join(' | ');
                    }
                    console.error('Settings save failed', data, text);
                    this.showToast(msg, 'error');
                }
            } catch (e) {
                this.showToast('Network error saving settings', 'error');
            }
        },
        encodePayload(obj) {
            const json = JSON.stringify(obj);
            const bytes = new TextEncoder().encode(json);
            let bin = '';
            const CHUNK = 0x8000;
            for (let i = 0; i < bytes.length; i += CHUNK) {
                bin += String.fromCharCode.apply(null, bytes.subarray(i, i + CHUNK));
            }
            return btoa(bin);
        },
        async fetchLogs() { const res = await fetch(url('/settings/logs')); const data = await res.json(); this.logs = data.logs; },
        async fetchEmailLogs() { const res = await fetch(url('/settings/email-logs')); const data = await res.json(); this.emailLogs = data.logs; },
        async uploadLogo(e) { const file = e.target.files[0]; if (!file) return; const formData = new FormData(); formData.append('logo', file); const res = await fetch(url('/settings/logo'), { method: 'POST', body: formData }); const data = await res.json(); if (data.status === 'success') { this.settings.logo_url = data.logo_url; this.showToast('Logo updated'); } else { this.showToast(data.message, 'error'); } },
        addService() { if(!this.settings.services) this.settings.services = []; this.settings.services.push({ id: Date.now().toString(), name: 'New Service', description: '', price: 0 }); },
        removeService(id) { this.settings.services = this.settings.services.filter(s => s.id !== id); },
        addBudget() { if(!this.settings.budgets) this.settings.budgets = []; this.settings.budgets.push({ id: Date.now().toString(), name: 'New Range', range: '₹' }); },
        removeBudget(id) { this.settings.budgets = this.settings.budgets.filter(b => b.id !== id); },
        addBank() { if (!this.settings.bank_accounts) this.settings.bank_accounts = []; this.settings.bank_accounts.push({ id: Date.now().toString(), account_name: '', account_no: '', ifsc: '', branch: '' }); },
        removeBank(id) { this.settings.bank_accounts = this.settings.bank_accounts.filter(b => b.id !== id); },
        async uploadAsset(e, callback, oldUrl = '') {
        const file = e.target.files[0];
        if (!file) return;
        const formData = new FormData();
        formData.append('asset', file);
        if (oldUrl) formData.append('old_url', oldUrl);
        const res = await fetch(url('/settings/asset'), { method: 'POST', body: formData });
        const data = await res.json();
        if (data.status === 'success') {
            callback(data.url);
            this.showToast('Asset uploaded');
        } else {
            this.showToast(data.message, 'error');
        }
    },
        addApprovalTemplate() { if (!this.settings.approval_templates) this.settings.approval_templates = []; const n = { id: Date.now().toString(), name: 'New Template', content: '<h1>Project Approval</h1><p>Dear {{client_name}},</p>', bg_graphic: '', header_graphic: '', footer_graphic: '', stamp_sign: '', is_default: false }; this.settings.approval_templates.push(n); this.selectTemplate(n); },
        removeApprovalTemplate(id) { this.settings.approval_templates = this.settings.approval_templates.filter(t => t.id !== id); if(this.selectedTpl?.id === id) this.selectedTpl = null; },
        setDefaultTemplate(id) { this.settings.approval_templates.forEach(t => { t.is_default = (t.id === id); }); this.showToast('Default template set'); },
        confirmAction(message, callback) { this.confirmModal.message = message; this.confirmModal.callback = callback; this.confirmModal.show = true; },
        executeConfirm() { if (this.confirmModal.callback) this.confirmModal.callback(); this.confirmModal.show = false; },
        
        testSmtpModal: false,
        testEmail: '',
        isTestingSmtp: false,
        
        async testSmtpConnection() {
            if (!this.testEmail) { this.showToast('Enter a test email address', 'error'); return; }
            this.isTestingSmtp = true;
            try {
                const res = await fetch(url('/settings/smtp-test'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: this.encodePayload({ test_email: this.testEmail, smtp: this.settings.smtp })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast(data.message);
                    this.testSmtpModal = false;
                } else {
                    this.showToast(data.message, 'error');
                }
            } catch (err) {
                this.showToast('Connection failed', 'error');
            }
            this.isTestingSmtp = false;
        },

        async generateSampleData() {
            this.confirmAction('Generate 5 sample records for each module? This will not delete existing data.', async () => {
                const res = await fetch(url('/settings/sample-data'), { method: 'POST' });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast(data.message);
                } else {
                    this.showToast(data.message, 'error');
                }
            });
        },

        async clearLogs(type = 'audit') { this.confirmAction(`Are you sure you want to permanently clear all ${type} logs?`, async () => { const res = await fetch(url(`/database/clear-logs?type=${type}`), { method: 'POST' }); const data = await res.json(); if (data.status === 'success') { this.showToast(data.message); if (type === 'audit') this.logs = []; else this.emailLogs = []; } }); },
        async runCleanup() {
            const selected = Object.keys(this.cleanupOptions).filter(k => this.cleanupOptions[k]);
            if (selected.length === 0) { this.showToast('Select at least one module', 'error'); return; }
            this.confirmAction(`DANGER: This will permanently WIPE all data from: ${selected.join(', ')}. Continue?`, async () => {
                const res = await fetch(url('/database/clean'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ collections: selected }) });
                const data = await res.json();
                if (data.status === 'success') { this.showToast(data.message); selected.forEach(k => this.cleanupOptions[k] = false); } else { this.showToast(data.message, 'error'); }
            });
        }
    }))
})
</script>

</body>
</html>
