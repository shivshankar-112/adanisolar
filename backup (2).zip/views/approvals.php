<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Approvals - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <script src="<?= url('/assets/js/html2pdf.bundle.min.js') ?>"></script>
    <link rel="stylesheet" href="<?= url('/assets/css/jodit.min.css') ?>"/>
    <script src="<?= url('/assets/js/jodit.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
        .jodit-container { border: none !important; }
        .jodit-wysiwyg { padding: 0 !important; background: transparent !important; }
        @media print {
            .no-print { display: none !important; }
            body { background-color: white !important; }
            .print-only { display: block !important; }
            .card { box-shadow: none !important; border: none !important; }
        }
        .prose b, .prose strong { font-weight: bold !important; }
        .prose i, .prose em { font-style: italic !important; }
        .prose u { text-decoration: underline !important; }
        .prose h1 { font-size: 24pt !important; font-weight: bold !important; margin-bottom: 0.5em !important; }
        .prose h2 { font-size: 18pt !important; font-weight: bold !important; margin-bottom: 0.5em !important; }
        .prose h3 { font-size: 14pt !important; font-weight: bold !important; margin-bottom: 0.5em !important; }
        .prose ul { list-style-type: disc !important; padding-left: 40px !important; margin-bottom: 1em !important; }
        .prose ol { list-style-type: decimal !important; padding-left: 40px !important; margin-bottom: 1em !important; }
        .prose p { margin-bottom: 1em !important; }
        .approval-bg-standard {
            background-size: cover !important;
            background-position: center !important;
            background-repeat: no-repeat !important;
            background-color: white;
        }
    </style>
</head>
<body class="text-gray-800">

<div x-data="approvalManager" class="min-h-screen flex flex-col">

    <div class="no-print">
        <?php 
        $activePage = 'approvals';
        include __DIR__ . '/partials/header.php'; 
        ?>

        <!-- Actions Toolbar -->
        <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4 shadow-sm sticky top-0 z-30">
            <div class="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 flex-grow">
                <div class="relative group">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 group-focus-within:text-blue-500 transition-colors">
                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </span>
                    <input type="text" x-model="searchQuery" autocomplete="off" placeholder="Search approvals..." class="bg-gray-50 border border-gray-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full lg:w-64 transition-all">
                </div>

                <!-- Advanced Filters -->
                <div class="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                    <select x-model="filterStatus" @change="fetchData(1)" class="bg-gray-50 border border-gray-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none flex-shrink-0 cursor-pointer hover:bg-white transition-colors">
                        <option value="">All Status</option>
                        <option value="Draft">Draft</option>
                        <option value="Sent">Sent</option>
                        <option value="Accepted">Accepted</option>
                        <option value="Rejected">Rejected</option>
                    </select>

                    <button type="button" @click="showTrash = !showTrash; fetchData(1)" class="flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all flex-shrink-0" :class="showTrash ? 'bg-red-100 text-red-700 shadow-inner' : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-white hover:shadow-sm'">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        <span x-text="showTrash ? 'Viewing Trash' : 'Trash'"></span>
                    </button>
                    
                    <button type="button" @click="filterStatus=''; searchQuery=''; showTrash=false; fetchData(1)" class="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline px-2 flex-shrink-0">Reset</button>
                </div>
                
                <!-- Bulk Actions -->
                <div x-show="selected.length > 0" x-transition class="flex flex-wrap items-center gap-2 lg:border-l lg:pl-4 pb-1 lg:pb-0" style="display: none;">
                    <span class="text-xs text-gray-500 font-bold mr-2 whitespace-nowrap bg-blue-50 px-2 py-1 rounded" x-text="selected.length + ' selected'"></span>
                    <button type="button" @click="bulkAction('approve')" class="text-[10px] md:text-xs font-bold bg-green-50 hover:bg-green-100 text-green-700 px-3 py-1.5 rounded-lg border border-green-200 transition-all flex-shrink-0">Accept</button>
                    <button type="button" @click="bulkAction('reject')" class="text-[10px] md:text-xs font-bold bg-red-50 hover:bg-red-100 text-red-700 px-3 py-1.5 rounded-lg border border-red-200 transition-all flex-shrink-0">Reject</button>
                    <button type="button" @click="bulkAction('delete')" class="text-[10px] md:text-xs font-bold bg-gray-50 hover:bg-red-50 text-red-600 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-red-200 transition-all flex-shrink-0">Delete</button>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <button type="button" @click="exportToCSV()" class="flex-1 lg:flex-none justify-center bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 hover:shadow-sm transition-all flex items-center">
                    <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Export
                </button>
                <button type="button" @click="openNewApprovalModal()" class="flex-1 lg:flex-none justify-center btn-google py-2 px-6 rounded-lg text-sm font-semibold shadow-md hover:shadow-lg transition-all flex items-center">
                    <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                    New Approval
                </button>
            </div>
        </div>

        <main class="flex-grow p-4 md:p-8">
            <div class="max-w-full mx-auto">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-6 md:mb-8 gap-4">
                    <h1 class="text-xl md:text-2xl">Approvals</h1>
                </div>

                <div class="card overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                            <thead class="bg-gray-50 border-b">
                                <tr>
                                    <th class="px-3 md:px-4 py-3 w-10 md:w-12"><input type="checkbox" x-model="selectAll" @change="toggleSelectAll()" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"></th>
                                    <th @click="sortBy('approval_no')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Approval No
                                        <span x-show="sortKey === 'approval_no'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('client_name')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Client
                                        <span x-show="sortKey === 'client_name'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('subject')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase cursor-pointer hover:bg-gray-100">
                                        Subject
                                        <span x-show="sortKey === 'subject'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('amount')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Amount
                                        <span x-show="sortKey === 'amount'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('status')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Status
                                        <span x-show="sortKey === 'status'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('created_at')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100 text-right">
                                        Date
                                        <span x-show="sortKey === 'created_at'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y">
                                <template x-for="approval in filteredApprovals" :key="approval.id">
                                    <tr class="hover:bg-gray-50 transition group">
                                        <td class="px-3 md:px-4 py-4"><input type="checkbox" :value="approval.id" x-model="selected" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500 cursor-pointer"></td>
                                        <td class="px-3 md:px-4 py-4 font-medium text-blue-600 whitespace-nowrap">
                                            <a href="#" @click.prevent="openPreviewModal(approval)" x-text="approval.approval_no" class="hover:underline text-xs md:text-sm"></a>
                                        </td>
                                        <td class="px-3 md:px-4 py-4">
                                            <div class="text-xs md:text-sm font-medium text-gray-900 truncate max-w-[150px]" :title="approval.client_name" x-text="approval.client_name"></div>        
                                            <div class="text-[10px] md:text-xs text-gray-500 truncate max-w-[150px]" :title="approval.email">
                                                <a :href="'mailto:' + approval.email" class="hover:text-blue-600 hover:underline" x-text="approval.email"></a>
                                            </div>
                                        </td>
                                        <td class="px-3 md:px-4 py-4 text-xs md:text-sm text-gray-900 font-medium truncate max-w-[200px]" :title="approval.subject" x-text="approval.subject"></td>
                                        <td class="px-3 md:px-4 py-4 text-xs md:text-sm font-medium text-gray-900" x-text="'₹' + parseFloat(approval.amount || 0).toLocaleString()"></td>
                                        <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                            <template x-if="approval.status === 'Draft'">
                                                <div class="flex items-center bg-gray-100 rounded-full p-0.5 w-max border">
                                                    <button type="button" @click="updateStatus(approval.id, 'Sent')" class="px-2 md:px-3 py-1 text-[9px] md:text-xs rounded-full font-medium transition-colors hover:bg-white hover:shadow-sm text-gray-500 hover:text-blue-600">Send</button>
                                                </div>
                                            </template>
                                            <template x-if="approval.status === 'Sent'">
                                                <div class="flex items-center bg-gray-100 rounded-full p-0.5 w-max border">
                                                    <button type="button" @click="updateStatus(approval.id, 'Accepted')" class="px-2 md:px-3 py-1 text-[9px] md:text-xs rounded-full font-medium transition-colors hover:bg-white hover:shadow-sm text-gray-500 hover:text-green-600">Accept</button>
                                                    <button type="button" @click="updateStatus(approval.id, 'Rejected')" class="px-2 md:px-3 py-1 text-[9px] md:text-xs rounded-full font-medium transition-colors hover:bg-white hover:shadow-sm text-gray-500 hover:text-red-600">Reject</button>
                                                </div>
                                            </template>
                                            <template x-if="approval.status !== 'Sent' && approval.status !== 'Draft'">
                                                <span :class="{
                                                    'bg-green-100 text-green-700': approval.status === 'Accepted' || approval.status === 'Paid',
                                                    'bg-blue-100 text-blue-700 border-blue-200': approval.status === 'Invoiced',
                                                    'bg-red-100 text-red-700 border-red-200': approval.status === 'Rejected'
                                                }" class="px-3 py-1 text-[10px] md:text-xs rounded-full font-bold whitespace-nowrap border" x-text="approval.status"></span>
                                            </template>
                                        </td>
                                        <td class="px-4 py-4 text-[10px] md:text-xs text-gray-500 text-right font-medium" x-text="approval.created_at"></td>
                                        <td class="px-4 py-4 text-right space-x-1 md:space-x-2 whitespace-nowrap">
                                            <button type="button" @click="openPreviewModal(approval)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">View</button>
                                            <template x-if="approval.status === 'Accepted'">
                                                <button type="button" @click="openInvoiceModal(approval)" class="text-[10px] md:text-xs text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg font-bold transition-all shadow-sm">Invoice</button>
                                            </template>
                                            <?php if (\App\Services\PermissionHelper::check('approvals', 'delete')): ?>
                                                <template x-if="!approval.deleted_at">
                                                    <button type="button" @click="deleteApproval(approval.id)" class="text-gray-400 hover:text-red-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-red-50"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                                </template>
                                                <template x-if="approval.deleted_at">
                                                    <button type="button" @click="restoreApproval(approval.id)" class="text-gray-400 hover:text-green-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-green-50"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg></button>
                                                </template>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                    <template x-if="pagination.total_pages > 1">
                        <div class="px-4 py-4 border-t border-gray-100 bg-gray-50 flex flex-col sm:flex-row items-center justify-between gap-4">
                            <div class="text-[10px] md:text-xs font-bold text-gray-500 uppercase tracking-widest">
                                Showing <span class="text-gray-900" x-text="(pagination.current_page - 1) * pagination.per_page + 1"></span> 
                                - <span class="text-gray-900" x-text="Math.min(pagination.current_page * pagination.per_page, pagination.total)"></span> 
                                of <span class="text-gray-900" x-text="pagination.total"></span> entries
                            </div>
                            <div class="flex items-center space-x-2">
                                <button @click="fetchData(pagination.current_page - 1)" :disabled="pagination.current_page <= 1" class="px-4 py-2 border border-gray-200 rounded-lg text-xs font-bold bg-white text-gray-600 hover:bg-gray-50 hover:text-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm">Previous</button>
                                <button @click="fetchData(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.total_pages" class="px-4 py-2 border border-gray-200 rounded-lg text-xs font-bold bg-white text-gray-600 hover:bg-gray-50 hover:text-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all shadow-sm">Next</button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </main>
    </div>

    <!-- Modals -->
    <div x-show="showNewApprovalModal" class="fixed inset-0 z-50 overflow-y-auto no-print px-4 py-6" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="showNewApprovalModal = false" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            <div class="inline-block w-full max-w-xl p-4 md:p-8 overflow-visible text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg md:text-xl font-bold text-gray-900">Create New Approval</h3>
                    <button @click="showNewApprovalModal = false" class="text-gray-400 hover:text-gray-600 transition-colors"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                </div>
                <div class="space-y-5 max-h-[70vh] overflow-y-auto px-1 custom-scrollbar">
                    <div class="bg-blue-50 p-4 rounded-xl border border-blue-100 shadow-sm">
                        <label class="text-[10px] font-bold text-blue-700 uppercase tracking-widest mb-1.5 block">Quick Select Client</label>
                        <select @change="selectClient($event.target.value)" class="w-full border-none focus:ring-0 outline-none py-1 bg-transparent text-sm md:text-base font-medium text-blue-900 cursor-pointer">
                            <option value="">-- Search existing clients --</option>
                            <template x-for="c in clientsList" :key="c.id"><option :value="c.id" x-text="c.client_name"></option></template>
                        </select>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div class="space-y-1.5"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Client Name *</label><input type="text" x-model="newStandaloneApproval.client_name" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm md:text-base transition-all"></div>
                        <div class="space-y-1.5"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Email Address *</label><input type="email" x-model="newStandaloneApproval.email" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm md:text-base transition-all"></div>
                    </div>
                    <div class="space-y-1.5"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Approval Subject *</label><input type="text" x-model="newStandaloneApproval.subject" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm md:text-base transition-all"></div>
                    <div class="space-y-4">
                        <div class="flex justify-between items-center pb-2 border-b border-gray-100"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Scope of Services</label><button type="button" @click="addServiceItem('new')" class="text-[11px] bg-blue-50 text-blue-600 font-bold px-3 py-1 rounded-full hover:bg-blue-100 transition-all">+ Add Service</button></div>
                        <template x-for="(item, index) in newStandaloneApproval.items" :key="index">
                            <div class="flex flex-col sm:flex-row items-stretch sm:items-end gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200 relative group">
                                <div class="flex-grow space-y-1.5">
                                    <label class="text-[9px] font-bold text-gray-400 uppercase">Service Description</label>
                                    <select x-model="item.service" @change="onCatalogServiceSelect($event, item)" class="w-full text-sm border-none bg-transparent p-0 focus:ring-0 font-medium">
                                        <option value="">Select from catalog...</option>
                                        <template x-for="ms in masterServices" :key="ms.id"><option :value="ms.name" :data-price="ms.price" x-text="ms.name"></option></template>
                                    </select>
                                    <input type="text" x-model="item.service" class="w-full text-[11px] italic border-none p-0 bg-transparent focus:ring-0 text-gray-500" placeholder="Or type a custom service name...">
                                </div>
                                <div class="w-full sm:w-32 space-y-1.5">
                                    <label class="text-[9px] font-bold text-gray-400 uppercase">Price (₹)</label>
                                    <input type="number" x-model="item.price" class="w-full text-sm border-none bg-transparent p-0 focus:ring-0 font-bold" placeholder="0.00">
                                </div>
                                <button type="button" @click="removeServiceItem(index, 'new')" x-show="newStandaloneApproval.items.length > 1" class="absolute -top-2 -right-2 bg-white text-red-400 hover:text-red-600 rounded-full shadow-md p-1 border border-red-50 transition-all opacity-0 group-hover:opacity-100"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                            </div>
                        </template>
                    </div>
                </div>
                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3 border-t border-gray-100 pt-6"><button type="button" @click="showNewApprovalModal = false" class="w-full sm:w-auto px-6 py-2.5 text-sm font-bold text-gray-500 hover:text-gray-700 transition-colors">Dismiss</button><button type="button" @click="createStandaloneApproval()" class="w-full sm:w-auto btn-google py-2.5 px-8 text-sm font-bold shadow-lg hover:shadow-xl transform active:scale-95 transition-all">Create Approval</button></div>
            </div>
        </div>
    </div>

    <!-- Preview Modal -->
    <div x-show="activePreview !== null" class="fixed inset-0 z-50 overflow-y-auto no-print" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-2 md:px-4 py-4 text-center">
            <div @click="activePreview = null" class="fixed inset-0 transition-opacity bg-black bg-opacity-40 backdrop-blur-sm"></div>
            <div class="inline-block w-full max-w-full lg:max-w-6xl p-4 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4 mb-6 pb-4 border-b">
                    <h3 class="text-lg md:text-xl font-medium" x-text="'Approval: ' + (activePreview?.approval_no || '')"></h3>
                    <div class="flex flex-wrap items-center gap-2 md:gap-3 w-full lg:w-auto">
                        <div class="flex items-center space-x-2 border-r pr-2 md:pr-3">
                            <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase">Status:</label>
                            <select x-model="activePreview.status" @change="updateStatus(activePreview.id, $event.target.value)" class="text-[10px] md:text-xs font-bold bg-transparent border-none focus:ring-0 cursor-pointer p-0">
                                <option value="Draft">Draft</option><option value="Sent">Sent</option><option value="Accepted">Accepted</option><option value="Rejected">Rejected</option>
                            </select>
                        </div>
                        <button type="button" @click="openEmailModal(activePreview)" class="bg-blue-50 text-blue-600 px-3 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-bold flex items-center hover:bg-blue-100 transition">
                            <svg class="w-3.5 h-3.5 md:w-4 md:h-4 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>Email
                        </button>
                        <button type="button" @click="toggleEdit()" class="px-3 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-medium transition" :class="isEditing ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'">
                            <span x-text="isEditing ? 'Finish' : 'Edit'"></span>
                        </button>
                        <select x-model="activePreview.template_id" @change="saveApproval()" class="text-[10px] md:text-sm border rounded px-2 md:px-3 py-1.5 bg-white outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">-- Template --</option>
                            <template x-for="t in templates" :key="t.id"><option :value="t.id" x-text="t.name"></option></template>
                        </select>
                        <button type="button" @click="downloadPDF(activePreview)" class="bg-gray-100 hover:bg-gray-200 px-3 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-medium transition flex items-center">
                            <svg class="w-3.5 h-3.5 md:w-4 md:h-4 mr-1.5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>PDF
                        </button>
                        <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-600 ml-auto lg:ml-0 transition p-1">
                            <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                </div>

                <div x-show="isEditing" class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6 bg-blue-50/50 p-4 md:p-6 rounded-xl border border-blue-100">
                    <div class="space-y-4">
                        <div class="space-y-1"><label class="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Subject</label><input type="text" x-model="activePreview.subject" @input.debounce.500ms="saveApproval()" class="w-full border-b border-gray-300 focus:border-blue-600 outline-none bg-transparent text-sm py-1 font-medium transition"></div>
                        <div class="space-y-1"><label class="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Date</label><input type="date" x-model="activePreview.created_at" @input.debounce.500ms="saveApproval()" class="w-full border-b border-gray-300 focus:border-blue-600 outline-none bg-transparent text-sm py-1 transition"></div>
                        <div class="pt-4 border-t border-blue-100 flex justify-between items-center"><label class="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Total Amount</label><div class="text-2xl font-bold text-blue-600" x-text="'₹' + (activePreview.amount || 0).toLocaleString()"></div></div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center"><label class="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Line Items</label><button type="button" @click="addServiceItem('edit')" class="text-[10px] bg-blue-600 text-white px-3 py-1 rounded-full font-bold hover:bg-blue-700 transition shadow-sm">+ Add Item</button></div>
                        <div class="space-y-2 max-h-64 overflow-y-auto pr-2 custom-scrollbar">
                            <template x-for="(item, index) in activePreview.items" :key="index">
                                <div class="flex items-end space-x-2 group bg-white p-2.5 rounded-lg border border-gray-200 shadow-sm">
                                    <div class="flex-grow">
                                        <select x-model="item.service" @change="onCatalogServiceSelect($event, item); saveApproval(); calculateTotal();" class="w-full text-xs border-b border-gray-100 outline-none bg-transparent py-0.5 focus:border-blue-300 transition">
                                            <template x-for="ms in masterServices" :key="ms.id"><option :value="ms.name" :data-price="ms.price" x-text="ms.name"></option></template>
                                        </select>
                                        <input type="text" x-model="item.service" @input.debounce.500ms="saveApproval()" class="w-full text-[10px] italic border-none p-0 bg-transparent focus:ring-0 text-gray-500">
                                    </div>
                                    <div class="w-20 md:w-24"><input type="number" x-model="item.price" @input.debounce.500ms="calculateTotal(); saveApproval()" class="w-full text-xs border-b border-gray-100 outline-none py-0.5 font-bold text-right focus:border-blue-300 transition" placeholder="Price"></div>
                                    <button type="button" @click="removeServiceItem('edit', index)" class="text-red-400 hover:text-red-600 transition p-1"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                </div>
                            </template>
                        </div>
                    </div>
                </div>

                <div class="bg-gray-100 rounded-xl p-4 md:p-8 overflow-x-auto flex justify-center shadow-inner">
                    <div class="border shadow-2xl mx-auto bg-white relative overflow-hidden approval-bg-standard min-w-[210mm]" 
                         id="approval-content" style="width: 210mm; transform: scale(0.9); transform-origin: top center; margin-bottom: -100px;">
                        <template x-if="activePreview?.template_id">
                            <div class="relative z-10 h-full flex flex-col">
                                <div x-show="!isEditing" class="flex flex-col flex-grow">
                                    <template x-if="templates.find(t => t.id === activePreview.template_id)?.header_graphic"><img :src="url(templates.find(t => t.id === activePreview.template_id).header_graphic)" class="w-full"></template>
                                    <div class="flex-grow p-[20mm] text-left"><div class="prose max-w-none" x-html="activePreview.custom_content || renderTemplate(templates.find(t => t.id === activePreview.template_id)?.content, activePreview)"></div></div>
                                    <div class="mt-auto p-[20mm] flex justify-between items-end relative z-20">
                                        <div class="relative z-10 flex-grow text-left"><template x-if="templates.find(t => t.id === activePreview.template_id)?.footer_graphic"><img :src="url(templates.find(t => t.id === activePreview.template_id).footer_graphic)" class="w-full"></template></div>
                                        <div class="text-center relative z-30 ml-4 mb-4"><template x-if="templates.find(t => t.id === activePreview.template_id)?.stamp_sign"><img :src="url(templates.find(t => t.id === activePreview.template_id).stamp_sign)" class="h-28 mx-auto -mb-8 object-contain relative z-40"></template><div class="border-t pt-2 text-xs text-gray-500 uppercase font-medium bg-white bg-opacity-80 px-2">Authorized Signatory</div></div>
                                    </div>
                                </div>
                                <div x-show="isEditing" class="flex-grow bg-gray-50 p-4 md:p-8"><div class="mx-auto" style="width: 100%;"><textarea id="inline-approval-editor"></textarea></div></div>
                            </div>
                        </template>
                        <template x-if="!activePreview?.template_id"><div class="h-[297mm] flex items-center justify-center text-gray-400 italic">Select a template to preview.</div></template>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Invoice Modal -->
    <div x-show="showInvoiceModal" class="fixed inset-0 z-50 overflow-y-auto no-print px-4 py-6" style="display: none;">
        <div class="flex items-center justify-center min-h-screen text-center">
            <div @click="showInvoiceModal = false" class="fixed inset-0 bg-black bg-opacity-40 backdrop-blur-sm transition-opacity"></div>
            <div class="inline-block w-full max-w-2xl p-6 md:p-8 overflow-visible text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg md:text-xl font-bold text-gray-900">Create Invoice</h3>
                    <button @click="showInvoiceModal = false" class="text-gray-400 hover:text-gray-600 transition-colors"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-5">
                        <div class="bg-gray-50 p-4 rounded-xl border border-gray-100 shadow-sm">
                            <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Bill To</label>
                            <div class="font-bold text-gray-900" x-text="newInvoice.client_name"></div>
                            <div class="text-xs text-gray-500" x-text="newInvoice.email"></div>
                        </div>
                        <div class="space-y-1.5"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Invoice Subject *</label><input type="text" x-model="newInvoice.subject" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm font-semibold transition-all"></div>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-1.5"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Date *</label><input type="date" x-model="newInvoice.invoice_date" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm transition-all"></div>
                            <div class="space-y-1.5"><label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider">Bank *</label><select x-model="newInvoice.bank_id" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm cursor-pointer transition-all"><option value="">-- Select --</option><template x-for="bank in banks" :key="bank.id"><option :value="bank.id" x-text="bank.account_name"></option></template></select></div>
                        </div>
                    </div>
                    <div class="space-y-4">
                        <label class="text-[11px] font-bold text-gray-500 uppercase tracking-wider block">Billed Items</label>
                        <div class="space-y-2 max-h-64 overflow-y-auto custom-scrollbar pr-1">
                            <template x-for="(item, index) in newInvoice.items" :key="index">
                                <div class="flex items-end space-x-2 bg-blue-50/50 p-3 rounded-xl border border-blue-100/50 transition-all hover:bg-blue-50">
                                    <div class="flex-grow"><input type="text" x-model="item.service" class="w-full text-xs border-none bg-transparent p-0 focus:ring-0 font-medium text-gray-800" placeholder="Service"></div>
                                    <div class="w-24"><input type="number" x-model="item.price" class="w-full text-xs border-none bg-transparent p-0 focus:ring-0 font-bold text-right text-blue-700" placeholder="Price"></div>
                                </div>
                            </template>
                        </div>
                        <div class="pt-4 mt-2 border-t border-gray-100 flex justify-between items-center font-bold text-lg"><span class="text-gray-500 text-sm uppercase">Total</span><span class="text-blue-600" x-text="'₹' + newInvoice.items.reduce((sum, item) => sum + parseFloat(item.price || 0), 0).toLocaleString()"></span></div>
                    </div>
                </div>
                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3 border-t border-gray-100 pt-6"><button type="button" @click="showInvoiceModal = false" class="w-full sm:w-auto px-6 py-2.5 text-sm font-bold text-gray-500 hover:text-gray-700 transition-colors">Cancel</button><button type="button" @click="submitInvoice()" :disabled="submittingInvoice" class="w-full sm:w-auto btn-google py-2.5 px-8 text-sm font-bold shadow-lg hover:shadow-xl transition-all" :class="submittingInvoice ? 'opacity-50 cursor-not-allowed' : ''">Generate Invoice</button></div>
            </div>
        </div>
    </div>

    <!-- Email Modal -->
    <div x-show="showEmailModal" class="fixed inset-0 z-[60] overflow-y-auto no-print px-4 py-6" style="display: none;">
        <div class="flex items-center justify-center min-h-screen text-center">
            <div @click="showEmailModal = false" class="fixed inset-0 bg-black bg-opacity-50 backdrop-blur-sm transition-opacity"></div>
            <div class="inline-block w-full max-w-2xl p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex items-center justify-between mb-6">
                    <h3 class="text-lg md:text-xl font-bold text-gray-900">Send Approval</h3>
                    <button @click="showEmailModal = false" class="text-gray-400 hover:text-gray-600 transition-colors"><svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                </div>
                <div class="space-y-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                        <div class="space-y-1.5"><label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Recipient</label><input type="text" x-model="emailData.to" class="w-full bg-gray-50 border-gray-200 rounded-lg text-gray-500 py-2 px-3 text-sm font-bold" readonly></div>
                        <div class="space-y-1.5"><label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">CC (Comma Separated)</label><input type="text" x-model="emailData.cc" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm transition-all" placeholder="Enter emails..."></div>
                    </div>
                    <div class="space-y-1.5"><label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Subject Line</label><input type="text" x-model="emailData.subject" class="w-full bg-gray-50 border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none py-2 px-3 text-sm font-bold transition-all"></div>
                    <div class="space-y-1.5"><label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Email Body</label><textarea x-model="emailData.body" rows="6" class="w-full bg-gray-50 border border-gray-200 rounded-xl py-3 px-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all resize-none"></textarea></div>
                    <div class="p-4 bg-blue-50 rounded-xl border border-blue-100 flex items-center shadow-sm">
                        <div class="flex-grow">
                            <div class="text-[11px] font-bold text-blue-800 uppercase tracking-wider">PDF Attachment</div>
                            <div class="text-[10px] text-blue-600/70">Securely generated approval document</div>
                        </div>
                        <template x-if="emailData.attachment"><span class="text-[10px] bg-green-500 text-white px-3 py-1 rounded-full font-bold uppercase shadow-sm">Ready</span></template>
                    </div>
                </div>
                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3 border-t border-gray-100 pt-6"><button type="button" @click="showEmailModal = false" class="w-full sm:w-auto px-6 py-2.5 text-sm font-bold text-gray-500 hover:text-gray-700 transition-colors">Dismiss</button><button type="button" @click="submitManualEmail()" class="w-full sm:w-auto btn-google py-2.5 px-8 text-sm font-bold shadow-lg hover:shadow-xl transform active:scale-95 transition-all">Send Email Now</button></div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-50" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div @click="confirmModal.show = false" class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg font-medium mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/partials/footer.php'; ?>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('approvalManager', () => ({
        searchQuery: '',
        approvals: <?= json_encode($approvals) ?>,
        templates: <?= json_encode($settings['approval_templates'] ?? []) ?>,
        masterServices: <?= json_encode($settings['services'] ?? []) ?>,
        banks: <?= json_encode($settings['bank_accounts'] ?? []) ?>,
        emailTemplates: <?php echo json_encode($settings['templates'] ?? []) ?>,
        org: <?= json_encode([
            'name' => $settings['org_name'] ?? '',
            'website' => $settings['website_url'] ?? '',
            'email' => $settings['email'] ?? '',
            'phone' => $settings['phone'] ?? '',
            'logo_url' => $settings['logo_url'] ?? ''
        ]) ?>,
        settings: <?= json_encode($settings) ?>,
        selected: [],
        selectAll: false,
        showTrash: false,
        filterStatus: '',
        sortKey: '',
        sortOrder: 'desc',
        pagination: <?= json_encode($pagination) ?>,
        toast: { show: false, message: '', type: 'success' },
        confirmModal: { show: false, message: '', callback: null },
        activePreview: null,
        isEditing: false,
        editor: null,
        showInvoiceModal: false,
        submittingInvoice: false,
        showNewApprovalModal: false,
        showEmailModal: false,
        emailData: { to: '', cc: '', subject: '', body: '', attachment: '' },
        newStandaloneApproval: { client_name: '', email: '', subject: '', items: [{service: '', price: 0}], approval_date: '' },
        newInvoice: { approval_id: '', client_name: '', email: '', amount: 0, bank_id: '' },
        clientsList: [],
        async init() {
            const cRes = await fetch(url('/clients'), { headers: { 'Accept': 'application/json' } });
            if(cRes.ok) { this.clientsList = (await cRes.json()).clients || []; }
            const urlParams = new URLSearchParams(window.location.search);
            const openId = urlParams.get('open');
            if (openId) { const p = this.approvals.find(pr => pr.id === openId); if (p) this.openPreviewModal(p); }
            this.$watch('searchQuery', () => this.fetchData(1));
            setTimeout(() => { this.searchQuery = ''; }, 50);
        },
        async fetchData(page = 1) {
            const params = new URLSearchParams({
                page: page,
                q: this.searchQuery,
                status: this.filterStatus,
                trash: this.showTrash ? '1' : '0'
            });
            const res = await fetch(url('/approvals?' + params.toString()), {
                headers: { 'Accept': 'application/json' }
            });
            const data = await res.json();
            this.approvals = data.approvals;
            this.pagination = {
                current_page: page,
                per_page: 25,
                total: data.total,
                total_pages: Math.ceil(data.total / 25)
            };
        },
        amountInWords(num) {
            if (!num) return 'Zero Rupees Only';
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            const inWords = (n) => {
                if ((n = n.toString()).length > 9) return 'overflow';
                let nArr = ('000000000' + n).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                if (!nArr) return ''; 
                let str = '';
                str += (nArr[1] != 0) ? (a[Number(nArr[1])] || b[nArr[1][0]] + ' ' + a[nArr[1][1]]) + 'Crore ' : '';
                str += (nArr[2] != 0) ? (a[Number(nArr[2])] || b[nArr[2][0]] + ' ' + a[nArr[2][1]]) + 'Lakh ' : '';
                str += (nArr[3] != 0) ? (a[Number(nArr[3])] || b[nArr[3][0]] + ' ' + a[nArr[3][1]]) + 'Thousand ' : '';
                str += (nArr[4] != 0) ? (a[Number(nArr[4])] || b[nArr[4][0]] + ' ' + a[nArr[4][1]]) + 'Hundred ' : '';
                str += (nArr[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(nArr[5])] || b[nArr[5][0]] + ' ' + a[nArr[5][1]]) : '';
                return str;
            }
            return inWords(Math.floor(num)) + ' Rupees Only';
        },
        async downloadPDF(approval) {
            this.showToast('Generating PDF...');
            if (approval.created_at?.includes(' ')) approval.created_at = approval.created_at.split(' ')[0];
            this.activePreview = approval;
            this.isEditing = false;
            
            await new Promise(r => setTimeout(r, 400));

            const element = document.getElementById('approval-content');
            if(!element) {
                this.showToast('Preview element not found', 'error');
                return;
            }

            const opt = {
                margin: 0,
                filename: `Approval_${approval.approval_no}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { 
                    scale: 2, 
                    useCORS: true,
                    onclone: (clonedDoc) => {
                        const el = clonedDoc.getElementById('approval-content');
                        if (el) {
                            el.style.transform = 'none';
                            el.style.margin = '0';
                            el.style.position = 'static';
                            el.style.display = 'block';
                            el.style.minHeight = 'auto';
                            el.style.height = 'auto';
                        }
                    }
                },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };

            html2pdf().set(opt).from(element).save().catch(err => {
                console.error('PDF Error:', err);
                this.showToast('Error generating PDF', 'error');
            });
        },
        async openEmailModal(approval) {
            this.showToast('Preparing email...');
            if (approval.created_at?.includes(' ')) approval.created_at = approval.created_at.split(' ')[0];
            this.activePreview = approval;
            this.isEditing = false;

            await new Promise(r => setTimeout(r, 400));

            try {
                const element = document.getElementById('approval-content');
                if(!element) {
                    this.showToast('Preview element not found', 'error');
                    return;
                }

                const opt = {
                    margin: 0,
                    image: { type: 'jpeg', quality: 0.98 },
                    html2canvas: { 
                        scale: 1.5, 
                        useCORS: true,
                        onclone: (clonedDoc) => {
                            const el = clonedDoc.getElementById('approval-content');
                            if (el) {
                                el.style.transform = 'none';
                                el.style.margin = '0';
                                el.style.position = 'static';
                                el.style.display = 'block';
                            }
                        }
                    },
                    jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
                };

                const pdfBase64 = await html2pdf().set(opt).from(element).outputPdf('datauristring');
                const tpl = this.emailTemplates.find(t => t.id === 'approval_sent');
                this.emailData = {
                    id: approval.id, to: approval.email, cc: '',
                    subject: tpl ? this.renderTemplate(tpl.subject, approval) : `Approval: ${approval.approval_no}`,
                    body: tpl ? this.renderTemplate(tpl.body, approval) : `Hi ${approval.client_name}, please find attached.`,
                    attachment: pdfBase64
                };
                this.showEmailModal = true;
            } catch (e) { 
                console.error('PDF Error:', e);
                this.showToast('PDF Error', 'error'); 
            }
        },
        async submitManualEmail() {
            this.showToast('Sending...');
            const res = await fetch(url('/approvals/send-email'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.emailData) });
            const data = await res.json();
            if (data.status === 'success') { this.showToast('Sent!'); this.showEmailModal = false; setTimeout(() => this.fetchData(this.pagination.current_page), 1000); }
            else { this.showToast(data.message || 'Failed', 'error'); }
        },
        addServiceItem(type) {
            if (type === 'new') this.newStandaloneApproval.items.push({ service: '', price: 0 });
            else {
                if (!this.activePreview.items) this.activePreview.items = [];
                this.activePreview.items.push({ service: '', price: 0 });
                this.calculateTotal(); this.saveApproval();
            }
        },
        removeServiceItem(index, type) {
            if (type === 'new') this.newStandaloneApproval.items.splice(index, 1);
            else { this.activePreview.items.splice(index, 1); this.calculateTotal(); this.saveApproval(); }
        },
        calculateTotal() { if(this.activePreview) this.activePreview.amount = this.activePreview.items.reduce((s, i) => s + parseFloat(i.price || 0), 0); },
        onCatalogServiceSelect(event, item) {
            const sel = event.target.options[event.target.selectedIndex];
            const price = sel?.dataset?.price;
            if (price !== undefined && price !== '') {
                item.price = parseFloat(price) || 0;
            }
        },
        selectClient(id) { const c = this.clientsList.find(cl => cl.id === id); if(c) { this.newStandaloneApproval.client_name = c.client_name; this.newStandaloneApproval.email = c.email; } },
        toggleEdit() { this.isEditing = !this.isEditing; if(this.isEditing) this.initInlineEditor(this.activePreview); else if(this.editor) { this.editor.destruct(); this.editor = null; } },
        initInlineEditor(p) {
            this.$nextTick(() => {
                if (this.editor) this.editor.destruct();
                const tpl = this.templates.find(t => t.id === p.template_id);
                let bg = []; let sz = []; let pos = [];
                bg.push(`linear-gradient(to bottom, transparent 296.7mm, #cbd5e1 296.7mm, #cbd5e1 297mm)`); sz.push('100% 297mm'); pos.push('top left');
                if(tpl?.bg_graphic) { bg.push(`url('${tpl.bg_graphic}')`); sz.push('cover'); pos.push('center'); }
                let bgStyles = `background-image: ${bg.join(', ')}; background-size: ${sz.join(', ')}; background-position: ${pos.join(', ')}; background-repeat: repeat-y; background-color: white; `;
                let ex = ''; if(tpl?.header_graphic) ex += `body::before { content: ''; display: block; width: 100%; height: 150px; background: url('${tpl.header_graphic}') no-repeat center / contain; margin-bottom: 20mm; } `;
                if(tpl?.footer_graphic || tpl?.stamp_sign) {
                    let fbg = []; let fpos = []; let fsz = [];
                    if(tpl.stamp_sign) { fbg.push(`url('${tpl.stamp_sign}')`); fpos.push('right bottom 20px'); fsz.push('auto 100px'); }
                    if(tpl.footer_graphic) { fbg.push(`url('${tpl.footer_graphic}')`); fpos.push('left bottom'); fsz.push('contain'); }
                    ex += `body::after { content: ''; display: block; width: 100%; height: 150px; background-image: ${fbg.join(', ')}; background-position: ${fpos.join(', ')}; background-size: ${fsz.join(', ')}; background-repeat: no-repeat; margin-top: 20mm; position: relative; z-index: 100; } `;
                }
                this.editor = new Jodit('#inline-approval-editor', { height: 'auto', minHeight: 1122, width: '100%', toolbarAdaptive: false, theme: 'default', iframe: true,
                    iframeStyle: `html { background: #eee; } body { font-family: sans-serif; font-size: 14px; padding: 20mm; color: #333; margin: 20px auto; box-shadow: 0 0 10px rgba(0,0,0,0.1); width: 210mm; min-height: 297mm; ${bgStyles} } ${ex}` });
                this.editor.value = p.custom_content || this.renderTemplate(tpl?.content, p);
                this.editor.events.on('change', (val) => { p.custom_content = val; this.saveApproval(); });
            });
        },
        async openNewApprovalModal() {
            this.newStandaloneApproval = { client_name: '', email: '', subject: '', items: [{service: '', price: 0}], approval_date: new Date().toISOString().split('T')[0] };
            this.showNewApprovalModal = true;
        },
        async createStandaloneApproval() {
            const res = await fetch(url('/approvals'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.newStandaloneApproval) });
            const data = await res.json();
            if(data.status === 'success') window.location.href = url('/approvals?open=' + data.id);
        },
        openPreviewModal(p) { if(p.created_at?.includes(' ')) p.created_at = p.created_at.split(' ')[0]; this.activePreview = p; },
        async updateStatus(id, status) {
            const res = await fetch(url('/approvals/status'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) });
            if ((await res.json()).status === 'success') { const pr = this.approvals.find(p => p.id === id); if(pr) pr.status = status; if(this.activePreview) this.activePreview.status = status; this.showToast('Updated'); }
        },
        openInvoiceModal(p) { this.newInvoice = { approval_id: p.id, client_name: p.client_name, email: p.email, subject: p.subject || 'Services', amount: p.amount, items: JSON.parse(JSON.stringify(p.items || [])), invoice_date: new Date().toISOString().split('T')[0], bank_id: '' }; this.submittingInvoice = false; this.showInvoiceModal = true; },
        async submitInvoice() {
            if (this.submittingInvoice) return;
            if(!this.newInvoice.bank_id) { this.showToast('Select Bank', 'error'); return; }
            this.submittingInvoice = true;
            try {
                const res = await fetch(url('/invoices'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.newInvoice) });
                const data = await res.json();
                if (data.status === 'success') { await fetch(url('/approvals/status'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id: this.newInvoice.approval_id, status: 'Invoiced' }) }); window.location.href = url('/invoices'); }
                else { this.showToast(data.message || 'Failed to create invoice', 'error'); this.submittingInvoice = false; }
            } catch (e) { this.showToast('Error creating invoice', 'error'); this.submittingInvoice = false; }
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) this.confirmModal.callback();
            this.confirmModal.show = false;
        },
        async saveApproval() { if(this.activePreview) await fetch(url('/approvals/update'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.activePreview) }); },
        async deleteApproval(id) {
            this.confirmAction('Are you sure you want to delete this approval?', async () => {
                await fetch(url('/approvals/delete'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
                this.fetchData(this.pagination.current_page);
            });
        },
        async restoreApproval(id) {
            const res = await fetch(url('/approvals/restore'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
            if ((await res.json()).status === 'success') { this.showToast('Approval restored'); this.fetchData(this.pagination.current_page); }
        },
        toggleSelectAll() { this.selected = this.selectAll ? this.filteredApprovals.map(p => p.id) : []; },
        async bulkAction(action) {
            if (this.selected.length === 0) return;
            if (action === 'delete') {
                this.confirmAction(`Delete ${this.selected.length} selected approvals?`, async () => {
                    await fetch(url('/approvals/bulk-delete'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids: this.selected }) });
                    this.fetchData(this.pagination.current_page);
                });
            } else if (action === 'approve' || action === 'reject') {
                const status = action === 'approve' ? 'Accepted' : 'Rejected';
                this.confirmAction(`${status} ${this.selected.length} selected approvals?`, async () => {
                    await fetch(url('/approvals/bulk-update'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids: this.selected, updates: { status } }) });
                    this.fetchData(this.pagination.current_page);
                });
            }
        },
renderTemplate(content, approval) {
             let r = approval.custom_content || content || '';
             const orgLogo = this.org.logo_url ? `<img src="${url(this.org.logo_url)}" style="height: 100px;">` : '';
             let sText = approval.items?.map(i => i.service).join(', ') || approval.enquiry?.service || '';
             let cPhoto = '';
             if (approval.client && approval.client.client_photo) {
                 cPhoto = `<img src="${url(approval.client.client_photo)}" style="height: 100px; border-radius: 50%;">`;
             } else if (approval.enquiry && approval.enquiry.client_photo) {
                 cPhoto = `<img src="${url(approval.enquiry.client_photo)}" style="height: 100px; border-radius: 50%;">`;
             }
             
             let itemsTable = '';
             if (approval.items && approval.items.length > 0) {
                 itemsTable = '<table style="width: 100%; border-collapse: collapse; margin-bottom: 1em; font-size: 14px;">';
                 itemsTable += '<thead><tr style="border-bottom: 2px solid #ddd; text-align: left;"><th style="padding: 8px;">Service</th><th style="padding: 8px; text-align: right;">Price</th></tr></thead>';
                 itemsTable += '<tbody>';
                 let total = 0;
                 approval.items.forEach(item => {
                     let price = parseFloat(item.price || 0);
                     total += price;
                     itemsTable += `<tr style="border-bottom: 1px solid #eee;"><td style="padding: 8px;">${item.service}</td><td style="padding: 8px; text-align: right;">₹${price.toLocaleString()}</td></tr>`;
                 });
                 itemsTable += `<tr style="font-weight: bold; font-size: 16px;"><td style="padding: 8px; text-align: right;">Total</td><td style="padding: 8px; text-align: right;">₹${total.toLocaleString()}</td></tr>`;
                 itemsTable += '</tbody></table>';
             }
             
             // Get budget text from enquiry or client
             let budgetText = '';
             if (approval.enquiry && approval.enquiry.budget_id) {
                 const budget = this.settings.budgets?.find(b => b.id === approval.enquiry.budget_id);
                 budgetText = budget ? budget.name + ' (' + budget.range + ')' : '';
             }
             
             const v = { 
                 '{{client_name}}': approval.client_name, 
                 '{{email}}': approval.email, 
                 '{{phone}}': approval.client?.phone || approval.enquiry?.phone || '', 
                 '{{address}}': approval.client?.address || approval.enquiry?.address || '', 
                 '{{state}}': approval.client?.state || approval.enquiry?.state || '', 
                 '{{budget}}': budgetText,
                 '{{approval_no}}': approval.approval_no, 
                 '{{amount}}': approval.amount, 
                 '{{date}}': approval.created_at, 
                 '{{subject}}': approval.subject, 
                 '{{service}}': sText, 
                 '{{org_name}}': this.org.name, 
                 '{{org_website}}': this.org.website,
                 '{{org_email}}': this.org.email,
                 '{{org_phone}}': this.org.phone,
                 '{{org_logo}}': orgLogo, 
                 '{{client_photo}}': cPhoto, 
                 '{{items}}': itemsTable 
             };
             for (const [k, val] of Object.entries(v)) r = r.split(k).join(val || '');
             return r;
         },
        get filteredApprovals() { return this.approvals; },
        sortBy(key) {
            if (this.sortKey === key) {
                this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                this.sortKey = key;
                this.sortOrder = 'asc';
            }
            // In a real app, you would fetch data again with sort parameters here.
        },
        showToast(msg) { this.toast.message = msg; this.toast.show = true; setTimeout(() => this.toast.show = false, 3000); }
    }));
});
</script>

</body>
</html>
