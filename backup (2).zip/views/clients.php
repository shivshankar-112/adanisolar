<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Clients - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
        [x-cloak] { display: none !important; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="clientComponent" class="min-h-screen flex flex-col" x-cloak>

    <?php 
    $activePage = 'clients';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <!-- Actions Toolbar -->
    <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4 shadow-sm sticky top-0 z-30">
        <div class="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 flex-grow">
            <div class="relative group">
                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 group-focus-within:text-blue-500 transition-colors">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </span>
                <input type="text" x-model="searchQuery" autocomplete="off" placeholder="Search clients..." class="bg-gray-50 border border-gray-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full lg:w-64 transition-all">
            </div>

            <!-- Advanced Filters -->
            <div class="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                <select x-model="filterState" @change="fetchData(1)" class="bg-gray-50 border border-gray-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none flex-shrink-0 cursor-pointer hover:bg-white transition-colors">
                    <option value="">All States</option>
                    <template x-for="st in indianStates" :key="st">
                        <option :value="st" x-text="st"></option>
                    </template>
                </select>
                
                <button type="button" @click="showTrash = !showTrash; fetchData(1)" class="flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all flex-shrink-0" :class="showTrash ? 'bg-red-100 text-red-700 shadow-inner' : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-white hover:shadow-sm'">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    <span x-text="showTrash ? 'Viewing Trash' : 'Trash'"></span>
                </button>

                <button type="button" @click="filterState=''; searchQuery=''; showTrash=false; fetchData(1)" class="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline px-2 flex-shrink-0">Reset</button>
            </div>

            <!-- Bulk Actions -->
            <div x-show="selected.length > 0" x-transition class="flex flex-wrap items-center gap-2 lg:border-l lg:pl-4 pb-1 lg:pb-0" style="display: none;">
                <span class="text-xs text-gray-500 font-bold mr-2 whitespace-nowrap bg-blue-50 px-2 py-1 rounded" x-text="selected.length + ' selected'"></span>
                <button type="button" @click="bulkDelete()" class="text-[10px] md:text-xs font-bold bg-gray-50 hover:bg-red-50 text-red-600 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-red-200 transition-all flex-shrink-0">Delete</button>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <button type="button" @click="exportToCSV()" class="flex-1 lg:flex-none justify-center bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 hover:shadow-sm transition-all flex items-center">
                <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Export
            </button>
            <button type="button" @click="addClient()" class="flex-1 lg:flex-none justify-center btn-google py-2 px-6 rounded-lg text-sm font-semibold shadow-md hover:shadow-lg transition-all flex items-center">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Add Client
            </button>
        </div>
    </div>

    <main class="flex-grow p-4 md:p-8">
        <div class="max-w-full mx-auto">
            <h1 class="text-xl md:text-2xl mb-6 md:mb-8">Clients</h1>

            <div class="card overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-3 md:px-4 py-3 w-10 md:w-12"><input type="checkbox" x-model="selectAll" @change="toggleSelectAll()" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"></th>
                                <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Client</th>
                                <th @click="sortBy('client_name')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Contact Info <span x-show="sortKey === 'client_name'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Tax IDs</th>
                                <th @click="sortBy('state')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Location <span x-show="sortKey === 'state'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <template x-for="client in clients" :key="client.id">
                                <tr class="hover:bg-gray-50 transition group">
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <input type="checkbox" :value="client.id" x-model="selected" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                                    </td>
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <div class="flex items-center">
                                            <template x-if="client.client_photo">
                                                <img :src="url(client.client_photo)" class="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover border shadow-sm mr-2 md:mr-3">
                                            </template>
                                            <template x-if="!client.client_photo">
                                                <div class="w-8 h-8 md:w-10 md:h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs md:text-sm mr-2 md:mr-3" x-text="(client.client_name || '?').charAt(0)"></div>
                                            </template>
                                            <div>
                                                <div class="text-sm font-medium text-blue-600 hover:underline cursor-pointer" @click.prevent.stop="previewClient(client)" x-text="client.client_name"></div>
                                                <div class="text-[9px] text-gray-400" x-text="'ID: ' + client.id"></div>
                                            </div>
                                        </div>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <div class="text-xs md:text-sm" x-text="client.email"></div>
                                        <div class="text-[10px] md:text-xs text-gray-500" x-text="client.phone"></div>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <div class="text-[9px] md:text-[10px] uppercase text-gray-400">PAN: <span class="text-gray-600 font-medium" x-text="client.pan || '-'"></span></div>
                                        <div class="text-[9px] md:text-[10px] uppercase text-gray-400">GST: <span class="text-gray-600 font-medium" x-text="client.gst || '-'"></span></div>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 text-xs md:text-sm text-gray-600 whitespace-nowrap">
                                        <div x-text="client.state || '-'"></div>
                                        <div class="text-[9px] md:text-[10px] text-gray-400 truncate max-w-[120px] md:max-w-[150px]" :title="client.address" x-text="client.address"></div>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 text-right space-x-1 md:space-x-2 whitespace-nowrap">
                                        <button type="button" @click.prevent.stop="previewClient(client)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">View</button>
                                        <button type="button" @click.prevent.stop="editClient(client)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">Edit</button>
                                        <?php if (\App\Services\PermissionHelper::check('enquiries', 'delete')): ?>
                                        <template x-if="!client.deleted_at">
                                            <button type="button" @click.prevent.stop="deleteClient(client.id)" class="text-gray-400 hover:text-red-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-red-50">
                                                <svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                            </button>
                                        </template>
                                        <template x-if="client.deleted_at">
                                            <button type="button" @click.prevent.stop="restoreClient(client.id)" class="text-gray-400 hover:text-green-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-green-50">
                                                <svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                                            </button>
                                        </template>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
                <template x-if="pagination.total_pages > 1">
                    <div class="px-4 py-3 border-t bg-gray-50 flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div class="text-[10px] md:text-xs text-gray-500">
                            Showing <span x-text="(pagination.current_page - 1) * pagination.per_page + 1"></span> 
                            to <span x-text="Math.min(pagination.current_page * pagination.per_page, pagination.total)"></span> 
                            of <span x-text="pagination.total"></span> entries
                        </div>
                        <div class="flex space-x-2">
                            <button @click="fetchData(pagination.current_page - 1)" :disabled="pagination.current_page <= 1" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50">Previous</button>
                            <button @click="fetchData(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.total_pages" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50">Next</button>
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </main>

    <!-- Client Preview Modal -->
    <div x-show="showPreview" class="fixed inset-0 z-50 overflow-y-auto px-4 py-6 md:p-0" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="showPreview = false" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            <div class="inline-block w-full max-w-2xl p-4 md:p-8 bg-white shadow-2xl rounded-2xl transform transition-all relative z-10" x-data="{ subTab: 'details' }">
                <div class="text-center mb-6">
                    <template x-if="activePreview?.client_photo">
                        <img :src="url(activePreview.client_photo)" class="w-16 h-16 md:w-20 md:h-20 rounded-full object-cover border-4 border-blue-50 mx-auto mb-2 shadow-md">
                    </template>
                    <template x-if="!activePreview?.client_photo">
                        <div class="w-16 h-16 md:w-20 md:h-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xl md:text-2xl mx-auto mb-2" x-text="(activePreview?.client_name || '?').charAt(0)"></div>
                    </template>
                    <h3 class="text-lg md:text-xl font-medium text-gray-900" x-text="activePreview?.client_name"></h3>
                </div>

                <div class="flex border-b mb-6 space-x-4 md:space-x-6 overflow-x-auto pb-1">
                    <button @click="subTab = 'details'" :class="subTab === 'details' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500'" class="pb-2 text-sm font-medium whitespace-nowrap">Details</button>
                    <button @click="subTab = 'emails'; fetchClientEmailLogs(activePreview.id)" :class="subTab === 'emails' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500'" class="pb-2 text-sm font-medium whitespace-nowrap">Email History</button>
                </div>
                
                <div x-show="subTab === 'details'" class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-y-6 text-sm">
                    <div>
                        <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Email</label>
                        <p class="text-blue-600 font-medium break-all" x-text="activePreview?.email"></p>
                    </div>
                    <div>
                        <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Phone</label>
                        <p class="text-gray-900 font-medium" x-text="activePreview?.phone || '-'"></p>
                    </div>
                    <div>
                        <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Location</label>
                        <p class="text-gray-900 font-medium" x-text="activePreview?.state || '-'"></p>
                    </div>
                    <div>
                        <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Address</label>
                        <p class="text-gray-900 leading-relaxed" x-text="activePreview?.address || '-'"></p>
                    </div>
                    <div>
                        <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">PAN</label>
                        <p class="text-gray-900 font-medium uppercase" x-text="activePreview?.pan || '-'"></p>
                    </div>
                    <div>
                        <label class="text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">GST Number</label>
                        <p class="text-gray-900 font-medium uppercase" x-text="activePreview?.gst || '-'"></p>
                    </div>
                </div>

                <div x-show="subTab === 'emails'" class="space-y-3">
                    <template x-for="log in clientEmailLogs" :key="log.id">
                        <div class="bg-gray-50 p-3 rounded border">
                            <div class="flex justify-between items-start mb-1">
                                <span class="text-xs font-bold text-gray-800 truncate pr-4" x-text="log.subject"></span>
                                <span class="text-[9px] text-gray-400 whitespace-nowrap" x-text="log.timestamp"></span>
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded" :class="log.status === 'sent' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'" x-text="log.status"></span>
                                <span x-show="log.error" class="text-[9px] text-red-500 italic" x-text="log.error"></span>
                            </div>
                        </div>
                    </template>
                    <template x-if="clientEmailLogs.length === 0">
                        <p class="text-center py-8 text-gray-400 italic text-sm">No email history found.</p>
                    </template>
                </div>

                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3">
                    <button type="button" @click="showPreview = false" class="w-full sm:w-auto px-6 py-2 bg-gray-100 text-gray-600 rounded-md font-medium hover:bg-gray-200 transition">Close</button>
                    <button type="button" @click="showPreview = false; editClient(activePreview)" class="w-full sm:w-auto px-6 py-2 bg-blue-600 text-white rounded-md font-medium hover:bg-blue-700 transition">Edit Details</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Client Edit Modal -->
    <div x-show="showModal" class="fixed inset-0 z-50 overflow-y-auto px-4 py-6 md:p-0" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="showModal = false" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            
            <div class="inline-block w-full max-w-2xl p-4 md:p-8 bg-white shadow-2xl rounded-2xl transform transition-all relative z-10">
                <h3 class="text-lg md:text-xl font-medium mb-6" x-text="activeClient.id ? 'Edit Client' : 'Add New Client'"></h3>
                
                <div class="space-y-4 max-h-[70vh] overflow-y-auto px-1">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Client Name*</label>
                            <input type="text" x-model="activeClient.client_name" class="w-full border-b focus:border-blue-600 outline-none py-1">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Email*</label>
                            <input type="email" x-model="activeClient.email" @blur="validateField('email')" class="w-full border-b focus:border-blue-600 outline-none py-1" :class="errors.email ? 'border-red-500' : ''">
                            <div x-show="errors.email" class="text-[10px] text-red-500" x-text="errors.email"></div>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Phone</label>
                            <input type="text" x-model="activeClient.phone" class="w-full border-b focus:border-blue-600 outline-none py-1">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">State</label>
                            <select x-model="activeClient.state" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-white">
                                <option value="">-- Select State --</option>
                                <template x-for="st in indianStates" :key="st">
                                    <option :value="st" x-text="st"></option>
                                </template>
                            </select>
                        </div>
                    </div>

                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Address</label>
                        <input type="text" x-model="activeClient.address" class="w-full border-b focus:border-blue-600 outline-none py-1">
                    </div>

                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Client Photo</label>
                        <div class="flex items-center space-x-2">
                            <template x-if="activeClient.client_photo">
                                <img :src="url(activeClient.client_photo)" class="w-10 h-10 rounded-full object-cover border">
                            </template>
                            <input type="file" @change="uploadClientPhoto" class="text-[10px] md:text-xs w-full">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">PAN</label>
                            <input type="text" x-model="activeClient.pan" maxlength="10" @input="activeClient.pan = $event.target.value.toUpperCase()" @blur="validateField('pan')" class="w-full border-b focus:border-blue-600 outline-none py-1 uppercase" :class="errors.pan ? 'border-red-500' : ''">
                            <div x-show="errors.pan" class="text-[10px] text-red-500" x-text="errors.pan"></div>
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Aadhar</label>
                            <input type="text" x-model="activeClient.aadhar" maxlength="12" @blur="validateField('aadhar')" class="w-full border-b focus:border-blue-600 outline-none py-1" :class="errors.aadhar ? 'border-red-500' : ''">
                            <div x-show="errors.aadhar" class="text-[10px] text-red-500" x-text="errors.aadhar"></div>
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">GST</label>
                            <input type="text" x-model="activeClient.gst" maxlength="15" @input="activeClient.gst = $event.target.value.toUpperCase()" @blur="validateField('gst')" class="w-full border-b focus:border-blue-600 outline-none py-1 uppercase" :class="errors.gst ? 'border-red-500' : ''">
                            <div x-show="errors.gst" class="text-[10px] text-red-500" x-text="errors.gst"></div>
                        </div>
                    </div>

                    <!-- Map Coordinates -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Latitude</label>
                            <input type="text" x-model="activeClient.latitude" @blur="validateField('latitude')" class="w-full border-b focus:border-blue-600 outline-none py-1" :class="errors.latitude ? 'border-red-500' : ''" placeholder="-90 to 90">
                            <div x-show="errors.latitude" class="text-[10px] text-red-500" x-text="errors.latitude"></div>
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Longitude</label>
                            <input type="text" x-model="activeClient.longitude" @blur="validateField('longitude')" class="w-full border-b focus:border-blue-600 outline-none py-1" :class="errors.longitude ? 'border-red-500' : ''" placeholder="-180 to 180">
                            <div x-show="errors.longitude" class="text-[10px] text-red-500" x-text="errors.longitude"></div>
                        </div>
                    </div>

                    <div class="space-y-1 bg-gray-50 p-3 md:p-4 rounded-xl border border-gray-100">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Portal Access</label>
                        <div class="mt-2">
                            <label class="text-xs font-medium text-gray-500">Login Password</label>
                            <input type="password" x-model="activeClient.password" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-transparent" placeholder="Enter password to enable/change login">
                            <p class="text-[10px] text-gray-400 mt-1 italic">Clients use their email to login to the portal.</p>
                        </div>
                    </div>
                </div>

                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3 border-t pt-6">
                    <button type="button" @click="showModal = false" class="w-full sm:w-auto px-6 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 transition">Cancel</button>
                    <button type="button" @click="saveClient()" class="w-full sm:w-auto btn-google py-2.5">Save Client</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" x-transition class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-[100]" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div @click="confirmModal.show = false" class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg font-medium mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/partials/footer.php'; ?>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('clientComponent', () => ({
        clients: <?= json_encode($clients) ?>,
        showModal: false,
        showPreview: false,
        showTrash: false,
        searchQuery: '',
        selected: [],
        selectAll: false,
        pagination: <?php echo json_encode($pagination) ?>,
        activeClient: { id: '', client_name: '', email: '', phone: '', address: '', state: '', pan: '', aadhar: '', gst: '', client_photo: '', password: '', latitude: '', longitude: '' },
        activePreview: null,
        clientEmailLogs: [],
        indianStates: ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands','Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi','Jammu and Kashmir','Ladakh','Lakshadweep','Puducherry'],
        filterState: '',
        sortKey: 'created_at',
        sortOrder: 'desc',
        errors: {},
        toast: { show: false, message: '' },
        confirmModal: { show: false, message: '', callback: null },

        async init() {
            this.$watch('searchQuery', () => this.fetchData(1));
            setTimeout(() => {
                document.querySelectorAll('input[type="text"][x-model]').forEach(el => {
                    if (el.getAttribute('x-model') === 'searchQuery') {
                        el.value = '';
                        el.dispatchEvent(new Event('input'));
                    }
                });
            }, 50);
        },

        async fetchData(page = 1) {
            const params = new URLSearchParams({
                page: page,
                q: this.searchQuery,
                state: this.filterState,
                trash: this.showTrash ? '1' : '0'
            });
            const res = await fetch(url('/clients?' + params.toString()), {
                headers: { 'Accept': 'application/json' }
            });
            const data = await res.json();
            this.pagination = {
                current_page: page,
                per_page: 25,
                total: data.total,
                total_pages: Math.ceil(data.total / 25)
            };
            this.clients = data.clients;
        },

        async fetchClientEmailLogs(clientId) {
            const res = await fetch(url('/settings/email-logs'));
            const data = await res.json();
            this.clientEmailLogs = data.logs.filter(log => log.client_id === clientId);
        },

        get filteredClients() {
            return this.clients;
        },

        toggleSelectAll() {
            this.selected = this.selectAll ? this.clients.map(c => c.id) : [];
        },
        sortBy(key) {
            if (this.sortKey === key) {
                this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                this.sortKey = key;
                this.sortOrder = 'asc';
            }
        },
        showToast(msg) {
            this.toast.message = msg;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) this.confirmModal.callback();
            this.confirmModal.show = false;
        },
        async validateField(field) {
            try {
                const res = await fetch(url('/clients/validate'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ field, value: this.activeClient[field] })
                });
                const data = await res.json();
                if (data.status === 'error') {
                    this.errors[field] = data.errors[field];
                } else {
                    delete this.errors[field];
                }
            } catch (e) { console.error(e); }
        },
        async uploadClientPhoto(event) {
            const file = event.target.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append('photo', file);

            try {
                const res = await fetch(url('/clients/upload-photo'), {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.activeClient.client_photo = data.url;
                    this.showToast('Photo uploaded successfully');
                } else {
                    this.showToast(data.message || 'Error uploading photo');
                }
            } catch (e) {
                this.showToast('Upload failed');
            }
        },
        async saveClient() {
            try {
                const res = await fetch(url('/clients'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.activeClient)
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Client saved');
                    this.showModal = false;
                    this.fetchData(this.pagination.current_page);
                } else if (data.errors) {
                    this.errors = data.errors;
                    this.showToast('Please fix the errors');
                } else {
                    this.showToast(data.message || 'Error saving client');
                }
            } catch (e) { this.showToast('Network error'); console.error(e); }
        },
        async deleteClient(id) {
            this.confirmAction('Are you sure you want to delete this client?', async () => {
                try {
                    const res = await fetch(url('/clients/delete'), {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    });
                    const data = await res.json();
                    if (data.status === 'success') {
                        this.showToast('Client deleted');
                        this.fetchData(this.pagination.current_page);
                    } else {
                        this.showToast(data.message || 'Error deleting client');
                    }
                } catch (e) { console.error(e); }
            });
        },
        async restoreClient(id) {
            try {
                const res = await fetch(url('/clients/restore'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Client restored');
                    this.fetchData(this.pagination.current_page);
                }
            } catch (e) { this.showToast('Restore failed'); }
        },
        async bulkDelete() {
            if (this.selected.length === 0) return;
            this.confirmAction(`Delete ${this.selected.length} selected clients?`, async () => {
                try {
                    const res = await fetch(url('/clients/bulk-delete'), {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ ids: this.selected })
                    });
                    if ((await res.json()).status === 'success') this.fetchData(this.pagination.current_page);
                } catch (e) { console.error(e); }
            });
        },
        addClient() {
            this.activeClient = { id: '', client_name: '', email: '', phone: '', address: '', state: '', pan: '', aadhar: '', gst: '', client_photo: '', password: '' };
            this.showModal = true;
        },
        exportToCSV() {
            if (this.clients.length === 0) return;
            const q = String.fromCharCode(34);
            const headers = ['Client Name', 'Email', 'Phone', 'PAN', 'Aadhar', 'GST', 'State', 'Address', 'Added On'];
            const rows = this.clients.map(c => [
                c.client_name,
                c.email,
                c.phone,
                c.pan,
                c.aadhar,
                c.gst,
                c.state,
                c.address,
                c.created_at
            ]);
            let csvContent = 'data:text/csv;charset=utf-8,' 
                + headers.join(',') + '\n' 
                + rows.map(r => r.map(cell => q + (cell||'').toString().split(q).join(q+q) + q).join(',')).join('\n');
            
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement('a');
            link.setAttribute('href', encodedUri);
            link.setAttribute('download', 'clients_export.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        },
        editClient(client) {
            const rawClient = JSON.parse(JSON.stringify(client));
            this.activeClient = { 
                id: '', client_name: '', email: '', phone: '', address: '', 
                state: '', pan: '', aadhar: '', gst: '', client_photo: '', password: '',
                ...rawClient
            };
            this.showModal = true;
        },
        previewClient(client) {
            this.activePreview = JSON.parse(JSON.stringify(client));
            this.showPreview = true;
        }
    }));
});
</script>

</body>
</html>
