<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24); transition: all 0.3s cubic-bezier(.25,.8,.25,1); }
        .card:hover { box-shadow: 0 14px 28px rgba(0,0,0,0.1), 0 10px 10px rgba(0,0,0,0.1); }
        .stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; items-center: center; justify-content: center; }
    </style>
</head>
<body class="text-gray-800">

<div class="min-h-screen flex flex-col">

    <?php 
    $activePage = 'dashboard';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <main class="flex-grow p-4 md:p-8 max-w-full mx-auto w-full space-y-8">
        <div class="flex items-center justify-between">
            <h1 class="text-xl md:text-2xl">Overview</h1>
            <span class="text-xs md:text-sm text-gray-500"><?php echo date('l, F j, Y'); ?></span>
        </div>

        <!-- Stats Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <div class="card p-4 md:p-6 flex items-center space-x-4">
                <div class="stat-icon bg-blue-50 text-blue-600 flex-shrink-0">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                <div>
                    <p class="text-[10px] md:text-sm text-gray-500 font-medium uppercase">Enquiries</p>
                    <p class="text-xl md:text-2xl font-medium"><?php echo $stats['total_enquiries']; ?></p>
                </div>
            </div>
            
            <div class="card p-4 md:p-6 flex items-center space-x-4">
                <div class="stat-icon bg-yellow-50 text-yellow-600 flex-shrink-0">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                <div>
                    <p class="text-[10px] md:text-sm text-gray-500 font-medium uppercase">Pending Approvals</p>
                    <p class="text-xl md:text-2xl font-medium"><?php echo $stats['pending_approvals']; ?></p>
                </div>
            </div>

            <div class="card p-4 md:p-6 flex items-center space-x-4">
                <div class="stat-icon bg-green-50 text-green-600 flex-shrink-0">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div>
                    <p class="text-[10px] md:text-sm text-gray-500 font-medium uppercase">Paid Invoices</p>
                    <p class="text-xl md:text-2xl font-medium"><?php echo $stats['paid_invoices']; ?></p>
                </div>
            </div>

            <div class="card p-4 md:p-6 flex items-center space-x-4">
                <div class="stat-icon bg-purple-50 text-purple-600 flex-shrink-0">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div>
                    <p class="text-[10px] md:text-sm text-gray-500 font-medium uppercase">Total Revenue</p>
                    <p class="text-xl md:text-2xl font-medium">$<?php echo number_format($stats['revenue']); ?></p>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Recent Activity -->
            <div class="lg:col-span-2 space-y-4">
                <h2 class="text-lg font-medium">Recent Activity</h2>
                <div class="card overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-gray-50 border-b">
                                <tr>
                                    <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Type</th>
                                    <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Reference</th>
                                    <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Client/Employee</th>
                                    <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap">Date</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y">
                                <?php foreach ($activity as $act): ?>
                                <tr class="hover:bg-gray-50 transition">
                                    <td class="px-4 md:px-6 py-4">
                                        <span class="px-2 py-1 text-[10px] rounded-full bg-gray-100 text-gray-600 font-medium whitespace-nowrap"><?php echo $act['type']; ?></span>
                                    </td>
                                    <td class="px-4 md:px-6 py-4 font-medium text-blue-600 text-sm whitespace-nowrap"><?php echo $act['no']; ?></td>
                                    <td class="px-4 md:px-6 py-4 text-sm whitespace-nowrap"><?php echo $act['desc']; ?></td>
                                    <td class="px-4 md:px-6 py-4 text-xs md:text-sm text-gray-500 whitespace-nowrap"><?php echo date('M d, H:i', strtotime($act['date'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Quick Links / Shortcuts -->
            <div class="space-y-4">
                <h2 class="text-lg font-medium">Quick Actions</h2>
                <div class="card p-4 space-y-2">
                    <a href="<?php echo url('/enquiries'); ?>" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-blue-50 text-gray-700 transition group">
                        <div class="p-2 bg-blue-100 text-blue-600 rounded-md group-hover:bg-blue-200 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                        </div>
                        <span class="font-medium text-sm md:text-base">New Enquiry</span>
                    </a>
                    <a href="<?php echo url('/settings'); ?>" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 text-gray-700 transition group">
                        <div class="p-2 bg-gray-100 text-gray-500 rounded-md group-hover:bg-gray-200 transition">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                        </div>
                        <span class="font-medium text-sm md:text-base">System Settings</span>
                    </a>
                </div>
            </div>
        </div>

    </main>

    <?php include __DIR__ . '/partials/footer.php'; ?>
</div>

</body>
</html>
