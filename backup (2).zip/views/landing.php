<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar') ?> — Franchise Opportunity - Start Your Solar Business</title>
    <meta name="description" content="Become a <?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar') ?> franchise partner. Build a profitable clean energy business with 7+ years of proven expertise. Solar & EV Charging franchise opportunity.">
    <link rel="canonical" href="<?= url('/') ?>" />
    <meta property="og:title" content="<?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar') ?> — Franchise Opportunity" />
    <meta property="og:description" content="Become a <?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar') ?> franchise partner. Build a profitable clean energy business." />
    <meta property="og:url" content="<?= url('/') ?>" />
    <meta property="og:image" content="<?= url('/web-assets/img/valmo-delivery.jpg') ?>" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:image" content="<?= url('/web-assets/img/valmo-delivery.jpg') ?>" />
    <link rel="icon" href="<?= url('/web-assets/img/favicon_dark.svg') ?>" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800;900&family=Poppins:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css">
    <style>
        :root {
            --primary-orange: #F36D21;
            --primary-orange-dark: #E05A10;
            --btn-orange: #FF6B30;
            --dark-navy: #0B1120;
            --dark-navy-light: #112240;
            --dark-navy-mid: #0D1B2A;
            --card-bg: #13203A;
            --card-bg-hover: #1A2D50;
            --white: #ffffff;
            --off-white: #F8F9FA;
            --gray-light: #e2e8f0;
            --gray-text: #a3a6ab;
            --gray-body: #cbd5e1;
            --green-success: #4ADE80;
            --gradient-orange: linear-gradient(135deg, #F38621 0%, #F36D21 100%);
            --gradient-dark: linear-gradient(180deg, #0B1120 0%, #112240 100%);
            --gradient-hero: linear-gradient(135deg, rgba(11,17,32,0.95) 0%, rgba(17,34,64,0.85) 100%);
            --gradient-card: linear-gradient(145deg, #13203A 0%, #0D1B2A 100%);
            --shadow-card: 0 8px 32px rgba(0,0,0,0.3);
            --shadow-card-hover: 0 20px 60px rgba(243,109,33,0.15);
            --radius-sm: 8px;
            --radius-md: 12px;
            --radius-lg: 16px;
            --radius-xl: 24px;
            --radius-pill: 180px;
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            --transition-slow: all 0.6s cubic-bezier(0.4, 0, 0.2, 1);
        }

        *, *::before, *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html {
            scroll-behavior: smooth;
            scroll-padding-top: 80px;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background: var(--dark-navy);
            color: var(--white);
            overflow-x: clip;
            line-height: 1.6;
        }

        .container {
            width: 100%;
            max-width: 1360px;
            margin: 0 auto;
            padding: 0 40px;
        }

        /* ===== PRELOADER ===== */
        .preloader {
            position: fixed;
            inset: 0;
            background: var(--dark-navy);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 99999;
            transition: opacity 0.5s, visibility 0.5s;
        }
        .preloader.hidden {
            opacity: 0;
            visibility: hidden;
        }
        .preloader-spinner {
            width: 60px;
            height: 60px;
            border: 3px solid rgba(243,109,33,0.2);
            border-top-color: var(--primary-orange);
            border-radius: 50%;
            animation: spin 0.8s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }

        /* ===== SCROLL PROGRESS ===== */
        .scroll-progress {
            position: fixed;
            top: 0;
            left: 0;
            height: 3px;
            background: var(--gradient-orange);
            z-index: 10001;
            transition: width 0.1s linear;
        }

        /* ===== TOP BAR ===== */
        .top-bar {
            background: rgba(11,17,32,0.95);
            border-bottom: 1px solid rgba(243,109,33,0.1);
            padding: 10px 0;
            font-size: 13px;
            backdrop-filter: blur(10px);
        }
        .top-bar .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .top-bar-left {
            display: flex;
            align-items: center;
            gap: 24px;
        }
        .top-bar-item {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--gray-text);
            text-decoration: none;
            transition: var(--transition);
        }
        .top-bar-item:hover { color: var(--primary-orange); }
        .top-bar-item i { color: var(--primary-orange); font-size: 12px; }
        .top-bar-socials {
            display: flex;
            gap: 12px;
        }
        .top-bar-socials a {
            width: 32px;
            height: 32px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(255,255,255,0.05);
            color: var(--gray-text);
            text-decoration: none;
            transition: var(--transition);
            font-size: 13px;
        }
        .top-bar-socials a:hover {
            background: var(--primary-orange);
            color: var(--white);
            transform: translateY(-2px);
        }

        /* ===== HEADER ===== */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 10000;
            transition: var(--transition);
            padding: 0;
        }
        .header.scrolled {
            background: rgba(11,17,32,0.98);
            backdrop-filter: blur(20px);
            box-shadow: 0 4px 30px rgba(0,0,0,0.3);
        }
        .header.scrolled .top-bar { display: none; }
        .header-inner {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 0;
            transition: var(--transition);
        }
        .header.scrolled .header-inner {
            padding: 10px 0;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            text-decoration: none;
        }
        .logo-icon {
            width: 44px;
            height: 44px;
            background: var(--gradient-orange);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            color: var(--white);
            font-weight: 800;
            font-family: 'Montserrat', sans-serif;
        }
        .logo-text {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 20px;
            color: var(--white);
            line-height: 1.2;
        }
        .logo-text span { color: var(--primary-orange); }

        .nav-links {
            display: flex;
            list-style: none;
            gap: 8px;
        }
        .nav-links a {
            color: var(--gray-text);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            padding: 8px 16px;
            border-radius: var(--radius-sm);
            transition: var(--transition);
            position: relative;
        }
        .nav-links a:hover,
        .nav-links a.active {
            color: var(--white);
            background: rgba(243,109,33,0.1);
        }
        .nav-links a.active::after {
            content: '';
            position: absolute;
            bottom: 2px;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 2px;
            background: var(--primary-orange);
            border-radius: 2px;
        }

        .header-cta {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 28px;
            border-radius: var(--radius-sm);
            font-family: 'Poppins', sans-serif;
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            transition: var(--transition);
            cursor: pointer;
            border: none;
            white-space: nowrap;
        }
        .btn-primary {
            background: var(--primary-orange);
            color: var(--white);
            box-shadow: 0 4px 15px rgba(243,109,33,0.3);
        }
        .btn-primary:hover {
            background: var(--primary-orange-dark);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(243,109,33,0.4);
        }
        .btn-outline {
            background: transparent;
            color: var(--primary-orange);
            border: 2px solid var(--primary-orange);
        }
        .btn-outline:hover {
            background: var(--primary-orange);
            color: var(--white);
            transform: translateY(-2px);
        }
        .btn-white {
            background: var(--white);
            color: var(--dark-navy);
        }
        .btn-white:hover {
            background: var(--primary-orange);
            color: var(--white);
            transform: translateY(-2px);
        }
        .btn-lg {
            padding: 16px 36px;
            font-size: 16px;
            border-radius: var(--radius-md);
        }

        .mobile-toggle {
            display: none;
            background: none;
            border: none;
            cursor: pointer;
            padding: 8px;
            z-index: 10001;
        }
        .hamburger {
            width: 28px;
            height: 20px;
            position: relative;
        }
        .hamburger span {
            display: block;
            width: 100%;
            height: 2px;
            background: var(--white);
            position: absolute;
            left: 0;
            transition: var(--transition);
            border-radius: 2px;
        }
        .hamburger span:nth-child(1) { top: 0; }
        .hamburger span:nth-child(2) { top: 9px; }
        .hamburger span:nth-child(3) { top: 18px; }
        .mobile-toggle.active .hamburger span:nth-child(1) { transform: rotate(45deg); top: 9px; }
        .mobile-toggle.active .hamburger span:nth-child(2) { opacity: 0; }
        .mobile-toggle.active .hamburger span:nth-child(3) { transform: rotate(-45deg); top: 9px; }

        .mobile-menu {
            position: fixed;
            top: 0;
            right: -100%;
            width: 320px;
            height: 100vh;
            background: var(--dark-navy-light);
            z-index: 10000;
            padding: 80px 32px 32px;
            transition: var(--transition-slow);
            box-shadow: -10px 0 40px rgba(0,0,0,0.5);
            overflow-y: auto;
        }
        .mobile-menu.active { right: 0; }
        .mobile-menu-overlay {
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 9999;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
        }
        .mobile-menu-overlay.active { opacity: 1; visibility: visible; }
        .mobile-menu-links {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 4px;
        }
        .mobile-menu-links a {
            display: block;
            padding: 14px 16px;
            color: var(--gray-text);
            text-decoration: none;
            font-size: 16px;
            font-weight: 500;
            border-radius: var(--radius-sm);
            transition: var(--transition);
        }
        .mobile-menu-links a:hover,
        .mobile-menu-links a.active {
            color: var(--white);
            background: rgba(243,109,33,0.1);
        }

        /* ===== HERO ===== */
        .hero {
            position: relative;
            min-height: 100vh;
            display: flex;
            align-items: center;
            overflow: hidden;
        }
        .hero-bg {
            position: absolute;
            inset: 0;
            z-index: 1;
            background: url('https://images.pexels.com/photos/10390893/pexels-photo-10390893.jpeg?auto=compress&cs=tinysrgb&w=1920') center/cover no-repeat;
        }
        .hero-bg::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(11,17,32,0.95) 0%, rgba(17,34,64,0.8) 50%, rgba(11,17,32,0.9) 100%);
        }
        .hero-video {
            position: absolute;
            top: 50%;
            left: 50%;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            transform: translate(-50%, -50%);
            object-fit: cover;
            z-index: 0;
            opacity: 0.25;
            pointer-events: none;
        }
        .hero-video::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(11,17,32,0.7) 0%, rgba(17,34,64,0.5) 50%, rgba(11,17,32,0.6) 100%);
        }
        .hero-particles {
            position: absolute;
            inset: 0;
            overflow: hidden;
            pointer-events: none;
            z-index: 3;
        }
        .particle {
            position: absolute;
            width: 4px;
            height: 4px;
            background: var(--primary-orange);
            border-radius: 50%;
            opacity: 0;
            animation: float-particle 8s infinite;
        }
        @keyframes float-particle {
            0% { opacity: 0; transform: translateY(100vh) scale(0); }
            10% { opacity: 0.6; }
            90% { opacity: 0.6; }
            100% { opacity: 0; transform: translateY(-10vh) scale(1); }
        }
        .hero-content {
            position: relative;
            z-index: 2;
            max-width: 700px;
        }
        .hero-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: var(--gradient-orange);
            padding: 8px 20px;
            border-radius: var(--radius-pill);
            font-size: 13px;
            font-weight: 600;
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-bottom: 24px;
            animation: fadeInUp 0.8s ease forwards;
        }
        .hero-badge i { font-size: 14px; }
        .hero-title {
            font-family: 'Montserrat', sans-serif;
            font-size: clamp(36px, 5vw, 68px);
            font-weight: 800;
            line-height: 1.1;
            margin-bottom: 24px;
            animation: fadeInUp 0.8s ease 0.2s forwards;
            opacity: 0;
        }
        .hero-title .highlight { color: var(--primary-orange); }
        .hero-desc {
            font-size: 18px;
            color: var(--gray-text);
            line-height: 1.7;
            margin-bottom: 40px;
            max-width: 560px;
            animation: fadeInUp 0.8s ease 0.4s forwards;
            opacity: 0;
        }
        .hero-actions {
            display: flex;
            gap: 16px;
            flex-wrap: wrap;
            animation: fadeInUp 0.8s ease 0.6s forwards;
            opacity: 0;
        }
        .hero-stats-row {
            display: flex;
            gap: 48px;
            margin-top: 64px;
            padding-top: 40px;
            border-top: 1px solid rgba(255,255,255,0.1);
            animation: fadeInUp 0.8s ease 0.8s forwards;
            opacity: 0;
        }
        .hero-stat-number {
            font-family: 'Montserrat', sans-serif;
            font-size: 36px;
            font-weight: 800;
            color: var(--primary-orange);
        }
        .hero-stat-label {
            font-size: 13px;
            color: var(--gray-text);
            margin-top: 4px;
        }
        .hero-visual {
            position: absolute;
            right: 4%;
            top: 50%;
            transform: translateY(-50%);
            width: 420px;
            height: 420px;
            z-index: 4;
            max-width: 45vw;
        }
        .hero-circle {
            position: absolute;
            border-radius: 50%;
            border: 1px solid rgba(243,109,33,0.15);
            animation: pulse-ring 4s ease-in-out infinite;
        }
        .hero-circle:nth-child(1) { width: 100%; height: 100%; top: 0; left: 0; }
        .hero-circle:nth-child(2) { width: 75%; height: 75%; top: 12.5%; left: 12.5%; animation-delay: 0.5s; }
        .hero-circle:nth-child(3) { width: 50%; height: 50%; top: 25%; left: 25%; animation-delay: 1s; }
        @keyframes pulse-ring {
            0%, 100% { opacity: 0.3; transform: scale(1); }
            50% { opacity: 0.8; transform: scale(1.02); }
        }
        .hero-float-card {
            position: absolute;
            background: rgba(19,32,58,0.9);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(243,109,33,0.2);
            border-radius: var(--radius-lg);
            padding: 16px 20px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: float 6s ease-in-out infinite;
        }
        .hero-float-card:nth-child(4) { top: 10%; right: 5%; animation-delay: 0s; }
        .hero-float-card:nth-child(5) { bottom: 25%; right: 2%; animation-delay: 2s; }
        .hero-float-card:nth-child(6) { bottom: 8%; left: 5%; animation-delay: 4s; }
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-12px); }
        }
        .float-card-icon {
            width: 40px;
            height: 40px;
            border-radius: var(--radius-sm);
            background: var(--gradient-orange);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 16px;
            flex-shrink: 0;
        }
        .float-card-text {
            font-size: 13px;
            font-weight: 600;
            line-height: 1.3;
        }
        .float-card-sub { font-size: 11px; color: var(--gray-text); font-weight: 400; }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* ===== SECTION STYLES ===== */
        .section {
            padding: 100px 0;
            position: relative;
        }
        .section-alt {
            background: var(--dark-navy-mid);
            overflow: hidden;
        }
        .section-header {
            text-align: center;
            max-width: 680px;
            margin: 0 auto 64px;
        }
        .section-badge {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: rgba(243,109,33,0.1);
            border: 1px solid rgba(243,109,33,0.2);
            padding: 6px 18px;
            border-radius: var(--radius-pill);
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1.5px;
            text-transform: uppercase;
            color: var(--primary-orange);
            margin-bottom: 16px;
        }
        .section-title {
            font-family: 'Montserrat', sans-serif;
            font-size: clamp(28px, 3.5vw, 44px);
            font-weight: 800;
            line-height: 1.15;
            margin-bottom: 16px;
        }
        .section-title .highlight { color: var(--primary-orange); }
        .section-subtitle {
            font-size: 16px;
            color: var(--gray-text);
            line-height: 1.7;
        }

        /* ===== SCROLL REVEAL ===== */
        .reveal {
            opacity: 0;
            transform: translateY(40px);
            transition: all 0.8s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        .reveal-delay-1 { transition-delay: 0.1s; }
        .reveal-delay-2 { transition-delay: 0.2s; }
        .reveal-delay-3 { transition-delay: 0.3s; }
        .reveal-delay-4 { transition-delay: 0.4s; }

        /* ===== COUNTER STATS ===== */
        .stats-bar {
            background: var(--gradient-card);
            border: 1px solid rgba(243,109,33,0.1);
            border-radius: var(--radius-xl);
            padding: 48px;
            margin-top: -50px;
            position: relative;
            z-index: 5;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 32px;
            box-shadow: var(--shadow-card);
        }
        .stat-item {
            text-align: center;
            padding: 20px 0;
            position: relative;
        }
        .stat-item:not(:last-child)::after {
            content: '';
            position: absolute;
            right: 0;
            top: 50%;
            transform: translateY(-50%);
            height: 50px;
            width: 1px;
            background: rgba(255,255,255,0.1);
        }
        .stat-icon {
            width: 56px;
            height: 56px;
            margin: 0 auto 16px;
            background: rgba(243,109,33,0.1);
            border-radius: var(--radius-md);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: var(--primary-orange);
            transition: var(--transition);
        }
        .stat-item:hover .stat-icon {
            background: var(--primary-orange);
            color: var(--white);
            transform: scale(1.1);
        }
        .stat-number {
            font-family: 'Montserrat', sans-serif;
            font-size: 36px;
            font-weight: 800;
            color: var(--white);
            line-height: 1;
        }
        .stat-number span { color: var(--primary-orange); }
        .stat-label {
            font-size: 14px;
            color: var(--gray-text);
            margin-top: 8px;
        }

        /* ===== FRANCHISE MODELS ===== */
        .models-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
        }
        .model-card {
            background: var(--gradient-card);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: var(--radius-lg);
            padding: 36px 28px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }
        .model-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: var(--gradient-orange);
            transform: scaleX(0);
            transition: var(--transition);
        }
        .model-card:hover::before { transform: scaleX(1); }
        .model-card:hover {
            border-color: rgba(243,109,33,0.2);
            transform: translateY(-8px);
            box-shadow: var(--shadow-card-hover);
        }
        .model-card.featured {
            border-color: rgba(243,109,33,0.3);
            background: linear-gradient(145deg, rgba(243,109,33,0.08) 0%, var(--card-bg) 100%);
        }
        .model-card.featured::before { transform: scaleX(1); }
        .model-tag {
            display: inline-block;
            background: var(--gradient-orange);
            padding: 4px 12px;
            border-radius: var(--radius-pill);
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 16px;
        }
        .model-icon {
            width: 64px;
            height: 64px;
            border-radius: var(--radius-md);
            background: rgba(243,109,33,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: var(--primary-orange);
            margin-bottom: 20px;
            transition: var(--transition);
        }
        .model-card:hover .model-icon {
            background: var(--primary-orange);
            color: var(--white);
        }
        .model-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 18px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .model-price {
            font-family: 'Montserrat', sans-serif;
            font-size: 28px;
            font-weight: 800;
            color: var(--primary-orange);
            margin-bottom: 4px;
        }
        .model-price-note {
            font-size: 12px;
            color: var(--gray-text);
            margin-bottom: 20px;
        }
        .model-features {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 28px;
        }
        .model-features li {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 13px;
            color: var(--gray-body);
        }
        .model-features li i {
            color: var(--green-success);
            font-size: 12px;
            flex-shrink: 0;
        }

        /* ===== HOW IT WORKS ===== */
        .steps-timeline {
            position: relative;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 32px;
        }
        .steps-timeline::before {
            content: '';
            position: absolute;
            top: 40px;
            left: 12.5%;
            right: 12.5%;
            height: 2px;
            background: linear-gradient(90deg, var(--primary-orange), rgba(243,109,33,0.2));
        }
        .step-item {
            text-align: center;
            position: relative;
        }
        .step-number {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            background: var(--dark-navy);
            border: 2px solid rgba(243,109,33,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 24px;
            position: relative;
            z-index: 2;
            transition: var(--transition);
        }
        .step-number-inner {
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: var(--gradient-orange);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Montserrat', sans-serif;
            font-size: 22px;
            font-weight: 800;
            color: var(--white);
        }
        .step-item:hover .step-number {
            border-color: var(--primary-orange);
            box-shadow: 0 0 30px rgba(243,109,33,0.3);
        }
        .step-icon {
            font-size: 28px;
            color: var(--primary-orange);
            margin-bottom: 12px;
        }
        .step-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 8px;
        }
        .step-desc {
            font-size: 13px;
            color: var(--gray-text);
            line-height: 1.6;
        }

        /* ===== BENEFITS ===== */
        .benefits-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 24px;
        }
        .benefit-card {
            background: var(--gradient-card);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: var(--radius-lg);
            padding: 36px 28px;
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }
        .benefit-card::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: var(--gradient-orange);
            transform: scaleX(0);
            transition: var(--transition);
        }
        .benefit-card:hover::after { transform: scaleX(1); }
        .benefit-card:hover {
            border-color: rgba(243,109,33,0.2);
            transform: translateY(-6px);
            box-shadow: var(--shadow-card-hover);
        }
        .benefit-icon {
            width: 56px;
            height: 56px;
            border-radius: var(--radius-md);
            background: rgba(243,109,33,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: var(--primary-orange);
            margin-bottom: 20px;
            transition: var(--transition);
        }
        .benefit-card:hover .benefit-icon {
            background: var(--primary-orange);
            color: var(--white);
            transform: rotate(-5deg) scale(1.1);
        }
        .benefit-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 17px;
            font-weight: 700;
            margin-bottom: 10px;
        }
        .benefit-desc {
            font-size: 14px;
            color: var(--gray-text);
            line-height: 1.7;
        }

        /* ===== INVESTMENT OVERVIEW ===== */
        .invest-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 24px;
        }
        .invest-card {
            background: var(--gradient-card);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: var(--radius-lg);
            padding: 32px 24px;
            text-align: center;
            transition: var(--transition);
        }
        .invest-card:hover {
            border-color: rgba(243,109,33,0.2);
            transform: translateY(-6px);
        }
        .invest-icon {
            width: 64px;
            height: 64px;
            margin: 0 auto 16px;
            border-radius: 50%;
            background: rgba(243,109,33,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            color: var(--primary-orange);
        }
        .invest-value {
            font-family: 'Montserrat', sans-serif;
            font-size: 28px;
            font-weight: 800;
            color: var(--primary-orange);
            margin-bottom: 4px;
        }
        .invest-label {
            font-size: 14px;
            color: var(--gray-text);
        }

        /* ===== TESTIMONIALS ===== */
        .testimonials-wrapper {
            position: relative;
        }
        .swiper-testimonials {
            padding: 20px 0 60px;
        }
        .testimonial-card {
            background: var(--dark-navy-light);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: var(--radius-lg);
            padding: 32px;
            height: 100%;
            transition: var(--transition);
            position: relative;
        }
        .testimonial-card:hover {
            border-color: rgba(243,109,33,0.2);
            box-shadow: 0 20px 40px rgba(0,0,0,0.08);
        }
        .testimonial-stars {
            display: flex;
            gap: 4px;
            margin-bottom: 16px;
        }
        .testimonial-stars i {
            color: var(--primary-orange);
            font-size: 14px;
        }
        .testimonial-text {
            font-size: 15px;
            line-height: 1.7;
            color: var(--gray-body);
            margin-bottom: 24px;
            font-style: italic;
        }
        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-top: 20px;
            border-top: 1px solid rgba(255,255,255,0.08);
        }
        .testimonial-avatar {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: var(--gradient-orange);
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            font-size: 16px;
            color: var(--white);
            flex-shrink: 0;
        }
        .testimonial-name {
            font-weight: 600;
            font-size: 14px;
        }
        .testimonial-role {
            font-size: 12px;
            color: var(--gray-text);
        }

        /* ===== FAQ ===== */
        .faq-list {
            max-width: 800px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .faq-item {
            background: var(--gradient-card);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: var(--radius-md);
            overflow: hidden;
            transition: var(--transition);
        }
        .faq-item.active {
            border-color: rgba(243,109,33,0.2);
        }
        .faq-question {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 20px 24px;
            cursor: pointer;
            font-weight: 600;
            font-size: 15px;
            transition: var(--transition);
            gap: 16px;
        }
        .faq-question:hover { color: var(--primary-orange); }
        .faq-question i {
            font-size: 14px;
            color: var(--primary-orange);
            transition: var(--transition);
            flex-shrink: 0;
        }
        .faq-item.active .faq-question i {
            transform: rotate(180deg);
        }
        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        .faq-answer-inner {
            padding: 0 24px 20px;
            font-size: 14px;
            color: var(--gray-text);
            line-height: 1.7;
        }

        /* ===== CTA SECTION ===== */
        .cta-section {
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }
        .cta-bg {
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, var(--primary-orange) 0%, #E05A10 100%);
        }
        .cta-bg::before {
            content: '';
            position: absolute;
            inset: 0;
            background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="rgba(255,255,255,0.05)" d="M0,96L48,112C96,128,192,160,288,165.3C384,171,480,149,576,128C672,107,768,85,864,90.7C960,96,1056,128,1152,138.7C1248,149,1344,139,1392,133.3L1440,128L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>') bottom/cover no-repeat;
        }
        .cta-bg-image {
            position: absolute;
            inset: 0;
            background: url('https://images.pexels.com/photos/12067501/pexels-photo-12067501.jpeg?auto=compress&cs=tinysrgb&w=1920') center/cover no-repeat;
            opacity: 0.2;
        }
        .cta-content {
            position: relative;
            z-index: 2;
            text-align: center;
            max-width: 700px;
            margin: 0 auto;
        }
        .cta-title {
            font-family: 'Montserrat', sans-serif;
            font-size: clamp(28px, 3.5vw, 44px);
            font-weight: 800;
            color: var(--white);
            margin-bottom: 16px;
        }
        .cta-desc {
            font-size: 18px;
            color: rgba(255,255,255,0.9);
            margin-bottom: 36px;
        }
        .cta-actions {
            display: flex;
            gap: 16px;
            justify-content: center;
            flex-wrap: wrap;
        }
        .btn-dark {
            background: var(--dark-navy);
            color: var(--white);
        }
        .btn-dark:hover {
            background: var(--dark-navy-light);
            transform: translateY(-2px);
        }

        /* ===== CONTACT FORM ===== */
        .contact-grid {
            display: grid;
            grid-template-columns: 1fr 1.2fr;
            gap: 48px;
            align-items: start;
        }
        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 32px;
        }
        .contact-info-item {
            display: flex;
            gap: 16px;
            align-items: flex-start;
        }
        .contact-info-icon {
            width: 48px;
            height: 48px;
            border-radius: var(--radius-md);
            background: rgba(243,109,33,0.1);
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-orange);
            font-size: 18px;
            flex-shrink: 0;
        }
        .contact-info-label {
            font-size: 12px;
            color: var(--gray-text);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 4px;
        }
        .contact-info-value {
            font-size: 15px;
            font-weight: 500;
        }
        .contact-form {
            background: var(--gradient-card);
            border: 1px solid rgba(255,255,255,0.06);
            border-radius: var(--radius-xl);
            padding: 40px;
        }
        .form-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 22px;
            font-weight: 700;
            margin-bottom: 24px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full { grid-column: 1 / -1; }
        .form-label {
            font-size: 11px;
            font-weight: 700;
            color: var(--gray-text);
            text-transform: uppercase;
            letter-spacing: 1px;
            margin-bottom: 6px;
        }
        .form-input,
        .form-select,
        .form-textarea {
            width: 100%;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: var(--radius-sm);
            padding: 12px 16px;
            color: var(--white);
            font-family: 'Poppins', sans-serif;
            font-size: 14px;
            outline: none;
            transition: var(--transition);
        }
        .form-input:focus,
        .form-select:focus,
        .form-textarea:focus {
            border-color: var(--primary-orange);
            box-shadow: 0 0 0 3px rgba(243,109,33,0.1);
        }
        .form-input::placeholder,
        .form-textarea::placeholder {
            color: rgba(255,255,255,0.3);
        }
        .form-select {
            appearance: none;
            background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%23a3a6ab' viewBox='0 0 16 16'%3E%3Cpath d='M8 11L3 6h10z'/%3E%3C/svg%3E");
            background-repeat: no-repeat;
            background-position: right 12px center;
            padding-right: 36px;
        }
        .form-select option {
            background: var(--dark-navy-light);
            color: var(--white);
        }
        .form-textarea {
            resize: vertical;
            min-height: 100px;
        }
        .form-submit {
            grid-column: 1 / -1;
            margin-top: 8px;
        }

        /* ===== FOOTER ===== */
        .footer {
            background: var(--dark-navy-mid);
            border-top: 1px solid rgba(255,255,255,0.06);
            padding: 80px 0 0;
        }
        .footer-grid {
            display: grid;
            grid-template-columns: 1.5fr 1fr 1fr 1.5fr;
            gap: 48px;
            padding-bottom: 60px;
        }
        .footer-brand p {
            font-size: 14px;
            color: var(--gray-text);
            line-height: 1.7;
            margin-top: 16px;
        }
        .footer-heading {
            font-family: 'Montserrat', sans-serif;
            font-size: 16px;
            font-weight: 700;
            margin-bottom: 24px;
        }
        .footer-links {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }
        .footer-links a {
            color: var(--gray-text);
            text-decoration: none;
            font-size: 14px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .footer-links a::before {
            content: '';
            width: 0;
            height: 1px;
            background: var(--primary-orange);
            transition: var(--transition);
        }
        .footer-links a:hover {
            color: var(--primary-orange);
            padding-left: 4px;
        }
        .footer-links a:hover::before { width: 12px; }
        .footer-contact-item {
            display: flex;
            gap: 12px;
            margin-bottom: 16px;
            align-items: flex-start;
        }
        .footer-contact-item i {
            color: var(--primary-orange);
            margin-top: 4px;
            width: 16px;
            flex-shrink: 0;
        }
        .footer-contact-item span {
            font-size: 14px;
            color: var(--gray-text);
            line-height: 1.6;
        }
        .footer-bottom {
            border-top: 1px solid rgba(255,255,255,0.06);
            padding: 24px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .footer-copyright {
            font-size: 13px;
            color: var(--gray-text);
        }
        .footer-bottom-socials {
            display: flex;
            gap: 12px;
        }
        .footer-bottom-socials a {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(255,255,255,0.05);
            color: var(--gray-text);
            text-decoration: none;
            transition: var(--transition);
        }
        .footer-bottom-socials a:hover {
            background: var(--primary-orange);
            color: var(--white);
            transform: translateY(-2px);
        }

        /* ===== SCROLL TO TOP ===== */
        .scroll-top {
            position: fixed;
            bottom: 32px;
            right: 32px;
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: var(--primary-orange);
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            cursor: pointer;
            border: none;
            z-index: 999;
            opacity: 0;
            visibility: hidden;
            transform: translateY(20px);
            transition: var(--transition);
            box-shadow: 0 4px 20px rgba(243,109,33,0.4);
        }
        .scroll-top.visible {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }
        .scroll-top:hover {
            background: var(--primary-orange-dark);
            transform: translateY(-4px);
        }

        /* ===== WHATSAPP FAB ===== */
        .whatsapp-fab {
            position: fixed;
            bottom: 32px;
            left: 32px;
            width: 56px;
            height: 56px;
            border-radius: 50%;
            background: #25D366;
            color: var(--white);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            text-decoration: none;
            z-index: 999;
            box-shadow: 0 4px 20px rgba(37,211,102,0.4);
            transition: var(--transition);
            animation: whatsapp-pulse 2s infinite;
        }
        .whatsapp-fab:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 30px rgba(37,211,102,0.5);
        }
        @keyframes whatsapp-pulse {
            0% { box-shadow: 0 0 0 0 rgba(37,211,102,0.4); }
            70% { box-shadow: 0 0 0 15px rgba(37,211,102,0); }
            100% { box-shadow: 0 0 0 0 rgba(37,211,102,0); }
        }

        /* ===== CURSOR GLOW ===== */
        .cursor-glow {
            position: fixed;
            width: 300px;
            height: 300px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(243,109,33,0.06) 0%, transparent 70%);
            pointer-events: none;
            z-index: 9998;
            transform: translate(-50%, -50%);
            transition: transform 0.1s ease;
        }

        /* ===== IMAGE GALLERY STRIP ===== */
        .gallery-strip {
            padding: 0 0 60px;
            position: relative;
            overflow: hidden;
        }
        .gallery-strip-inner {
            display: flex;
            gap: 16px;
            animation: scrollGallery 30s linear infinite;
        }
        .gallery-strip-item {
            flex-shrink: 0;
            width: 320px;
            height: 200px;
            border-radius: var(--radius-lg);
            overflow: hidden;
            position: relative;
        }
        .gallery-strip-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s ease;
        }
        .gallery-strip-item:hover img {
            transform: scale(1.1);
        }
        .gallery-strip-item::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, transparent 40%, rgba(11,17,32,0.6) 100%);
        }
        .gallery-strip-label {
            position: absolute;
            bottom: 12px;
            left: 16px;
            z-index: 2;
            font-size: 12px;
            font-weight: 600;
            color: var(--white);
            display: flex;
            align-items: center;
            gap: 6px;
        }
        .gallery-strip-label i { color: var(--primary-orange); font-size: 10px; }
        @keyframes scrollGallery {
            0% { transform: translateX(0); }
            100% { transform: translateX(-50%); }
        }

        /* ===== WHY SOLAR VISUAL SECTION ===== */
        .why-solar {
            padding: 100px 0;
            position: relative;
            overflow: hidden;
        }
        .why-solar-bg {
            position: absolute;
            inset: 0;
            background: url('https://images.pexels.com/photos/11644973/pexels-photo-11644973.jpeg?auto=compress&cs=tinysrgb&w=1920') center/cover no-repeat;
        }
        .why-solar-bg::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(11,17,32,0.92) 0%, rgba(17,34,64,0.88) 100%);
        }
        .why-solar-content {
            position: relative;
            z-index: 2;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 64px;
            align-items: center;
        }
        .why-solar-text .section-badge { margin-bottom: 16px; }
        .why-solar-text .section-title { text-align: left; margin-bottom: 20px; }
        .why-solar-text .section-subtitle { text-align: left; margin-bottom: 32px; }
        .why-solar-list {
            list-style: none;
            display: flex;
            flex-direction: column;
            gap: 16px;
            margin-bottom: 36px;
        }
        .why-solar-list li {
            display: flex;
            align-items: flex-start;
            gap: 14px;
            font-size: 15px;
            color: var(--gray-body);
            line-height: 1.6;
        }
        .why-solar-list li .list-check {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: rgba(243,109,33,0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: var(--primary-orange);
            font-size: 12px;
            margin-top: 2px;
        }
        .why-solar-images {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }
        .why-solar-img {
            border-radius: var(--radius-lg);
            overflow: hidden;
            position: relative;
        }
        .why-solar-img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.6s ease;
        }
        .why-solar-img:hover img {
            transform: scale(1.05);
        }
        .why-solar-img:nth-child(1) { height: 240px; }
        .why-solar-img:nth-child(2) { height: 240px; margin-top: 32px; }
        .why-solar-img:nth-child(3) { height: 180px; margin-top: 0; }
        .why-solar-img:nth-child(4) { height: 180px; }
        .why-solar-img::after {
            content: '';
            position: absolute;
            inset: 0;
            border: 1px solid rgba(243,109,33,0.15);
            border-radius: var(--radius-lg);
            pointer-events: none;
        }

        /* ===== MODEL CARD IMAGES ===== */
        .model-card-image {
            width: 100%;
            height: 140px;
            border-radius: var(--radius-md);
            overflow: hidden;
            margin-bottom: 20px;
            position: relative;
        }
        .model-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.6s ease;
        }
        .model-card:hover .model-card-image img {
            transform: scale(1.08);
        }
        .model-card-image::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, transparent 50%, rgba(11,17,32,0.5) 100%);
        }

        /* ===== HOW IT WORKS BG IMAGE ===== */
        .how-it-works-bg {
            position: absolute;
            inset: 0;
            background: url('https://images.pexels.com/photos/11815854/pexels-photo-11815854.jpeg?auto=compress&cs=tinysrgb&w=1920') center/cover no-repeat;
            opacity: 0.08;
        }

        /* ===== SHOWCASE / PROJECTS GRID ===== */
        .showcase-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            grid-template-rows: auto auto;
            gap: 16px;
        }
        .showcase-item {
            border-radius: var(--radius-lg);
            overflow: hidden;
            position: relative;
            cursor: pointer;
        }
        .showcase-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
            transition: transform 0.6s ease;
        }
        .showcase-item:hover img {
            transform: scale(1.08);
        }
        .showcase-item::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(180deg, transparent 40%, rgba(11,17,32,0.8) 100%);
            transition: var(--transition);
        }
        .showcase-item:hover::after {
            background: linear-gradient(180deg, transparent 20%, rgba(243,109,33,0.4) 100%);
        }
        .showcase-item-content {
            position: absolute;
            bottom: 0;
            left: 0;
            right: 0;
            padding: 20px;
            z-index: 2;
            transform: translateY(10px);
            transition: var(--transition);
        }
        .showcase-item:hover .showcase-item-content {
            transform: translateY(0);
        }
        .showcase-item-tag {
            display: inline-block;
            background: var(--gradient-orange);
            padding: 3px 10px;
            border-radius: var(--radius-pill);
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }
        .showcase-item-title {
            font-family: 'Montserrat', sans-serif;
            font-size: 14px;
            font-weight: 700;
        }
        .showcase-item:nth-child(1) { grid-column: span 2; height: 300px; }
        .showcase-item:nth-child(2) { height: 300px; }
        .showcase-item:nth-child(3) { height: 300px; }
        .showcase-item:nth-child(4) { height: 240px; }
        .showcase-item:nth-child(5) { grid-column: span 2; height: 240px; }
        .showcase-item:nth-child(6) { height: 240px; }

        /* ===== CONTACT IMAGE ===== */
        .contact-visual {
            border-radius: var(--radius-xl);
            overflow: hidden;
            position: relative;
            margin-top: 24px;
        }
        .contact-visual img {
            width: 100%;
            height: 220px;
            object-fit: cover;
            display: block;
        }
        .contact-visual::after {
            content: '';
            position: absolute;
            inset: 0;
            background: linear-gradient(135deg, rgba(243,109,33,0.15) 0%, transparent 60%);
            border-radius: var(--radius-xl);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 1280px) {
            .container { padding: 0 32px; }
            .hero-visual { width: 340px; height: 340px; right: 2%; }
            .hero-float-card { padding: 12px 16px; gap: 10px; }
            .float-card-icon { width: 34px; height: 34px; font-size: 14px; }
            .float-card-text { font-size: 12px; }
            .float-card-sub { font-size: 10px; }
        }
        @media (max-width: 1024px) {
            .container { padding: 0 24px; }
            .hero-visual { display: none; }
            .stats-bar { grid-template-columns: repeat(2, 1fr); }
            .stat-item:nth-child(2)::after { display: none; }
            .models-grid { grid-template-columns: repeat(2, 1fr); }
            .steps-timeline { grid-template-columns: repeat(2, 1fr); gap: 40px; }
            .steps-timeline::before { display: none; }
            .benefits-grid { grid-template-columns: repeat(2, 1fr); }
            .invest-grid { grid-template-columns: repeat(2, 1fr); }
            .footer-grid { grid-template-columns: repeat(2, 1fr); }
            .contact-grid { grid-template-columns: 1fr; }
            .why-solar-content { grid-template-columns: 1fr; gap: 40px; }
            .why-solar-images { max-width: 500px; }
            .showcase-grid { grid-template-columns: 1fr 1fr; }
            .showcase-item:nth-child(1) { grid-column: span 2; height: 220px; }
            .showcase-item:nth-child(2), .showcase-item:nth-child(3) { height: 220px; }
            .showcase-item:nth-child(4) { height: 180px; }
            .showcase-item:nth-child(5) { grid-column: span 2; height: 180px; }
            .showcase-item:nth-child(6) { height: 180px; }
            .nav-links, .header-cta { display: none; }
            .mobile-toggle { display: block; }
            .top-bar-left { display: none; }
        }
        @media (max-width: 768px) {
            .container { padding: 0 20px; }
            html { scroll-padding-top: 70px; }
            .section { padding: 64px 0; }
            .section-header { margin-bottom: 40px; }
            .hero { min-height: auto; padding: 120px 0 60px; }
            .hero-content { max-width: 100%; }
            .hero-title { font-size: clamp(28px, 7vw, 40px); margin-bottom: 16px; }
            .hero-desc { font-size: 15px; margin-bottom: 28px; }
            .hero-badge { font-size: 11px; padding: 6px 14px; margin-bottom: 16px; }
            .hero-stats-row { gap: 20px; margin-top: 40px; padding-top: 28px; flex-wrap: wrap; }
            .hero-stat-number { font-size: 28px; }
            .hero-stat-label { font-size: 12px; }
            .stats-bar { grid-template-columns: 1fr 1fr; padding: 28px 20px; margin-top: -40px; border-radius: var(--radius-lg); gap: 16px; }
            .stat-item { padding: 12px 0; }
            .stat-item::after { display: none !important; }
            .stat-icon { width: 44px; height: 44px; font-size: 18px; margin-bottom: 10px; }
            .stat-number { font-size: 26px; }
            .stat-label { font-size: 12px; }
            .models-grid { grid-template-columns: 1fr; max-width: 100%; }
            .model-card { padding: 24px 20px; }
            .model-card-image { height: 160px; }
            .steps-timeline { grid-template-columns: 1fr; max-width: 100%; gap: 24px; }
            .step-number { width: 64px; height: 64px; margin-bottom: 16px; }
            .step-number-inner { width: 48px; height: 48px; font-size: 18px; }
            .step-icon { font-size: 22px; margin-bottom: 8px; }
            .step-title { font-size: 15px; }
            .benefits-grid { grid-template-columns: 1fr; max-width: 100%; }
            .benefit-card { padding: 28px 20px; }
            .invest-grid { grid-template-columns: 1fr 1fr; gap: 12px; }
            .invest-card { padding: 24px 16px; }
            .invest-value { font-size: 22px; }
            .invest-icon { width: 52px; height: 52px; font-size: 22px; }
            .why-solar { padding: 64px 0; }
            .why-solar-images { grid-template-columns: 1fr; max-width: 100%; }
            .why-solar-img:nth-child(1), .why-solar-img:nth-child(2),
            .why-solar-img:nth-child(3), .why-solar-img:nth-child(4) {
                height: 180px; margin-top: 0;
            }
            .why-solar-list li { font-size: 14px; gap: 12px; }
            .showcase-grid { grid-template-columns: 1fr; }
            .showcase-item:nth-child(1), .showcase-item:nth-child(5) { grid-column: span 1; }
            .showcase-item { height: 200px !important; }
            .gallery-strip-item { width: 240px; height: 150px; }
            .testimonials-wrapper { margin: 0 -20px; padding: 0 20px; overflow: hidden; }
            .swiper-testimonials { padding: 10px 0 50px; }
            .testimonial-card { padding: 24px 20px; }
            .testimonial-text { font-size: 14px; }
            .cta-section { padding: 64px 0; }
            .contact-grid { gap: 32px; }
            .contact-form { padding: 24px 20px; border-radius: var(--radius-lg); }
            .form-title { font-size: 18px; margin-bottom: 20px; }
            .contact-visual img { height: 180px; }
            .footer { padding: 48px 0 0; }
            .footer-grid { grid-template-columns: 1fr; gap: 32px; padding-bottom: 40px; }
            .footer-bottom { flex-direction: column; gap: 16px; text-align: center; padding: 20px 0; }
            .mobile-menu { width: 85%; max-width: 320px; padding: 72px 24px 24px; }
            .scroll-top { bottom: 20px; right: 20px; width: 44px; height: 44px; }
            .whatsapp-fab { bottom: 20px; left: 20px; width: 50px; height: 50px; font-size: 24px; }
            .faq-question { padding: 16px 18px; font-size: 14px; }
            .faq-answer-inner { padding: 0 18px 16px; font-size: 13px; }
            .logo-text { font-size: 17px; }
            .logo-icon { width: 38px; height: 38px; font-size: 17px; }
            .header-inner { padding: 12px 0; }
        }
        @media (max-width: 480px) {
            .container { padding: 0 16px; }
            .section { padding: 52px 0; }
            .hero { padding: 110px 0 48px; }
            .hero-title { font-size: 26px; }
            .hero-desc { font-size: 14px; margin-bottom: 24px; }
            .hero-actions { flex-direction: column; gap: 12px; }
            .hero-actions .btn { width: 100%; justify-content: center; padding: 14px 24px; font-size: 15px; }
            .hero-stats-row { gap: 16px; }
            .hero-stat-number { font-size: 24px; }
            .stats-bar { grid-template-columns: 1fr 1fr; padding: 20px 16px; margin-top: -32px; gap: 12px; }
            .stat-number { font-size: 22px; }
            .stat-label { font-size: 11px; }
            .section-badge { font-size: 10px; padding: 5px 14px; }
            .section-title { font-size: 22px; }
            .section-subtitle { font-size: 14px; }
            .invest-grid { grid-template-columns: 1fr; }
            .model-price { font-size: 24px; }
            .model-title { font-size: 16px; }
            .benefit-title { font-size: 15px; }
            .benefit-desc { font-size: 13px; }
            .why-solar-img:nth-child(1), .why-solar-img:nth-child(2),
            .why-solar-img:nth-child(3), .why-solar-img:nth-child(4) { height: 160px; }
            .gallery-strip-item { width: 200px; height: 130px; }
            .cta-section { padding: 48px 0; }
            .cta-title { font-size: 24px; }
            .cta-desc { font-size: 15px; margin-bottom: 28px; }
            .cta-actions { flex-direction: column; align-items: stretch; }
            .cta-actions .btn { width: 100%; justify-content: center; }
            .contact-form { padding: 20px 16px; }
            .form-grid { gap: 12px; }
            .form-input, .form-select, .form-textarea { padding: 14px 16px; font-size: 15px; }
            .form-label { font-size: 10px; margin-bottom: 5px; }
            .btn-lg { padding: 14px 28px; font-size: 15px; }
            .footer-heading { font-size: 14px; margin-bottom: 16px; }
            .footer-links a { font-size: 13px; }
            .footer-contact-item span { font-size: 13px; }
            .logo-text { font-size: 17px; }
            .logo-icon { width: 38px; height: 38px; font-size: 17px; }
            .header-inner { padding: 12px 0; }
        }
        @media (max-width: 360px) {
            .hero-title { font-size: 22px; }
            .stats-bar { grid-template-columns: 1fr; }
            .stat-item:not(:last-child) { border-bottom: 1px solid rgba(255,255,255,0.06); padding-bottom: 16px; }
            .invest-grid { grid-template-columns: 1fr; }
            .hero-stat-number { font-size: 22px; }
        }
    </style>
</head>
<body>

    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <div class="preloader-spinner"></div>
    </div>

    <!-- Scroll Progress -->
    <div class="scroll-progress" id="scrollProgress"></div>

    <!-- Cursor Glow -->
    <div class="cursor-glow" id="cursorGlow"></div>

    <!-- Header -->
    <header class="header" id="header">
        <div class="top-bar">
            <div class="container">
                <div class="top-bar-left">
                    <a href="tel:+918585940056" class="top-bar-item">
                        <i class="fas fa-phone-alt"></i> +91 85859 40056
                    </a>
                    <a href="mailto:<?php echo !empty($settings['email']) ? htmlspecialchars($settings['email']) : 'info@brightfuturesolars.com'; ?>" class="top-bar-item">
                        <i class="fas fa-envelope"></i>
                        <?php echo !empty($settings['email']) ? htmlspecialchars($settings['email']) : 'info@brightfuturesolars.com'; ?>
                    </a>
                </div>
                <div class="top-bar-socials">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-x-twitter"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="header-inner">
                <a href="<?= url('/') ?>" class="logo" aria-label="<?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar'); ?> home">
                    <?php if (!empty($settings['logo_url'])): ?>
                        <img alt="Logo" src="<?= url($settings['logo_url']) ?>" style="max-height: 44px; display: block;" />
                    <?php else: ?>
                        <div class="logo-icon">☀</div>
                        <div class="logo-text">Bright<span>Future</span>Solar</div>
                    <?php endif; ?>
                </a>
                <ul class="nav-links">
                    <li><a href="#hero" class="nav-link is-selected">Home</a></li>
                    <li><a href="#models" class="nav-link">Franchise Models</a></li>
                    <li><a href="#how-it-works" class="nav-link">How It Works</a></li>
                    <li><a href="#benefits" class="nav-link">Benefits</a></li>
                    <li><a href="#testimonials" class="nav-link">Testimonials</a></li>
                    <li><a href="#faq" class="nav-link">FAQ</a></li>
                    <li><a href="<?= url('/login') ?>" class="nav-link" target="_blank">Check Status</a></li>
                </ul>
                <div class="header-cta">
                    <a href="#apply" class="btn btn-primary">Apply Now <i class="fas fa-arrow-right"></i></a>
                </div>
                <button class="mobile-toggle" id="mobileToggle" aria-label="Toggle menu">
                    <div class="hamburger">
                        <span></span>
                        <span></span>
                        <span></span>
                    </div>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="mobile-menu-overlay" id="mobileOverlay"></div>
    <div class="mobile-menu" id="mobileMenu">
        <ul class="mobile-menu-links">
            <li><a href="#hero" class="active">Home</a></li>
            <li><a href="#models">Franchise Models</a></li>
            <li><a href="#how-it-works">How It Works</a></li>
            <li><a href="#benefits">Benefits</a></li>
            <li><a href="#testimonials">Testimonials</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="<?= url('/login') ?>" class="nav-link" target="_blank" style="margin-top:12px;">Check Status</a></li>
            <li><a href="#apply" class="btn btn-primary" style="text-align:center;margin-top:12px;">Apply Now</a></li>
        </ul>
    </div>

    <!-- Hero Section -->
    <section class="hero" id="hero">
        <div class="hero-bg"></div>
        <video class="hero-video" autoplay muted loop playsinline>
            <source src="https://assets.mixkit.co/videos/43760/43760-720.mp4" type="video/mp4">
            <source src="https://assets.mixkit.co/videos/4822/4822-720.mp4" type="video/mp4">
        </video>
        <div class="hero-particles" id="heroParticles"></div>
        <div class="container">
            <div class="hero-content">
                <div class="hero-badge">
                    <i class="fas fa-bolt"></i> Business Opportunity
                </div>
                <h1 class="hero-title">
                    JOIN THE <span class="highlight">SOLAR & EV</span> REVOLUTION
                </h1>
                <p class="hero-desc">
                    Become a <?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar'); ?> franchise partner. Build a profitable clean energy business with 7+ years of proven expertise behind you.
                </p>
                <div class="hero-actions">
                    <a href="#apply" class="btn btn-primary btn-lg">
                        Start Your Franchise <i class="fas fa-arrow-right"></i>
                    </a>
                    <a href="#models" class="btn btn-outline btn-lg">
                        Explore Models <i class="fas fa-chevron-down"></i>
                    </a>
                </div>
                <div class="hero-stats-row">
                    <div>
                        <div class="hero-stat-number" data-count="7">0</div>
                        <div class="hero-stat-label">Years Experience</div>
                    </div>
                    <div>
                        <div class="hero-stat-number" data-count="500">0</div>
                        <div class="hero-stat-label">Projects Done</div>
                    </div>
                    <div>
                        <div class="hero-stat-number" data-count="98">0</div>
                        <div class="hero-stat-label">% Client Satisfaction</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero-visual">
            <div class="hero-circle"></div>
            <div class="hero-circle"></div>
            <div class="hero-circle"></div>
            <div class="hero-float-card">
                <div class="float-card-icon"><i class="fas fa-solar-panel"></i></div>
                <div>
                    <div class="float-card-text">5 MW+ Installed</div>
                    <div class="float-card-sub">Solar Capacity</div>
                </div>
            </div>
            <div class="hero-float-card">
                <div class="float-card-icon"><i class="fas fa-rupee-sign"></i></div>
                <div>
                    <div class="float-card-text">₹2L – ₹5L</div>
                    <div class="float-card-sub">Investment Range</div>
                </div>
            </div>
            <div class="hero-float-card">
                <div class="float-card-icon"><i class="fas fa-award"></i></div>
                <div>
                    <div class="float-card-text">25 Year Warranty</div>
                    <div class="float-card-sub">Panel Coverage</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Stats Bar -->
    <div class="container">
        <div class="stats-bar reveal">
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                <div class="stat-number"><span data-count="7">0</span><span>+</span></div>
                <div class="stat-label">Years Experience</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-project-diagram"></i></div>
                <div class="stat-number"><span data-count="500">0</span><span>+</span></div>
                <div class="stat-label">Projects Completed</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-bolt"></i></div>
                <div class="stat-number"><span data-count="5">0</span><span> MW+</span></div>
                <div class="stat-label">Solar Installed</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon"><i class="fas fa-smile"></i></div>
                <div class="stat-number"><span data-count="98">0</span><span>%</span></div>
                <div class="stat-label">Client Satisfaction</div>
            </div>
        </div>
    </div>

    <!-- Image Gallery Strip -->
    <div class="gallery-strip">
        <div class="gallery-strip-inner">
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/11837451/pexels-photo-11837451.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar panel field at sunset" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-solar-panel"></i> Solar Installations</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/12224996/pexels-photo-12224996.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar panels on rooftop" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-home"></i> Rooftop Systems</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/12243093/pexels-photo-12243093.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar technician at work" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-tools"></i> Professional Setup</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/12498725/pexels-photo-12498725.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Green energy landscape" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-leaf"></i> Clean Energy</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/12530460/pexels-photo-12530460.jpeg?auto=compress&cs=tinysrgb&w=640" alt="EV charging station" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-charging-station"></i> EV Charging</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/12606669/pexels-photo-12606669.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar powered home" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-home"></i> Smart Homes</div>
            </div>
            <!-- Duplicate for seamless loop -->
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/13223714/pexels-photo-13223714.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar farm aerial view" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-solar-panel"></i> Solar Farms</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/13366683/pexels-photo-13366683.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar energy solutions" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-home"></i> Energy Solutions</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/13385063/pexels-photo-13385063.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar grid system" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-tools"></i> Grid Systems</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/13545524/pexels-photo-13545524.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar maintenance" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-leaf"></i> Solar Maintenance</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/13900627/pexels-photo-13900627.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Solar power systems" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-charging-station"></i> Power Systems</div>
            </div>
            <div class="gallery-strip-item">
                <img src="https://images.pexels.com/photos/13963757/pexels-photo-13963757.jpeg?auto=compress&cs=tinysrgb&w=640" alt="Green technology" loading="lazy">
                <div class="gallery-strip-label"><i class="fas fa-home"></i> Green Tech</div>
            </div>
        </div>
    </div>

    <!-- Franchise Models -->
    <section class="section" id="models">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-handshake"></i> Franchise Models</div>
                <h2 class="section-title">CHOOSE YOUR <span class="highlight">FRANCHISE</span> PATH</h2>
                <p class="section-subtitle">Four flexible franchise models designed to match your investment capacity and business goals.</p>
            </div>
            <div class="models-grid">
                <div class="model-card reveal reveal-delay-1">
                    <div class="model-card-image">
                        <img src="https://images.pexels.com/photos/14384697/pexels-photo-14384697.jpeg?auto=compress&cs=tinysrgb&w=400" alt="Retail solar store" loading="lazy">
                    </div>
                    <div class="model-icon"><i class="fas fa-store"></i></div>
                    <h3 class="model-title">Retailer / Distributor</h3>
                    <div class="model-price">₹60,000</div>
                    <div class="model-price-note">+GST</div>
                    <ul class="model-features">
                        <li><i class="fas fa-check-circle"></i> Local territory rights</li>
                        <li><i class="fas fa-check-circle"></i> Product catalog access</li>
                        <li><i class="fas fa-check-circle"></i> Basic training program</li>
                        <li><i class="fas fa-check-circle"></i> Marketing materials</li>
                        <li><i class="fas fa-check-circle"></i> Lead sharing support</li>
                    </ul>
                    <a href="#apply" class="btn btn-outline" style="width:100%;justify-content:center;">Get Started</a>
                </div>
                <div class="model-card reveal reveal-delay-2">
                    <div class="model-card-image">
                        <img src="https://images.pexels.com/photos/14468163/pexels-photo-14468163.jpeg?auto=compress&cs=tinysrgb&w=400" alt="Smart distribution center" loading="lazy">
                    </div>
                    <div class="model-icon"><i class="fas fa-building"></i></div>
                    <h3 class="model-title">Smart Distributor</h3>
                    <div class="model-price">₹1,20,000</div>
                    <div class="model-price-note">+GST</div>
                    <ul class="model-features">
                        <li><i class="fas fa-check-circle"></i> Expanded territory</li>
                        <li><i class="fas fa-check-circle"></i> Priority lead allocation</li>
                        <li><i class="fas fa-check-circle"></i> Advanced sales training</li>
                        <li><i class="fas fa-check-circle"></i> Digital marketing support</li>
                        <li><i class="fas fa-check-circle"></i> Dedicated account manager</li>
                    </ul>
                    <a href="#apply" class="btn btn-outline" style="width:100%;justify-content:center;">Get Started</a>
                </div>
                <div class="model-card featured reveal reveal-delay-3">
                    <div class="model-tag">Most Popular</div>
                    <div class="model-card-image">
                        <img src="https://images.pexels.com/photos/14613940/pexels-photo-14613940.jpeg?auto=compress&cs=tinysrgb&w=400" alt="Master franchise solar farm" loading="lazy">
                    </div>
                    <div class="model-icon"><i class="fas fa-crown"></i></div>
                    <h3 class="model-title">Master Franchise</h3>
                    <div class="model-price">₹2,25,000</div>
                    <div class="model-price-note">+GST</div>
                    <ul class="model-features">
                        <li><i class="fas fa-check-circle"></i> City-wide exclusive rights</li>
                        <li><i class="fas fa-check-circle"></i> Sub-dealer recruitment</li>
                        <li><i class="fas fa-check-circle"></i> Complete engineering backup</li>
                        <li><i class="fas fa-check-circle"></i> Full marketing campaign</li>
                        <li><i class="fas fa-check-circle"></i> Revenue sharing model</li>
                    </ul>
                    <a href="#apply" class="btn btn-primary" style="width:100%;justify-content:center;">Get Started</a>
                </div>
                <div class="model-card reveal reveal-delay-4">
                    <div class="model-card-image">
                        <img src="https://images.pexels.com/photos/14774796/pexels-photo-14774796.jpeg?auto=compress&cs=tinysrgb&w=400" alt="Channel franchise network" loading="lazy">
                    </div>
                    <div class="model-icon"><i class="fas fa-handshake"></i></div>
                    <h3 class="model-title">Channel Franchise</h3>
                    <div class="model-price">₹5,50,000</div>
                    <div class="model-price-note">+GST</div>
                    <ul class="model-features">
                        <li><i class="fas fa-check-circle"></i> Multi-city operations</li>
                        <li><i class="fas fa-check-circle"></i> White-label branding</li>
                        <li><i class="fas fa-check-circle"></i> Full operational support</li>
                        <li><i class="fas fa-check-circle"></i> National campaign access</li>
                        <li><i class="fas fa-check-circle"></i> Premium commission tier</li>
                    </ul>
                    <a href="#apply" class="btn btn-outline" style="width:100%;justify-content:center;">Get Started</a>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works -->
    <section class="section section-alt" id="how-it-works">
        <div class="how-it-works-bg"></div>
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-route"></i> How It Works</div>
                <h2 class="section-title">START YOUR FRANCHISE IN <span class="highlight">4 SIMPLE STEPS</span></h2>
                <p class="section-subtitle">From inquiry to launch, we guide you through every step of the process.</p>
            </div>
            <div class="steps-timeline">
                <div class="step-item reveal reveal-delay-1">
                    <div class="step-number">
                        <div class="step-number-inner">1</div>
                    </div>
                    <div class="step-icon"><i class="fas fa-file-alt"></i></div>
                    <h3 class="step-title">Apply Online</h3>
                    <p class="step-desc">Fill our inquiry form with your background and target region.</p>
                </div>
                <div class="step-item reveal reveal-delay-2">
                    <div class="step-number">
                        <div class="step-number-inner">2</div>
                    </div>
                    <div class="step-icon"><i class="fas fa-phone-alt"></i></div>
                    <h3 class="step-title">Discovery Call</h3>
                    <p class="step-desc">Meet our team — understand the business model, territory, and terms.</p>
                </div>
                <div class="step-item reveal reveal-delay-3">
                    <div class="step-number">
                        <div class="step-number-inner">3</div>
                    </div>
                    <div class="step-icon"><i class="fas fa-graduation-cap"></i></div>
                    <h3 class="step-title">Sign & Train</h3>
                    <p class="step-desc">Complete our training program and set up your office with full support.</p>
                </div>
                <div class="step-item reveal reveal-delay-4">
                    <div class="step-number">
                        <div class="step-number-inner">4</div>
                    </div>
                    <div class="step-icon"><i class="fas fa-rocket"></i></div>
                    <h3 class="step-title">Launch & Earn</h3>
                    <p class="step-desc">Start operations with leads, tech support, and marketing from HQ.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Why Solar Visual Section -->
    <section class="why-solar" id="why-solar">
        <div class="why-solar-bg"></div>
        <div class="container">
            <div class="why-solar-content">
                <div class="why-solar-text reveal">
                    <div class="section-badge"><i class="fas fa-sun"></i> Why Solar</div>
                    <h2 class="section-title">POWERING INDIA'S <span class="highlight">CLEAN ENERGY</span> FUTURE</h2>
                    <p class="section-subtitle">India's most trusted Solar & EV Charger specialist. Clean energy solutions for homes, businesses, and industries across Maharashtra and beyond.</p>
                    <ul class="why-solar-list">
                        <li>
                            <span class="list-check"><i class="fas fa-check"></i></span>
                            MNRE Approved & DISCOM Certified Installer
                        </li>
                        <li>
                            <span class="list-check"><i class="fas fa-check"></i></span>
                            Tier-1 Panel Brands — Longi, Adani, Waaree & more
                        </li>
                        <li>
                            <span class="list-check"><i class="fas fa-check"></i></span>
                            PM Surya Ghar Subsidy Assistance
                        </li>
                        <li>
                            <span class="list-check"><i class="fas fa-check"></i></span>
                            ARAI Compliant EV Charger Installation
                        </li>
                    </ul>
                    <a href="#apply" class="btn btn-primary btn-lg">Start Your Journey <i class="fas fa-arrow-right"></i></a>
                </div>
                <div class="why-solar-images reveal reveal-delay-2">
                    <div class="why-solar-img">
                        <img src="https://images.pexels.com/photos/15418504/pexels-photo-15418504.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Solar panel farm" loading="lazy">
                    </div>
                    <div class="why-solar-img">
                        <img src="https://images.pexels.com/photos/15751130/pexels-photo-15751130.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Residential rooftop solar" loading="lazy">
                    </div>
                    <div class="why-solar-img">
                        <img src="https://images.pexels.com/photos/15751131/pexels-photo-15751131.jpeg?auto=compress&cs=tinysrgb&w=600" alt="EV charging station" loading="lazy">
                    </div>
                    <div class="why-solar-img">
                        <img src="https://images.pexels.com/photos/15751132/pexels-photo-15751132.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Green clean energy" loading="lazy">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Benefits -->
    <section class="section" id="benefits">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-star"></i> Why Partner</div>
                <h2 class="section-title">BENEFITS OF <span class="highlight">PARTNERING</span> WITH US</h2>
                <p class="section-subtitle">Everything you need to build a successful solar & EV charging business.</p>
            </div>
            <div class="benefits-grid">
                <div class="benefit-card reveal reveal-delay-1">
                    <div class="benefit-icon"><i class="fas fa-award"></i></div>
                    <h3 class="benefit-title">Established Brand</h3>
                    <p class="benefit-desc">7 years of credibility and 500+ happy clients as your proof of quality to new customers.</p>
                </div>
                <div class="benefit-card reveal reveal-delay-2">
                    <div class="benefit-icon"><i class="fas fa-book-open"></i></div>
                    <h3 class="benefit-title">Complete Training</h3>
                    <p class="benefit-desc">Technical, sales, and operations training for you and your entire team before launch.</p>
                </div>
                <div class="benefit-card reveal reveal-delay-3">
                    <div class="benefit-icon"><i class="fas fa-bullhorn"></i></div>
                    <h3 class="benefit-title">Marketing Support</h3>
                    <p class="benefit-desc">Branded collaterals, digital campaigns, and lead generation from our central HQ team.</p>
                </div>
                <div class="benefit-card reveal reveal-delay-1">
                    <div class="benefit-icon"><i class="fas fa-cogs"></i></div>
                    <h3 class="benefit-title">Engineering Backup</h3>
                    <p class="benefit-desc">Complex projects supported by our senior engineering team — remotely and on-site.</p>
                </div>
                <div class="benefit-card reveal reveal-delay-2">
                    <div class="benefit-icon"><i class="fas fa-charging-station"></i></div>
                    <h3 class="benefit-title">EV + Solar = Double Revenue</h3>
                    <p class="benefit-desc">Two booming markets in one franchise — maximum earning potential per territory.</p>
                </div>
                <div class="benefit-card reveal reveal-delay-3">
                    <div class="benefit-icon"><i class="fas fa-shield-alt"></i></div>
                    <h3 class="benefit-title">Exclusive Territory</h3>
                    <p class="benefit-desc">Secure your own exclusive zone with protected market rights and dedicated support.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Investment Overview -->
    <section class="section section-alt" id="investment">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-chart-line"></i> Investment Overview</div>
                <h2 class="section-title">YOUR <span class="highlight">INVESTMENT</span> AT A GLANCE</h2>
                <p class="section-subtitle">Transparent numbers to help you make an informed decision.</p>
            </div>
            <div class="invest-grid">
                <div class="invest-card reveal reveal-delay-1">
                    <div class="invest-icon"><i class="fas fa-wallet"></i></div>
                    <div class="invest-value">₹2L – ₹5L</div>
                    <div class="invest-label">Investment Range</div>
                </div>
                <div class="invest-card reveal reveal-delay-2">
                    <div class="invest-icon"><i class="fas fa-sync-alt"></i></div>
                    <div class="invest-value">12–18 Mo</div>
                    <div class="invest-label">Payback Period</div>
                </div>
                <div class="invest-card reveal reveal-delay-3">
                    <div class="invest-icon"><i class="fas fa-hand-holding-usd"></i></div>
                    <div class="invest-value">₹50K – ₹2L+</div>
                    <div class="invest-label">Monthly Earning Potential</div>
                </div>
                <div class="invest-card reveal reveal-delay-4">
                    <div class="invest-icon"><i class="fas fa-map-marked-alt"></i></div>
                    <div class="invest-value">Exclusive</div>
                    <div class="invest-label">Dedicated Territory</div>
                </div>
            </div>
        </div>
    </section>

    <!-- Showcase / Projects -->
    <section class="section" id="showcase">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-images"></i> Our Work</div>
                <h2 class="section-title">OUR WORK <span class="highlight">SPEAKS</span></h2>
                <p class="section-subtitle">From residential rooftops to large-scale commercial installations — see the projects we've delivered.</p>
            </div>
            <div class="showcase-grid reveal">
                <div class="showcase-item">
                    <img src="https://images.pexels.com/photos/16052944/pexels-photo-16052944.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Large solar farm installation" loading="lazy">
                    <div class="showcase-item-content">
                        <div class="showcase-item-tag">Commercial</div>
                        <div class="showcase-item-title">200 KW IT Office Complex — Mumbai</div>
                    </div>
                </div>
                <div class="showcase-item">
                    <img src="https://images.pexels.com/photos/16427010/pexels-photo-16427010.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Home rooftop solar system" loading="lazy">
                    <div class="showcase-item-content">
                        <div class="showcase-item-tag">Residential</div>
                        <div class="showcase-item-title">5 KW Home Rooftop System</div>
                    </div>
                </div>
                <div class="showcase-item">
                    <img src="https://images.pexels.com/photos/16659262/pexels-photo-16659262.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Society solar installation" loading="lazy">
                    <div class="showcase-item-content">
                        <div class="showcase-item-tag">Residential</div>
                        <div class="showcase-item-title">80 KW Residential Society — Pune</div>
                    </div>
                </div>
                <div class="showcase-item">
                    <img src="https://images.pexels.com/photos/16780141/pexels-photo-16780141.jpeg?auto=compress&cs=tinysrgb&w=600" alt="EV charging point" loading="lazy">
                    <div class="showcase-item-content">
                        <div class="showcase-item-tag">EV Charging</div>
                        <div class="showcase-item-title">EV Charging Hub Installation</div>
                    </div>
                </div>
                <div class="showcase-item">
                    <img src="https://images.pexels.com/photos/17762230/pexels-photo-17762230.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Industrial solar project" loading="lazy">
                    <div class="showcase-item-content">
                        <div class="showcase-item-tag">Industrial</div>
                        <div class="showcase-item-title">500 KW Industrial Plant — Nashik</div>
                    </div>
                </div>
                <div class="showcase-item">
                    <img src="https://images.pexels.com/photos/17854880/pexels-photo-17854880.jpeg?auto=compress&cs=tinysrgb&w=600" alt="Hybrid solar system" loading="lazy">
                    <div class="showcase-item-content">
                        <div class="showcase-item-tag">Hybrid</div>
                        <div class="showcase-item-title">10 KW Villa Hybrid System</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Testimonials -->
    <section class="section" id="testimonials">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-quote-left"></i> Testimonials</div>
                <h2 class="section-title">WHAT OUR <span class="highlight">PARTNERS</span> SAY</h2>
                <p class="section-subtitle">Hear from our successful franchise partners across Maharashtra.</p>
            </div>
            <div class="testimonials-wrapper reveal">
                <div class="swiper swiper-testimonials">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-stars">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                </div>
                                <p class="testimonial-text">"Joining Bright Future Solar was the best business decision I made. The training and support from the team made it easy to get started and start earning within months."</p>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar">RP</div>
                                    <div>
                                        <div class="testimonial-name">Rajesh Patil</div>
                                        <div class="testimonial-role">Master Franchise Partner — Pune</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-stars">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                </div>
                                <p class="testimonial-text">"The dual solar + EV charging model gives us an edge in the market. We are serving both residential and commercial clients with excellent margins."</p>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar">SA</div>
                                    <div>
                                        <div class="testimonial-name">Sunita Agarwal</div>
                                        <div class="testimonial-role">Smart Distributor — Mumbai</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-stars">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                </div>
                                <p class="testimonial-text">"From technical training to marketing support, everything was provided. I was able to set up my franchise and acquire 50+ customers in the first quarter."</p>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar">AK</div>
                                    <div>
                                        <div class="testimonial-name">Amit Kumar</div>
                                        <div class="testimonial-role">Channel Franchise — Nagpur</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-stars">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                </div>
                                <p class="testimonial-text">"I started as a Retailer and within a year upgraded to Smart Distributor. The growth potential with Bright Future Solar is truly remarkable."</p>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar">VM</div>
                                    <div>
                                        <div class="testimonial-name">Vikram Mehta</div>
                                        <div class="testimonial-role">Smart Distributor — Nashik</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="swiper-slide">
                            <div class="testimonial-card">
                                <div class="testimonial-stars">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                                </div>
                                <p class="testimonial-text">"The engineering backup for complex installations is a game changer. We can confidently take on large commercial projects knowing the HQ team has our back."</p>
                                <div class="testimonial-author">
                                    <div class="testimonial-avatar">PS</div>
                                    <div>
                                        <div class="testimonial-name">Priya Sharma</div>
                                        <div class="testimonial-role">Master Franchise — Thane</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ -->
    <section class="section section-alt" id="faq">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-question-circle"></i> FAQ</div>
                <h2 class="section-title">FREQUENTLY <span class="highlight">ASKED</span> QUESTIONS</h2>
                <p class="section-subtitle">Got questions? We've got answers.</p>
            </div>
            <div class="faq-list">
                <div class="faq-item active reveal reveal-delay-1">
                    <div class="faq-question">
                        <span>What is the minimum investment to start a franchise?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer" style="max-height: 200px;">
                        <div class="faq-answer-inner">
                            You can start with our Retailer/Distributor franchise starting at just ₹60,000 +GST. We also offer Smart Distributor, Master Franchise, and Channel Franchise models with progressive investment levels and earning potential.
                        </div>
                    </div>
                </div>
                <div class="faq-item reveal reveal-delay-2">
                    <div class="faq-question">
                        <span>How long does it take to recover the investment?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            Most of our franchise partners recover their initial investment within 12–18 months, depending on the territory and sales volume. With our lead generation support and marketing backing, you can start generating revenue from day one.
                        </div>
                    </div>
                </div>
                <div class="faq-item reveal reveal-delay-3">
                    <div class="faq-question">
                        <span>What training and support do you provide?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            We provide comprehensive training covering technical installation, sales techniques, operations management, and customer service. Additionally, you get ongoing engineering backup, marketing materials, digital campaigns, and a dedicated account manager.
                        </div>
                    </div>
                </div>
                <div class="faq-item reveal reveal-delay-4">
                    <div class="faq-question">
                        <span>Can I offer both solar and EV charging solutions?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            Absolutely! That's our unique advantage. All franchise partners get access to both solar installation and EV charger installation products and training, allowing you to serve two booming markets simultaneously and maximize your earning potential.
                        </div>
                    </div>
                </div>
                <div class="faq-item reveal reveal-delay-4">
                    <div class="faq-question">
                        <span>Is the territory exclusive?</span>
                        <i class="fas fa-chevron-down"></i>
                    </div>
                    <div class="faq-answer">
                        <div class="faq-answer-inner">
                            Yes, depending on the franchise model you choose, you get an exclusive territory with protected market rights. Master Franchise and Channel Franchise partners get city-wide or multi-city exclusive zones.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="cta-section">
        <div class="cta-bg"></div>
        <div class="cta-bg-image"></div>
        <div class="container">
            <div class="cta-content reveal">
                <h2 class="cta-title">READY TO BUILD YOUR <br>SOLAR BUSINESS?</h2>
                <p class="cta-desc">Limited franchise slots available in your region. Apply now to secure your territory before it's gone.</p>
                <div class="cta-actions">
                    <a href="#apply" class="btn btn-white btn-lg">
                        Apply for Franchise <i class="fas fa-arrow-right"></i>
                    </a>
                    <a href="tel:+918585940056" class="btn btn-lg" style="background:rgba(255,255,255,0.15);color:#fff;border:2px solid rgba(255,255,255,0.3);">
                        <i class="fas fa-phone-alt"></i> Call Us Now
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact / Apply Form -->
    <section class="section" id="apply">
        <div class="container">
            <div class="section-header reveal">
                <div class="section-badge"><i class="fas fa-paper-plane"></i> Apply Now</div>
                <h2 class="section-title">BECOME A <span class="highlight">PARTNER</span></h2>
                <p class="section-subtitle">Fill out the form below and our team will contact you within 24 hours.</p>
            </div>
            <div class="contact-grid">
                <div class="contact-info reveal">
                    <div class="contact-info-item">
                        <div class="contact-info-icon"><i class="fas fa-phone-alt"></i></div>
                        <div>
                            <div class="contact-info-label">Call Us</div>
                            <div class="contact-info-value">+91 85859 40056 / +91 85859 40057</div>
                        </div>
                    </div>
                    <div class="contact-info-item">
                        <div class="contact-info-icon"><i class="fas fa-envelope"></i></div>
                        <div>
                            <div class="contact-info-label">Email Us</div>
                            <div class="contact-info-value">
                                <?php echo !empty($settings['email']) ? htmlspecialchars($settings['email']) : 'info@brightfuturesolars.com'; ?>
                            </div>
                        </div>
                    </div>
                    <div class="contact-info-item">
                        <div class="contact-info-icon"><i class="fas fa-map-marker-alt"></i></div>
                        <div>
                            <div class="contact-info-label">Visit Us</div>
                            <div class="contact-info-value">
                                <?php if (!empty($settings['address'])): ?>
                                    <?php echo nl2br(htmlspecialchars($settings['address'])); ?>
                                <?php else: ?>
                                    406, 4th Floor, Neo Corporate Plaza, Opp. Kapol Banquet Hall, Ramchandra Lane Extension Road, Malad (West), Mumbai 400064
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="contact-info-item">
                        <div class="contact-info-icon"><i class="fas fa-clock"></i></div>
                        <div>
                            <div class="contact-info-label">Working Hours</div>
                            <div class="contact-info-value">Mon – Sat: 10:00 AM – 7:00 PM</div>
                        </div>
                    </div>
                    <div class="contact-visual">
                        <img src="https://images.pexels.com/photos/17965455/pexels-photo-17965455.jpeg?auto=compress&cs=tinysrgb&w=800" alt="Bright Future Solar installation" loading="lazy">
                    </div>
                </div>
                <div class="contact-form reveal reveal-delay-2">
                    <h3 class="form-title">Franchise Inquiry Form</h3>
                    <p class="form-subtitle">Submit your details and our team will contact you shortly.</p>
                    <div id="dadmin-enquiry-container"></div>
                    <script>
                        (function() {
                            const CONFIG = {
                                api_url: url('/api/enquiry'),
                                primary_color: '#F36D21',
                                success_message: 'Thank you! Your enquiry has been received.'
                            };
                            const container = document.getElementById('dadmin-enquiry-container');
                            container.innerHTML = `
                                <form id="dadmin-form" style="width: 100%;">
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                                        <div>
                                            <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">Full Name *</label>
                                            <input type="text" name="client_name" required style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05);">
                                        </div>
                                        <div>
                                            <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">Email Address *</label>
                                            <input type="email" name="email" required style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05);">
                                        </div>
                                    </div>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                                        <div>
                                            <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">Phone Number *</label>
                                            <input type="tel" name="phone" required style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05);">
                                        </div>
                                        <div>
                                            <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">City / Location *</label>
                                            <input type="text" name="address" required style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05);">
                                        </div>
                                    </div>
                                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                                        <div>
                                            <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">Interested Model *</label>
                                            <select name="service" required style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05);">
                                                <option value="" style="background: rgba(19,32,58,0.95); color: #ffffff;">Select Service</option>
                                                <?php foreach(($settings['services'] ?? []) as $svc): ?>
                                                    <option value="<?php echo htmlspecialchars($svc['name']) ?>" style="background: rgba(19,32,58,0.95); color: #ffffff;"><?php echo htmlspecialchars($svc['name']) ?></option>
                                                <?php endforeach; ?>
                                                <?php if(empty($settings['services'])): ?>
                                                    <option value="General Inquiry" style="background: rgba(19,32,58,0.95); color: #ffffff;">General Inquiry</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                        <div>
                                            <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">Investment Budget</label>
                                            <select name="budget" style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05);">
                                                <option value="" style="background: rgba(19,32,58,0.95); color: #ffffff;">Select Budget</option>
                                                <?php foreach(($settings['budgets'] ?? []) as $bdg): ?>
                                                    <option value="<?php echo htmlspecialchars($bdg['range'] ?? $bdg['name']) ?>" style="background: rgba(19,32,58,0.95); color: #ffffff;"><?php echo htmlspecialchars($bdg['range'] ?? $bdg['name']) ?></option>
                                                <?php endforeach; ?>
                                                <?php if(empty($settings['budgets'])): ?>
                                                    <option value="General Budget" style="background: rgba(19,32,58,0.95); color: #ffffff;">General Budget</option>
                                                <?php endif; ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div style="margin-bottom: 20px;">
                                        <label style="display:block; font-size: 11px; font-weight: 700; text-transform: uppercase; margin-bottom: 8px; color: #a3a6ab; letter-spacing: 0.05em;">Message</label>
                                        <textarea name="message" rows="3" style="width: 100%; padding: 12px; border: 1px solid rgba(255,255,255,0.1); border-radius: 8px; box-sizing: border-box; color: #fff; font-family: 'Poppins', sans-serif; font-size: 14px; outline: none; background: rgba(255,255,255,0.05); resize: vertical;"></textarea>
                                    </div>
                                    <button type="submit" id="dadmin-submit" style="width: 100%; padding: 16px; background: ${CONFIG.primary_color}; color: #fff; border: none; border-radius: 12px; cursor: pointer; font-weight: 700; font-size: 16px; transition: transform 0.1s, background 0.2s; margin-top: 10px;">Submit Application</button>
                                    <div id="dadmin-status" style="margin-top: 20px; font-size: 14px; text-align: center; display: none; padding: 15px; border-radius: 10px;"></div>
                                </form>
                            `;
                            const form = document.getElementById('dadmin-form');
                            const status = document.getElementById('dadmin-status');
                            const btn = document.getElementById('dadmin-submit');
                            form.addEventListener('submit', async (e) => {
                                e.preventDefault();
                                btn.disabled = true;
                                btn.innerText = 'Submitting...';
                                status.style.display = 'none';
                                const formData = new FormData(form);
                                const data = Object.fromEntries(formData.entries());
                                try {
                                    const response = await fetch(CONFIG.api_url, {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify(data)
                                    });
                                    const result = await response.json();
                                    if (result.status === 'success') {
                                        form.reset();
                                        status.innerText = CONFIG.success_message;
                                        status.style.color = '#065f46';
                                        status.style.background = '#d1fae5';
                                        status.style.display = 'block';
                                    } else {
                                        status.innerText = result.message || 'Error sending enquiry.';
                                        status.style.color = '#991b1b';
                                        status.style.background = '#fee2e2';
                                        status.style.display = 'block';
                                    }
                                } catch (err) {
                                    status.innerText = 'Connection error. Please try again.';
                                    status.style.color = '#991b1b';
                                    status.style.background = '#fee2e2';
                                    status.style.display = 'block';
                                } finally {
                                    btn.disabled = false;
                                    btn.innerText = 'Submit Application';
                                }
                            });
                        })();
                    </script>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-grid">
                <div class="footer-brand">
                    <a href="<?= url('/') ?>" class="logo" style="margin-bottom:8px; text-decoration:none;">
                        <?php if (!empty($settings['logo_url'])): ?>
                            <img alt="Logo" src="<?= url($settings['logo_url']) ?>" style="max-height: 50px; display: block;" />
                        <?php else: ?>
                            <div class="logo-icon">☀</div>
                            <div class="logo-text">Bright<span>Future</span>Solar</div>
                        <?php endif; ?>
                    </a>
                    <p>India's trusted solar energy partner with 7+ years of experience. Powering homes, businesses, and institutions with clean, affordable solar and EV charging solutions.</p>
                </div>
                <div>
                    <h4 class="footer-heading">Quick Links</h4>
                    <ul class="footer-links">
                        <li><a href="#hero">Home</a></li>
                        <li><a href="#models">Franchise Models</a></li>
                        <li><a href="#how-it-works">How It Works</a></li>
                        <li><a href="#benefits">Benefits</a></li>
                        <li><a href="#faq">FAQ</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-heading">Our Services</h4>
                    <ul class="footer-links">
                        <li><a href="#">Residential Solar</a></li>
                        <li><a href="#">Commercial Solar</a></li>
                        <li><a href="#">Industrial Solar</a></li>
                        <li><a href="#">On-Grid Systems</a></li>
                        <li><a href="#">Hybrid Systems</a></li>
                        <li><a href="#">EV Charger Installation</a></li>
                    </ul>
                </div>
                <div>
                    <h4 class="footer-heading">Contact Us</h4>
                    <div class="footer-contact-item">
                        <i class="fas fa-envelope"></i>
                        <span>
                            <?php echo !empty($settings['email']) ? htmlspecialchars($settings['email']) : 'info@brightfuturesolars.com'; ?>
                        </span>
                    </div>
                    <div class="footer-contact-item">
                        <i class="fas fa-phone-alt"></i>
                        <span>+91 85859 40056 / +91 85859 40057</span>
                    </div>
                    <div class="footer-contact-item">
                        <i class="fas fa-map-marker-alt"></i>
                        <span>
                            <?php if (!empty($settings['address'])): ?>
                                <?php echo nl2br(htmlspecialchars($settings['address'])); ?>
                            <?php else: ?>
                                406, 4th Floor, Neo Corporate Plaza, Opp. Kapol Banquet Hall, Malad (West), Mumbai 400064
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <div class="footer-copyright">&copy; <?= date('Y') ?> <?php echo htmlspecialchars($settings['org_name'] ?? 'Bright Future Solar Pvt. Ltd.'); ?>. All rights reserved.</div>
                <div class="footer-bottom-socials">
                    <a href="#" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" aria-label="Twitter"><i class="fab fa-x-twitter"></i></a>
                    <a href="#" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                    <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Scroll to Top -->
    <button class="scroll-top" id="scrollTop" aria-label="Scroll to top">
        <i class="fas fa-chevron-up"></i>
    </button>

    <!-- WhatsApp FAB -->
    <a href="https://wa.me/918585940056" target="_blank" class="whatsapp-fab" aria-label="WhatsApp">
        <i class="fab fa-whatsapp"></i>
    </a>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        // Preloader
        window.addEventListener('load', () => {
            setTimeout(() => {
                document.getElementById('preloader').classList.add('hidden');
            }, 600);
        });

        // Scroll Progress
        window.addEventListener('scroll', () => {
            const scrollTop = window.scrollY;
            const docHeight = document.documentElement.scrollHeight - window.innerHeight;
            const progress = (scrollTop / docHeight) * 100;
            document.getElementById('scrollProgress').style.width = progress + '%';
        });

        // Cursor Glow
        const cursorGlow = document.getElementById('cursorGlow');
        if (window.innerWidth > 768) {
            document.addEventListener('mousemove', (e) => {
                cursorGlow.style.left = e.clientX + 'px';
                cursorGlow.style.top = e.clientY + 'px';
            });
        }

        // Header scroll
        const header = document.getElementById('header');
        window.addEventListener('scroll', () => {
            header.classList.toggle('scrolled', window.scrollY > 50);
        });

        // Mobile menu
        const mobileToggle = document.getElementById('mobileToggle');
        const mobileMenu = document.getElementById('mobileMenu');
        const mobileOverlay = document.getElementById('mobileOverlay');

        function toggleMobile() {
            mobileToggle.classList.toggle('active');
            mobileMenu.classList.toggle('active');
            mobileOverlay.classList.toggle('active');
            document.body.style.overflow = mobileMenu.classList.contains('active') ? 'hidden' : '';
        }
        mobileToggle.addEventListener('click', toggleMobile);
        mobileOverlay.addEventListener('click', toggleMobile);
        mobileMenu.querySelectorAll('a').forEach(a => {
            a.addEventListener('click', () => {
                if (mobileMenu.classList.contains('active')) toggleMobile();
            });
        });

        // Scroll reveal
        const revealElements = document.querySelectorAll('.reveal');
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('active');
                }
            });
        }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
        revealElements.forEach(el => revealObserver.observe(el));

        // Counter animation
        function animateCount(el) {
            const target = parseInt(el.getAttribute('data-count'));
            const duration = 2000;
            const start = performance.now();
            function update(now) {
                const elapsed = now - start;
                const progress = Math.min(elapsed / duration, 1);
                const eased = 1 - Math.pow(1 - progress, 3);
                el.textContent = Math.floor(target * eased);
                if (progress < 1) requestAnimationFrame(update);
                else el.textContent = target;
            }
            requestAnimationFrame(update);
        }
        const counterObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCount(entry.target);
                    counterObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        document.querySelectorAll('[data-count]').forEach(el => counterObserver.observe(el));

        // Hero particles
        const particlesContainer = document.getElementById('heroParticles');
        for (let i = 0; i < 30; i++) {
            const particle = document.createElement('div');
            particle.classList.add('particle');
            particle.style.left = Math.random() * 100 + '%';
            particle.style.animationDelay = Math.random() * 8 + 's';
            particle.style.animationDuration = (6 + Math.random() * 6) + 's';
            particle.style.width = particle.style.height = (2 + Math.random() * 4) + 'px';
            particlesContainer.appendChild(particle);
        }

        // Swiper Testimonials
        new Swiper('.swiper-testimonials', {
            slidesPerView: 1,
            spaceBetween: 24,
            loop: true,
            autoplay: {
                delay: 4000,
                disableOnInteraction: false,
            },
            pagination: {
                el: '.swiper-pagination',
                clickable: true,
            },
            breakpoints: {
                640: { slidesPerView: 2 },
                1024: { slidesPerView: 3 },
            },
        });

        // FAQ Accordion
        document.querySelectorAll('.faq-question').forEach(question => {
            question.addEventListener('click', () => {
                const item = question.parentElement;
                const answer = item.querySelector('.faq-answer');
                const isActive = item.classList.contains('active');

                // Close all
                document.querySelectorAll('.faq-item').forEach(faq => {
                    faq.classList.remove('active');
                    faq.querySelector('.faq-answer').style.maxHeight = '0';
                });

                if (!isActive) {
                    item.classList.add('active');
                    answer.style.maxHeight = answer.scrollHeight + 'px';
                }
            });
        });

        // Scroll to top
        const scrollTopBtn = document.getElementById('scrollTop');
        window.addEventListener('scroll', () => {
            scrollTopBtn.classList.toggle('visible', window.scrollY > 500);
        });
        scrollTopBtn.addEventListener('click', () => {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });

        // Active nav link
        const sections = document.querySelectorAll('section[id]');
        window.addEventListener('scroll', () => {
            let current = '';
            sections.forEach(section => {
                const top = section.offsetTop - 150;
                if (window.scrollY >= top) current = section.getAttribute('id');
            });
            document.querySelectorAll('.nav-links a, .mobile-menu-links a').forEach(a => {
                a.classList.remove('active');
                if (a.getAttribute('href') === '#' + current) a.classList.add('active');
            });
        });
    </script>
</body>
</html>