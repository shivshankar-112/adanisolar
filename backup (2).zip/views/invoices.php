<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoices - <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?></title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <script src="<?= url('/assets/js/html2pdf.bundle.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
        @media print {
            .no-print { display: none !important; }
            body { background-color: white !important; }
            .card { box-shadow: none !important; border: none !important; }
        }
    </style>
</head>
<body class="text-gray-800">

<div x-data="invoiceManager" class="min-h-screen flex flex-col">

    <div class="no-print">
        <?php 
        $activePage = 'invoices';
        include __DIR__ . '/partials/header.php'; 
        ?>

        <!-- Actions Toolbar -->
        <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4 shadow-sm sticky top-0 z-30">
            <div class="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 flex-grow">
                <div class="relative group">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 group-focus-within:text-blue-500 transition-colors">
                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </span>
                    <input type="text" x-model="searchQuery" autocomplete="off" placeholder="Search invoices..." class="bg-gray-50 border border-gray-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full lg:w-64 transition-all">
                </div>

                <!-- Advanced Filters -->
                <div class="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                    <select x-model="filterStatus" @change="fetchData(1)" class="bg-gray-50 border border-gray-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none flex-shrink-0 cursor-pointer hover:bg-white transition-colors">
                        <option value="">All Status</option>
                        <option value="Draft">Draft</option>
                        <option value="Sent">Sent</option>
                        <option value="Paid">Paid</option>
                        <option value="Partial Paid">Partial Paid</option>
                        <option value="Overdue">Overdue</option>
                    </select>

                    <button type="button" @click="showTrash = !showTrash; fetchData(1)" class="flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all flex-shrink-0" :class="showTrash ? 'bg-red-100 text-red-700 shadow-inner' : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-white hover:shadow-sm'">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        <span x-text="showTrash ? 'Viewing Trash' : 'Trash'"></span>
                    </button>

                    <button type="button" @click="filterStatus=''; searchQuery=''; showTrash=false; fetchData(1)" class="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline px-2 flex-shrink-0">Reset</button>
                </div>
                
                <!-- Bulk Actions -->
                <div x-show="selected.length > 0" x-transition class="flex flex-wrap items-center gap-2 lg:border-l lg:pl-4 pb-1 lg:pb-0" style="display: none;">
                    <span class="text-xs text-gray-500 font-bold mr-2 whitespace-nowrap bg-blue-50 px-2 py-1 rounded" x-text="selected.length + ' selected'"></span>
                    <button type="button" @click="bulkAction('delete')" class="text-[10px] md:text-xs font-bold bg-gray-50 hover:bg-red-50 text-red-600 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-red-200 transition-all flex-shrink-0">Delete</button>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <button type="button" @click="exportToCSV()" class="flex-1 lg:flex-none justify-center bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 hover:shadow-sm transition-all flex items-center">
                    <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Export
                </button>
            </div>
        </div>

        <main class="flex-grow p-4 md:p-8">
            <div class="max-w-full mx-auto">
                <h1 class="text-xl md:text-2xl mb-4 md:mb-8">Invoices</h1>

                <div class="card overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                            <thead class="bg-gray-50 border-b">
                                <tr>
                                    <th class="px-3 md:px-4 py-3 w-10 md:w-12"><input type="checkbox" x-model="selectAll" @change="toggleSelectAll()" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"></th>
                                    <th @click="sortBy('invoice_no')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Invoice No
                                        <span x-show="sortKey === 'invoice_no'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('client_name')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Client
                                        <span x-show="sortKey === 'client_name'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('subject')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Subject
                                        <span x-show="sortKey === 'subject'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('amount')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Amount
                                        <span x-show="sortKey === 'amount'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right">Paid</th>
                                    <th @click="sortBy('status')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Status
                                        <span x-show="sortKey === 'status'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y">
                                <template x-for="invoice in invoices" :key="invoice.id">
                                    <tr class="hover:bg-gray-50 transition group">
                                        <td class="px-3 md:px-4 py-4 whitespace-nowrap"><input type="checkbox" :value="invoice.id" x-model="selected" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"></td>
                                        <td class="px-3 md:px-4 py-4 font-medium text-blue-600 whitespace-nowrap cursor-pointer hover:underline text-xs md:text-sm" @click="openPreviewModal(invoice)" x-text="invoice.invoice_no"></td>
                                        <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                            <div class="font-medium text-gray-900 text-xs md:text-sm" x-text="invoice.client_name"></div>
                                            <div class="text-[10px] md:text-xs text-gray-500" x-text="invoice.email"></div>
                                        </td>
                                        <td class="px-3 md:px-4 py-4 text-gray-600 truncate max-w-[150px] md:max-w-[200px] text-xs md:text-sm" x-text="invoice.subject"></td>
                                        <td class="px-3 md:px-4 py-4 font-medium whitespace-nowrap text-xs md:text-sm" x-text="'₹' + parseFloat(invoice.amount || 0).toLocaleString()"></td>
                                        <td class="px-3 md:px-4 py-4 text-right text-green-600 font-bold whitespace-nowrap text-xs md:text-sm" x-text="'₹' + calculatePaidAmount(invoice.id).toLocaleString()"></td>
                                        <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                            <span :class="{
                                                'bg-green-100 text-green-700': invoice.status === 'Paid',
                                                'bg-yellow-100 text-yellow-700': invoice.status === 'Partial Paid' || invoice.status === 'Sent',
                                                'bg-red-100 text-red-700': invoice.status === 'Overdue' || invoice.status === 'Cancelled',
                                                'bg-gray-100 text-gray-700': invoice.status === 'Draft'
                                            }" class="px-2 py-1 text-[9px] md:text-[10px] rounded-full font-bold uppercase" x-text="invoice.status"></span>
                                        </td>
                                        <td class="px-3 md:px-4 py-4 text-right space-x-1 md:space-x-2 whitespace-nowrap">
                                            <button type="button" @click="openPreviewModal(invoice)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">View</button>
                                            <template x-if="invoice.status !== 'Paid' && !invoice.deleted_at">
                                                <button type="button" @click="openPaymentModal(invoice)" class="text-[10px] md:text-xs text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg font-bold transition-all shadow-sm">Pay</button>
                                            </template>
                                            <?php if (\App\Services\PermissionHelper::check('invoices', 'delete')): ?>
                                                <template x-if="!invoice.deleted_at">
                                                    <button type="button" @click="deleteInvoice(invoice.id)" class="text-gray-400 hover:text-red-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-red-50"><svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                                </template>
                                                <template x-if="invoice.deleted_at">
                                                    <button type="button" @click="restoreInvoice(invoice.id)" class="text-gray-400 hover:text-green-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-green-50"><svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg></button>
                                                </template>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                    <template x-if="pagination.total_pages > 1">
                        <div class="px-4 py-3 border-t bg-gray-50 flex flex-col sm:flex-row items-center justify-between gap-3">
                            <div class="text-[10px] md:text-xs text-gray-500">
                                Showing <span x-text="(pagination.current_page - 1) * pagination.per_page + 1"></span> 
                                to <span x-text="Math.min(pagination.current_page * pagination.per_page, pagination.total)"></span> 
                                of <span x-text="pagination.total"></span> entries
                            </div>
                            <div class="flex space-x-2">
                                <button @click="fetchData(pagination.current_page - 1)" :disabled="pagination.current_page <= 1" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50">Prev</button>
                                <button @click="fetchData(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.total_pages" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50">Next</button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </main>
    </div>

    <!-- Modals -->

    <!-- New Invoice Modal -->
    <div x-show="showNewInvoiceModal" class="fixed inset-0 z-50 overflow-y-auto no-print" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 py-6 text-center">
            <div class="fixed inset-0 transition-opacity bg-black bg-opacity-25"></div>
            <div class="inline-block w-full max-w-full md:max-w-2xl p-4 md:p-8 overflow-visible text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg md:text-xl font-medium leading-6 text-gray-900 mb-6">Create New Invoice</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-4">
                        <div class="space-y-1 bg-blue-50 p-3 rounded border border-blue-100">
                            <label class="text-[10px] font-bold text-blue-700 uppercase">Existing Client</label>
                            <select @change="selectClient($event.target.value)" class="w-full border-b border-blue-300 focus:border-blue-600 outline-none py-1 bg-transparent text-sm">
                                <option value="">-- Select --</option>
                                <template x-for="c in clientsList" :key="c.id"><option :value="c.id" x-text="c.client_name"></option></template>
                            </select>
                        </div>
                        <div class="space-y-1"><label class="text-[10px] md:text-xs text-gray-500">Client Name *</label><input type="text" x-model="newStandaloneInvoice.client_name" class="w-full border-b outline-none py-1 text-sm"></div>
                        <div class="space-y-1"><label class="text-[10px] md:text-xs text-gray-500">Email *</label><input type="email" x-model="newStandaloneInvoice.email" class="w-full border-b outline-none py-1 text-sm"></div>
                        <div class="space-y-1"><label class="text-[10px] md:text-xs text-gray-500">Subject *</label><input type="text" x-model="newStandaloneInvoice.subject" class="w-full border-b outline-none py-1 text-sm font-medium"></div>
                        <div class="grid grid-cols-2 gap-4">
                            <div class="space-y-1"><label class="text-[10px] md:text-xs text-gray-500">Date *</label><input type="date" x-model="newStandaloneInvoice.invoice_date" class="w-full border-b outline-none py-1 text-xs md:text-sm"></div>
                            <div class="space-y-1"><label class="text-[10px] md:text-xs text-gray-500">Bank *</label><select x-model="newStandaloneInvoice.bank_id" class="w-full border-b outline-none py-1 bg-white text-xs md:text-sm"><option value="">-- Bank --</option><template x-for="bank in banks" :key="bank.id"><option :value="bank.id" x-text="bank.account_name"></option></template></select></div>
                        </div>
                    </div>
                    <div class="space-y-3">
                        <div class="flex justify-between items-center"><label class="text-[10px] md:text-xs font-bold text-gray-500 uppercase">Items</label><button type="button" @click="addInvoiceItem('new')" class="text-[10px] md:text-xs text-blue-600 font-bold">+ Add Service</button></div>
                        <div class="space-y-2 max-h-48 md:max-h-64 overflow-y-auto custom-scrollbar">
                            <template x-for="(item, index) in newStandaloneInvoice.items" :key="index">
                                <div class="flex items-end space-x-2 bg-blue-50 p-2 rounded border border-blue-100">
                                    <div class="flex-grow">
                                        <select x-model="item.service" class="w-full text-[10px] md:text-xs border-b border-blue-200 outline-none py-0.5 bg-transparent">
                                            <option value="">-- Select Master Service --</option>
                                            <template x-for="ms in settings.services" :key="ms.id"><option :value="ms.name" x-text="ms.name"></option></template>
                                        </select>
                                        <input type="text" x-model="item.service" class="w-full text-[9px] md:text-[10px] italic border-none p-0 bg-transparent" placeholder="Or type custom...">
                                    </div>
                                    <div class="w-16 md:w-20"><input type="number" x-model="item.price" class="w-full text-[10px] md:text-xs border-b border-blue-200 outline-none py-0.5 bg-transparent font-medium" placeholder="Price"></div>
                                    <button type="button" @click="removeInvoiceItem(index, 'new')" class="text-red-400"><svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                </div>
                            </template>
                        </div>
                        <div class="pt-4 border-t flex justify-between items-center font-bold text-sm md:text-base"><span>Total</span><span class="text-blue-600" x-text="'₹' + newStandaloneInvoice.items.reduce((sum, item) => sum + parseFloat(item.price || 0), 0).toLocaleString()"></span></div>
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-3"><button type="button" @click="showNewInvoiceModal = false" class="px-4 py-2 text-xs md:text-sm font-medium text-gray-600">Cancel</button><button type="button" @click="createStandaloneInvoice()" class="btn-google text-xs md:text-sm">Generate Invoice</button></div>
            </div>
        </div>
    </div>

    <!-- Preview Modal -->
    <div x-show="activePreview !== null" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen p-2 md:p-4 text-center">
            <div @click="activePreview = null" class="fixed inset-0 transition-opacity bg-black bg-opacity-25"></div>
<div class="inline-block w-full max-w-full lg:max-w-6xl p-4 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex flex-col md:flex-row md:justify-between md:items-center mb-6 gap-4">
                    <h3 class="text-lg md:text-xl font-medium" x-text="'Invoice: ' + (activePreview?.invoice_no || '')"></h3>
                    <div class="flex flex-wrap items-center gap-2">
                        <select x-model="activePreview.template_id" @change="renderInvoicePreview()" class="text-[10px] md:text-sm border rounded px-2 md:px-3 py-1.5 bg-white outline-none focus:ring-2 focus:ring-blue-500">
                            <option value="">-- Select Template --</option>
                            <template x-for="t in invoiceTemplates" :key="t.id"><option :value="t.id" x-text="t.name"></option></template>
                        </select>
                        <button type="button" @click="openEmailModal(activePreview)" class="bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-bold flex items-center"><svg class="w-4 h-4 mr-1 md:mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 002 2v10a2 2 0 002 2z"></path></svg>Email</button>
                        <button type="button" @click="downloadPDF(activePreview)" class="bg-gray-100 hover:bg-gray-200 px-3 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-medium">PDF</button>
                        <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-500 ml-auto md:ml-0"><svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg></button>
                    </div>
                </div>

                <div class="overflow-x-auto bg-gray-100 p-2 md:p-8 rounded-lg">
                    <div class="border shadow-inner mx-auto bg-white" id="invoice-print-area" style="width: 210mm; min-width: 210mm; padding: 20mm; color: #333; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;">
                        <template x-if="getInvoiceTemplate(activePreview)">
                            <div x-html="renderInvoiceTemplate(getInvoiceTemplate(activePreview).content, activePreview)"></div>
                        </template>
                        <template x-if="!getInvoiceTemplate(activePreview)">
                            <div class="h-[297mm] flex items-center justify-center text-gray-400 italic">No invoice template available.</div>
                        </template>
                        <div class="mt-8 pt-4 border-t-2 border-gray-800 text-center">
                            <p class="text-xs font-bold text-gray-800" x-text="settings.org_name"></p>
                            <p class="text-[10px] text-gray-500 uppercase">Authorized Signatory</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Payment Modal -->
    <div x-show="showPaymentModal" class="fixed inset-0 z-[60] overflow-y-auto no-print" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 py-6 text-center">
            <div @click="showPaymentModal = false" class="fixed inset-0 transition-opacity bg-black bg-opacity-50"></div>
            <div class="inline-block w-full max-w-md p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg md:text-xl font-medium mb-6">Record Payment</h3>
                
                <div class="bg-gray-50 p-4 rounded-lg border mb-6 space-y-2">
                    <div class="flex justify-between text-xs md:text-sm"><span class="text-gray-500">Invoice:</span><span class="font-medium" x-text="newPayment.invoice_no"></span></div>
                    <div class="flex justify-between text-xs md:text-sm"><span class="text-gray-500">Total Amount:</span><span class="font-medium" x-text="'₹' + newPayment.total_amount.toLocaleString()"></span></div>
                    <div class="flex justify-between text-xs md:text-sm"><span class="text-gray-500">Previously Paid:</span><span class="font-medium text-green-600" x-text="'₹' + newPayment.previous_paid.toLocaleString()"></span></div>
                    <div class="flex justify-between border-t pt-2 mt-2 text-sm md:text-base"><span class="text-gray-800 font-bold">Remaining Due:</span><span class="font-bold text-blue-600" x-text="'₹' + newPayment.remaining_due.toLocaleString()"></span></div>
                </div>

                <div class="space-y-4">
                    <div class="space-y-1">
                        <label class="text-[10px] md:text-xs font-medium text-gray-500 uppercase">Amount Received (₹)*</label>
                        <input type="number" x-model="newPayment.amount_received" class="w-full border-b focus:border-blue-600 outline-none py-2 text-base md:text-lg font-bold text-gray-900" :max="newPayment.remaining_due">
                    </div>
                    <div class="grid grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-[10px] md:text-xs font-medium text-gray-500 uppercase">Date*</label>
                            <input type="date" x-model="newPayment.date" class="w-full border-b focus:border-blue-600 outline-none py-2 text-xs md:text-sm">
                        </div>
                        <div class="space-y-1">
                            <label class="text-[10px] md:text-xs font-medium text-gray-500 uppercase">Method*</label>
                            <select x-model="newPayment.method" class="w-full border-b focus:border-blue-600 outline-none py-2 text-xs md:text-sm bg-white">
                                <option>Bank Transfer</option>
                                <option>UPI / Wallet</option>
                                <option>Cash</option>
                                <option>Cheque</option>
                            </select>
                        </div>
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] md:text-xs font-medium text-gray-500 uppercase">Note / Reference No</label>
                        <input type="text" x-model="newPayment.note" class="w-full border-b focus:border-blue-600 outline-none py-2 text-xs md:text-sm" placeholder="e.g. UTR or Cheque No">
                    </div>
                </div>

                <div class="mt-8 flex justify-end space-x-3"><button type="button" @click="showPaymentModal = false" class="px-4 py-2 text-xs md:text-sm font-medium text-gray-600">Cancel</button><button type="button" @click="submitPayment()" class="btn-google bg-green-600 hover:bg-green-700 text-xs md:text-sm">Record Payment</button></div>
            </div>
        </div>
    </div>

    <!-- Email Modal -->
    <div x-show="showEmailModal" class="fixed inset-0 z-[60] overflow-y-auto no-print" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 py-6 text-center">
            <div @click="showEmailModal = false" class="fixed inset-0 transition-opacity bg-black bg-opacity-50"></div>
            <div class="inline-block w-full max-w-2xl p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg md:text-xl font-medium mb-6">Send Invoice via Email</h3>
                <div class="space-y-4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">To</label><input type="text" x-model="emailData.to" class="w-full border-b bg-gray-50 py-1 text-sm font-medium" readonly></div>
                        <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">CC</label><input type="text" x-model="emailData.cc" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm" placeholder="Additional recipients..."></div>
                    </div>
                    <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">Subject</label><input type="text" x-model="emailData.subject" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm font-bold"></div>
                    <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">Message</label><textarea x-model="emailData.body" rows="6" class="w-full border rounded-md p-3 text-sm focus:border-blue-600 outline-none"></textarea></div>
                    <div class="p-3 bg-blue-50 rounded flex items-center">
                        <div class="flex-grow font-bold text-blue-800 text-[10px] md:text-xs">Invoice Attached as PDF</div>
                        <template x-if="emailData.attachment"><span class="text-[9px] md:text-[10px] bg-green-500 text-white px-2 py-0.5 rounded-full font-bold uppercase">Ready</span></template>
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-3"><button type="button" @click="showEmailModal = false" class="px-4 py-2 text-xs md:text-sm font-medium text-gray-600">Cancel</button><button type="button" @click="submitManualEmail()" class="btn-google text-xs md:text-sm">Send Email</button></div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-[100]" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div @click="confirmModal.show = false" class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg font-medium mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('invoiceManager', () => ({
        invoices: <?= json_encode($invoices) ?>,
        settings: <?= json_encode($settings ?: []) ?>,
        banks: <?= json_encode($settings['bank_accounts'] ?? []) ?>,
        invoiceTemplates: <?= json_encode($settings['invoice_templates'] ?? []) ?>,
        emailTemplates: <?php echo json_encode($settings['templates'] ?? []) ?>,
        searchQuery: '',
        filterStatus: '',
        showTrash: false,
        selected: [],
        selectAll: false,
        pagination: <?= json_encode($pagination) ?>,
        toast: { show: false, message: '', type: 'success' },
        confirmModal: { show: false, message: '', callback: null },
        showInvoiceModal: false,
        showEmailModal: false,
        showPaymentModal: false,
        emailData: { to: '', cc: '', subject: '', body: '', attachment: '' },
        newPayment: { invoice_id: '', invoice_no: '', total_amount: 0, previous_paid: 0, remaining_due: 0, amount_received: 0, date: new Date().toISOString().split('T')[0], method: 'Bank Transfer', note: '' },
        newStandaloneInvoice: { client_name: '', email: '', subject: 'Professional Services', items: [{service: '', price: 0}], invoice_date: new Date().toISOString().split('T')[0], bank_id: '' },
        activePreview: null,
        clientsList: [],
        payments: <?php 
            $allPayments = (new \App\Repositories\JsonNoSqlRepository(__DIR__ . '/../storage/db'))->findAll('payments');
            echo json_encode($allPayments ?? []); 
        ?>,
        
getInvoiceTemplate(invoice) {
            if (!invoice) return null;
            if (invoice.template_id) {
                const found = this.invoiceTemplates.find(t => t.id === invoice.template_id);
                if (found) return found;
            }
            return this.invoiceTemplates[0] || null;
        },
        
        renderInvoiceTemplate(content, invoice) {
            let r = content || '';
            const orgLogo = this.settings.logo_url ? `<img src="${url(this.settings.logo_url)}" style="height: 80px;">` : '';
            
            let itemsTable = '';
            if (invoice.items && invoice.items.length > 0) {
                itemsTable = '<table style="width: 100%; border-collapse: collapse; margin-bottom: 1em; font-size: 14px;">';
                itemsTable += '<thead><tr style="border-bottom: 2px solid #ddd; text-align: left;"><th style="padding: 8px;">Description</th><th style="padding: 8px; text-align: right;">Amount</th></tr></thead>';
                itemsTable += '<tbody>';
                let total = 0;
                invoice.items.forEach(item => {
                    let price = parseFloat(item.price || 0);
                    total += price;
                    itemsTable += `<tr style="border-bottom: 1px solid #eee;"><td style="padding: 8px;">${item.service}</td><td style="padding: 8px; text-align: right;">₹${price.toLocaleString()}</td></tr>`;
                });
                itemsTable += `<tr style="font-weight: bold; font-size: 16px;"><td style="padding: 8px;">Total</td><td style="padding: 8px; text-align: right;">₹${total.toLocaleString()}</td></tr>`;
                itemsTable += '</tbody></table>';
            }
            
            const bank = invoice.bank_id && this.banks ? this.banks.find(b => b.id === invoice.bank_id) : null;
            
            const v = {
                '{{client_name}}': invoice.client_name,
                '{{email}}': invoice.email,
                '{{phone}}': invoice.client?.phone || '',
                '{{address}}': invoice.client?.address || '',
                '{{state}}': invoice.client?.state || '',
                '{{budget}}': invoice.budget || '',
                '{{invoice_no}}': invoice.invoice_no,
                '{{amount}}': invoice.amount,
                '{{date}}': invoice.created_at,
                '{{subject}}': invoice.subject,
                '{{service}}': invoice.items?.map(i => i.service).join(', ') || '',
                '{{org_name}}': this.settings.org_name,
                '{{org_website}}': this.settings.website_url,
                '{{org_email}}': this.settings.email,
                '{{org_phone}}': this.settings.phone,
                '{{org_logo}}': orgLogo,
                '{{client_photo}}': invoice.client?.client_photo ? `<img src="${url(invoice.client.client_photo)}" style="height: 100px; border-radius: 50%;">` : '',
                '{{items}}': itemsTable,
                '{{bank_name}}': bank?.account_name || '',
                '{{bank_account}}': bank?.account_no || '',
                '{{bank_ifsc}}': bank?.ifsc || '',
                '{{bank_branch}}': bank?.branch || ''
            };
            for (const [k, val] of Object.entries(v)) r = r.split(k).join(val || '');
            return r;
        },
        renderInvoicePreview() {
            if (!this.activePreview) return;
            if (!this.activePreview.template_id && this.invoiceTemplates.length > 0) {
                this.activePreview.template_id = this.invoiceTemplates[0].id;
            }
        },
        async init() {
            const cRes = await fetch(url('/clients'), { headers: { 'Accept': 'application/json' } });
            if(cRes.ok) { this.clientsList = (await cRes.json()).clients || []; }
            this.$watch('searchQuery', () => this.fetchData(1));
            setTimeout(() => {
                document.querySelectorAll('input[type="text"][x-model]').forEach(el => {
                    if (el.getAttribute('x-model') === 'searchQuery') {
                        el.value = '';
                        el.dispatchEvent(new Event('input'));
                    }
                });
            }, 50);
        },
        async fetchData(page = 1) {
            const params = new URLSearchParams({
                page: page,
                q: this.searchQuery,
                status: this.filterStatus,
                trash: this.showTrash ? '1' : '0'
            });
            const res = await fetch(url('/invoices?') + params.toString(), {
                headers: { 'Accept': 'application/json' }
            });
            const data = await res.json();
            this.invoices = data.invoices;
            this.pagination = {
                current_page: page,
                per_page: 25,
                total: data.total,
                total_pages: Math.ceil(data.total / 25)
            };
        },
        calculatePaidAmount(invoiceId) {
            return this.payments.filter(p => p.invoice_id === invoiceId).reduce((sum, p) => sum + parseFloat(p.amount || 0), 0);
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) this.confirmModal.callback();
            this.confirmModal.show = false;
        },
        async deleteInvoice(id) {
            this.confirmAction('Are you sure you want to delete this invoice?', async () => {
                await fetch(url('/invoices/delete'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
                this.fetchData(this.pagination.current_page);
            });
        },
        async restoreInvoice(id) {
            const res = await fetch(url('/invoices/restore'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
            if ((await res.json()).status === 'success') { this.showToast('Invoice restored'); this.fetchData(this.pagination.current_page); }
        },
        showToast(msg, type = 'success') { this.toast.message = msg; this.toast.type = type; this.toast.show = true; setTimeout(() => this.toast.show = false, 3000); },
        toggleSelectAll() { this.selected = this.selectAll ? this.invoices.map(i => i.id) : []; },
        openPreviewModal(i) { this.activePreview = i; },
        selectClient(clientId) {
            const client = this.clientsList.find(c => c.id === clientId);
            if (client) {
                this.newStandaloneInvoice.client_name = client.client_name;
                this.newStandaloneInvoice.email = client.email;
            }
        },
        addInvoiceItem(type = 'edit') {
            if (type === 'new') this.newStandaloneInvoice.items.push({ service: '', price: 0 });
            else {
                if (!this.activePreview.items) this.activePreview.items = [];
                this.activePreview.items.push({ service: '', price: 0 });
            }
        },
        removeInvoiceItem(index, type = 'edit') {
            if (type === 'new') this.newStandaloneInvoice.items.splice(index, 1);
            else this.activePreview.items.splice(index, 1);
        },
        async createStandaloneInvoice() {
            if (!this.newStandaloneInvoice.bank_id) { this.showToast('Please select a bank', 'error'); return; }
            try {
                const res = await fetch(url('/invoices'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.newStandaloneInvoice) });
                const data = await res.json();
                if (data.status === 'success') { this.showNewInvoiceModal = false; this.showToast('Invoice created'); this.fetchData(1); }
                else { this.showToast(data.message || 'Failed to create invoice', 'error'); }
            } catch (e) { this.showToast('Error creating invoice', 'error'); }
        },
        amountInWords(num) {
            if (!num) return 'Zero Rupees Only';
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            const inWords = (n) => {
                if ((n = n.toString()).length > 9) return 'overflow';
                let nArr = ('000000000' + n).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                if (!nArr) return ''; 
                let str = '';
                str += (nArr[1] != 0) ? (a[Number(nArr[1])] || b[nArr[1][0]] + ' ' + a[nArr[1][1]]) + 'Crore ' : '';
                str += (nArr[2] != 0) ? (a[Number(nArr[2])] || b[nArr[2][0]] + ' ' + a[nArr[2][1]]) + 'Lakh ' : '';
                str += (nArr[3] != 0) ? (a[Number(nArr[3])] || b[nArr[3][0]] + ' ' + a[nArr[3][1]]) + 'Thousand ' : '';
                str += (nArr[4] != 0) ? (a[Number(nArr[4])] || b[nArr[4][0]] + ' ' + a[nArr[4][1]]) + 'Hundred ' : '';
                str += (nArr[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(nArr[5])] || b[nArr[5][0]] + ' ' + a[nArr[5][1]]) : '';
                return str;
            }
            return inWords(Math.floor(num)) + ' Rupees Only';
        },
        renderTemplate(content, invoice) {
            let r = content || '';
            const v = { '{{name}}': invoice.client_name, '{{client_name}}': invoice.client_name, '{{invoice_no}}': invoice.invoice_no, '{{amount}}': invoice.amount, '{{date}}': invoice.created_at, '{{org_name}}': this.settings.org_name, '{{org_website}}': this.settings.website_url, '{{org_email}}': this.settings.email, '{{org_phone}}': this.settings.phone };
            for (const [k, val] of Object.entries(v)) r = r.split(k).join(val || '');
            return r;
        },
        async downloadPDF(invoice) {
            this.showToast('Generating PDF...');
            this.activePreview = invoice;
            await new Promise(r => setTimeout(r, 400));
            const element = document.getElementById('invoice-print-area');
            if(!element) { this.showToast('Preview element not found', 'error'); return; }
            const opt = { margin: 0, filename: `Invoice_${invoice.invoice_no}.pdf`, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2, useCORS: true }, jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' } };
            html2pdf().set(opt).from(element).save();
        },
        async openEmailModal(invoice) {
            this.showToast('Preparing email...');
            this.activePreview = invoice;
            await new Promise(r => setTimeout(r, 400));
            try {
                const element = document.getElementById('invoice-print-area');
                if(!element) return;
                const opt = { margin: 0, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 1.5, useCORS: true }, jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' } };
                const pdfBase64 = await html2pdf().set(opt).from(element).outputPdf('datauristring');
                const tpl = this.emailTemplates.find(t => t.id === 'invoice_sent');
                this.emailData = { id: invoice.id, to: invoice.email, cc: '', subject: tpl ? this.renderTemplate(tpl.subject, invoice) : `Invoice: ${invoice.invoice_no}`, body: tpl ? this.renderTemplate(tpl.body, invoice) : `Hi ${invoice.client_name}, please find attached.`, attachment: pdfBase64 };
                this.showEmailModal = true;
            } catch (e) { this.showToast('PDF Error', 'error'); }
        },
        async submitManualEmail() {
            this.showToast('Sending...');
            const res = await fetch(url('/invoices/send-email'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.emailData) });
            const data = await res.json();
            if (data.status === 'success') { this.showToast('Sent!'); this.showEmailModal = false; }
            else { this.showToast(data.message || 'Failed', 'error'); }
        },
        openPaymentModal(invoice) {
            const paid = this.calculatePaidAmount(invoice.id);
            const due = parseFloat(invoice.amount) - paid;
            this.newPayment = { invoice_id: invoice.id, invoice_no: invoice.invoice_no, total_amount: parseFloat(invoice.amount), previous_paid: paid, remaining_due: due, amount_received: due, date: new Date().toISOString().split('T')[0], method: 'Bank Transfer', note: '' };
            this.showPaymentModal = true;
        },
        async submitPayment() {
            if (this.newPayment.amount_received <= 0 || this.newPayment.amount_received > this.newPayment.remaining_due) { this.showToast('Invalid amount', 'error'); return; }
            try {
                const res = await fetch(url('/invoices/record-payment'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.newPayment) });
                const data = await res.json();
                if (data.status === 'success') { this.showPaymentModal = false; this.showToast('Payment recorded'); setTimeout(() => window.location.reload(), 1000); }
                else { this.showToast(data.message || 'Failed to record payment', 'error'); }
            } catch (e) { this.showToast('Error recording payment', 'error'); }
        },
        async bulkAction(action) {
            if (this.selected.length === 0) return;
            if (action === 'delete') {
                this.confirmAction(`Delete ${this.selected.length} selected invoices?`, async () => {
                    await fetch(url('/invoices/bulk-delete'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ids: this.selected }) });
                    this.fetchData(this.pagination.current_page);
                });
            }
        },
        exportToCSV() {
            const h = ['Invoice No', 'Client', 'Email', 'Amount', 'Status', 'Date'];
            const r = this.invoices.map(i => [i.invoice_no, i.client_name, i.email, i.amount, i.status, i.created_at]);
            let csv = 'data:text/csv;charset=utf-8,' + h.join(',') + '\n' + r.map(row => row.map(c => '"' + (c||'').toString().replace(/"/g, '""') + '"').join(',')).join('\n');
            const link = document.createElement('a'); link.href = encodeURI(csv); link.download = 'invoices.csv'; link.click();
        }
    }));
});
</script>

</body>
</html>
