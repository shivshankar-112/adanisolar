<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enquiries - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="enquiryManager" class="min-h-screen flex flex-col">

    <?php 
    $activePage = 'enquiries';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <!-- Search bar and Actions -->
    <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4 shadow-sm sticky top-0 z-30">
        <div class="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 flex-grow">
            <div class="relative group">
                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 group-focus-within:text-blue-500 transition-colors">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </span>
                <input type="text" x-model="searchQuery" autocomplete="off" placeholder="Search client, email, no..." class="bg-gray-50 border border-gray-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full lg:w-64 transition-all">
            </div>

            <!-- Advanced Filters -->
            <div class="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                <select x-model="filterStatus" @change="fetchData(1)" class="bg-gray-50 border border-gray-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none flex-shrink-0 cursor-pointer hover:bg-white transition-colors">
                    <option value="">All Status</option>
                    <option value="New">New</option>
                    <option value="Approved">Approved</option>
                    <option value="Rejected">Rejected</option>
                    <option value="Converted">Converted</option>
                </select>

                <select x-model="filterStaff" @change="fetchData(1)" class="bg-gray-50 border border-gray-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none flex-shrink-0 cursor-pointer hover:bg-white transition-colors">
                    <option value="">All Staff</option>
                    <template x-for="staff in staffList" :key="staff.id">
                        <option :value="staff.id" x-text="staff.name"></option>
                    </template>
                </select>

                <button type="button" @click="showTrash = !showTrash; fetchData(1)" class="flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all flex-shrink-0" :class="showTrash ? 'bg-red-100 text-red-700 shadow-inner' : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-white hover:shadow-sm'">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                    <span x-text="showTrash ? 'Viewing Trash' : 'Trash'"></span>
                </button>

                <button type="button" @click="filterStatus=''; filterStaff=''; searchQuery=''; showTrash=false; fetchData(1)" class="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline px-2 flex-shrink-0">Reset</button>
            </div>
            
            <!-- Bulk Actions Toolbar -->
            <div x-show="selected.length > 0" x-transition class="flex flex-wrap items-center gap-2 lg:border-l lg:pl-4 pb-1 lg:pb-0" style="display: none;">
                <span class="text-xs text-gray-500 font-bold mr-2 whitespace-nowrap bg-blue-50 px-2 py-1 rounded" x-text="selected.length + ' selected'"></span>
                <button type="button" @click="showAssignModal = true" class="text-[10px] md:text-xs font-bold bg-gray-50 hover:bg-gray-100 text-gray-700 px-3 py-1.5 rounded-lg border border-gray-200 transition-all flex-shrink-0">Assign</button>
                <button type="button" @click="bulkAction('approve')" class="text-[10px] md:text-xs font-bold bg-green-50 hover:bg-green-100 text-green-700 px-3 py-1.5 rounded-lg border border-green-200 transition-all flex-shrink-0">Approve</button>
                <button type="button" @click="bulkAction('reject')" class="text-[10px] md:text-xs font-bold bg-red-50 hover:bg-red-100 text-red-700 px-3 py-1.5 rounded-lg border border-red-200 transition-all flex-shrink-0">Reject</button>
                <button type="button" @click="copySelected()" class="text-[10px] md:text-xs font-bold bg-gray-50 hover:bg-gray-100 text-gray-700 px-3 py-1.5 rounded-lg border border-gray-200 transition-all flex-shrink-0">Copy</button>
                <button type="button" @click="bulkAction('delete')" class="text-[10px] md:text-xs font-bold bg-gray-50 hover:bg-red-50 text-red-600 px-3 py-1.5 rounded-lg border border-gray-200 hover:border-red-200 transition-all flex-shrink-0">Delete</button>
            </div>
        </div>
        <div class="flex items-center gap-3">
            <button type="button" @click="exportToCSV()" class="flex-1 lg:flex-none justify-center bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 hover:shadow-sm transition-all flex items-center">
                <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                Export
            </button>
            <button type="button" @click="openNewModal()" class="flex-1 lg:flex-none justify-center btn-google py-2 px-6 rounded-lg text-sm font-semibold shadow-md hover:shadow-lg transition-all flex items-center">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                New Enquiry
            </button>
        </div>
    </div>

    <main class="flex-grow p-4 md:p-8">
        <div class="max-w-full mx-auto">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between mb-6 md:mb-8 gap-4">
                <h1 class="text-xl md:text-2xl">Enquiries</h1>
                <a href="<?php echo url('/enquiries/help'); ?>" class="text-[10px] md:text-sm text-blue-600 hover:underline font-bold flex items-center">
                    <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path></svg>
                    Get Embed Form Code
                </a>
            </div>

            <div class="card overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                        <thead class="bg-gray-50 border-b">
                            <tr>
                                <th class="px-3 md:px-4 py-3 w-10 md:w-12"><input type="checkbox" x-model="selectAll" @change="toggleSelectAll()" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"></th>
                                <th @click="sortBy('enquiry_no')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Enquiry No
                                    <span x-show="sortKey === 'enquiry_no'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-center">Photo</th>
                                <th @click="sortBy('client_name')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Client
                                    <span x-show="sortKey === 'client_name'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th @click="sortBy('service')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Service
                                    <span x-show="sortKey === 'service'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th @click="sortBy('status')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Status
                                    <span x-show="sortKey === 'status'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th @click="sortBy('assigned_to')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Assigned To
                                    <span x-show="sortKey === 'assigned_to'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th @click="sortBy('created_at')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                    Date
                                    <span x-show="sortKey === 'created_at'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                </th>
                                <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y">
                            <template x-for="enquiry in filteredEnquiries" :key="enquiry.id">
                                <tr class="hover:bg-gray-50 transition group">
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap"><input type="checkbox" :value="enquiry.id" x-model="selected" class="rounded border-gray-300 text-blue-600 focus:ring-blue-500"></td>
                                    <td class="px-3 md:px-4 py-4 font-medium text-blue-600 whitespace-nowrap">
                                        <a href="#" @click.prevent.stop="openPreviewModal(enquiry)" x-text="enquiry.enquiry_no" class="hover:underline text-xs md:text-sm"></a>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 text-center whitespace-nowrap">
                                        <template x-if="enquiry.client_photo">
                                            <img :src="url(enquiry.client_photo)" class="w-8 h-8 rounded-full object-cover border shadow-sm mx-auto">
                                        </template>
                                        <template x-if="!enquiry.client_photo">
                                            <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs mx-auto" x-text="enquiry.client_name.charAt(0)"></div>
                                        </template>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <div class="text-xs md:text-sm font-medium truncate max-w-[150px]" :title="enquiry.client_name" x-text="enquiry.client_name"></div>
                                        <div class="text-[10px] md:text-xs text-gray-500 truncate max-w-[150px]" :title="enquiry.email">
                                            <a :href="'mailto:' + enquiry.email" class="hover:text-blue-600 hover:underline" x-text="enquiry.email"></a>
                                        </div>
                                        <div class="text-[10px] md:text-xs text-gray-500 truncate max-w-[150px]" :title="enquiry.phone" x-show="enquiry.phone">
                                            <a :href="'tel:' + enquiry.phone" class="hover:text-blue-600 hover:underline" x-text="enquiry.phone"></a>
                                        </div>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <div class="text-xs md:text-sm text-gray-900 font-medium truncate max-w-[150px]" :title="enquiry.service" x-text="enquiry.service || '-'"></div>
                                        <div class="text-[9px] md:text-[10px] text-gray-500 mt-0.5">
                                            <span x-text="enquiry.budget || '-'"></span>
                                            <span class="text-blue-600 font-medium" x-text="budgetList.find(b => b.name === enquiry.budget)?.range ? ' ' + budgetList.find(b => b.name === enquiry.budget).range : ''"></span>
                                        </div>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 whitespace-nowrap">
                                        <template x-if="enquiry.status === 'New'">
                                            <div class="flex items-center bg-gray-100 rounded-full p-0.5 w-max border">
                                                <button type="button" @click.stop="updateStatus(enquiry.id, 'Approved')" class="px-3 py-1 text-[10px] md:text-xs rounded-full font-bold transition-all hover:bg-white hover:shadow-sm text-gray-500 hover:text-green-600">Approve</button>
                                                <button type="button" @click.stop="updateStatus(enquiry.id, 'Rejected')" class="px-3 py-1 text-[10px] md:text-xs rounded-full font-bold transition-all hover:bg-white hover:shadow-sm text-gray-500 hover:text-red-600">Reject</button>
                                            </div>
                                        </template>
                                        <template x-if="enquiry.status !== 'New'">
                                            <span :class="{
                                                'bg-green-100 text-green-700': enquiry.status === 'Converted' || enquiry.status === 'Approved',
                                                'bg-red-100 text-red-700': enquiry.status === 'Rejected'
                                            }" class="px-2 py-1 text-[10px] md:text-xs rounded-full font-medium" x-text="enquiry.status"></span>
                                        </template>
                                    </td>
                                    <td class="px-3 md:px-4 py-4 text-[10px] md:text-xs text-gray-600 truncate max-w-[120px] whitespace-nowrap" :title="staffList.find(s => s.id === enquiry.assigned_to)?.name || rolesList.find(r => r.id === enquiry.assigned_to)?.name" x-text="staffList.find(s => s.id === enquiry.assigned_to)?.name || rolesList.find(r => r.id === enquiry.assigned_to)?.name || 'Unassigned'">
                                    </td>
                                    <td class="px-3 md:px-4 py-4 text-[10px] md:text-xs text-gray-500 whitespace-nowrap" x-text="enquiry.created_at"></td>
                                    <td class="px-3 md:px-4 py-4 text-right space-x-1 md:space-x-2 whitespace-nowrap">
                                        <?php if (\App\Services\PermissionHelper::check('enquiries', 'edit')): ?>
                                            <button type="button" @click.stop="openEditModal(enquiry)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">Edit</button>
                                        <?php endif; ?>

                                        <template x-if="enquiry.status === 'Rejected'">
                                            <button type="button" @click.stop="updateStatus(enquiry.id, 'Approved')" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">Approve</button>
                                        </template>

                                        <template x-if="enquiry.status === 'Approved' || enquiry.status === 'Converted'">
                                            <button type="button" @click.stop="createApproval(enquiry)" class="text-[10px] md:text-xs text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg font-bold transition-all shadow-sm">Approval</button>
                                        </template>

                                        <template x-if="!enquiry.client_id">
                                            <button type="button" @click.stop="convertToClient(enquiry.id)" class="text-[10px] md:text-xs text-white bg-blue-600 hover:bg-blue-700 px-3 py-1.5 rounded-lg font-bold transition-all shadow-sm">Convert</button>
                                        </template>

                                        <?php if (\App\Services\PermissionHelper::check('enquiries', 'delete')): ?>
                                            <button type="button" @click.stop="deleteEnquiry(enquiry.id)" class="text-gray-400 hover:text-red-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-red-50">
                                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                                            </button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
                <template x-if="pagination.total_pages > 1">
                    <div class="px-4 py-3 border-t bg-gray-50 flex flex-col sm:flex-row items-center justify-between gap-3">
                        <div class="text-[10px] md:text-xs text-gray-500">
                            Showing <span x-text="(pagination.current_page - 1) * pagination.per_page + 1"></span> 
                            to <span x-text="Math.min(pagination.current_page * pagination.per_page, pagination.total)"></span> 
                            of <span x-text="pagination.total"></span> entries
                        </div>
                        <div class="flex space-x-2">
                            <button @click="fetchData(pagination.current_page - 1)" :disabled="pagination.current_page <= 1" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50 transition">Previous</button>
                            <button @click="fetchData(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.total_pages" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50 transition">Next</button>
                        </div>
                    </div>
                </template>
            </div>
        </div>
    </main>

    <!-- Assign Staff Modal -->
    <div x-show="showAssignModal" class="fixed inset-0 z-50 overflow-y-auto px-4 py-6 md:p-0" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="showAssignModal = false" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            
            <div class="inline-block w-full max-w-sm p-4 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg md:text-xl font-medium leading-6 text-gray-900 mb-6">Assign Staff</h3>
                
                <div class="space-y-4">
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Select Staff Member</label>
                        <select x-model="bulkAssignTo" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-white text-sm md:text-base">
                            <option value="">-- Unassigned --</option>
                            <optgroup label="Staff">
                                <template x-for="staff in staffList" :key="staff.id">
                                    <option :value="staff.id" x-text="staff.name"></option>
                                </template>
                            </optgroup>
                            <optgroup label="Roles">
                                <template x-for="role in rolesList" :key="role.id">
                                    <option :value="role.id" x-text="role.name"></option>
                                </template>
                            </optgroup>
                        </select>
                    </div>
                </div>

                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3">
                    <button type="button" @click="showAssignModal = false" class="w-full sm:w-auto px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 transition">Cancel</button>
                    <button type="button" @click="bulkAction('assign')" class="w-full sm:w-auto btn-google py-2 md:py-1.5">Assign</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Google-style Modal (Enquiry) -->
    <div x-show="showModal" class="fixed inset-0 z-50 overflow-y-auto px-4 py-6 md:p-0" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="showModal = false" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            
            <div class="inline-block w-full max-w-2xl p-4 md:p-8 overflow-x-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg md:text-xl font-medium leading-6 text-gray-900 mb-6" x-text="newEnquiry.id ? 'Edit Enquiry' : 'Create New Enquiry'"></h3>
                
                <div class="space-y-4 max-h-[70vh] overflow-y-auto px-1">
                    <div class="space-y-1 bg-blue-50 p-3 rounded-md mb-4 border border-blue-100">
                        <label class="text-xs font-medium text-blue-700">Existing Client (Optional)</label>
                        <select x-model="newEnquiry.client_id" @change="selectClient($event.target.value)" class="w-full border-b border-blue-300 focus:border-blue-600 outline-none py-1 bg-transparent text-blue-900">
                            <option value="">-- Select an Existing Client --</option>
                            <template x-for="client in clientsList" :key="client.id">
                                <option :value="client.id" x-text="client.client_name + ' (' + client.email + ')'"></option>
                            </template>
                        </select>
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Client Name*</label>
                            <input type="text" x-model="newEnquiry.client_name" class="w-full border-b focus:border-blue-600 outline-none py-1">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Email Address*</label>
                            <input type="email" x-model="newEnquiry.email" @blur="validateField('email')" class="w-full border-b focus:border-blue-600 outline-none py-1" :class="errors.email ? 'border-red-500' : ''">
                            <div x-show="errors.email" class="text-[10px] text-red-500" x-text="errors.email"></div>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Phone Number</label>
                            <input type="text" x-model="newEnquiry.phone" class="w-full border-b focus:border-blue-600 outline-none py-1">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Client Photo</label>
                            <div class="flex items-center space-x-2">
                                <template x-if="newEnquiry.client_photo">
                                    <img :src="url(newEnquiry.client_photo)" class="w-10 h-10 rounded-full object-cover border">
                                </template>
                                <input type="file" @change="uploadClientPhoto" class="text-[10px] md:text-xs w-full">
                            </div>
                        </div>
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">GST Number</label>
                            <input type="text" x-model="newEnquiry.gst" maxlength="15" @input="newEnquiry.gst = $event.target.value.toUpperCase()" @blur="validateField('gst')" class="w-full border-b focus:border-blue-600 outline-none py-1 uppercase" :class="errors.gst ? 'border-red-500' : ''">
                            <div x-show="errors.gst" class="text-[10px] text-red-500" x-text="errors.gst"></div>
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">PAN Number</label>
                            <input type="text" x-model="newEnquiry.pan" maxlength="10" @input="newEnquiry.pan = $event.target.value.toUpperCase()" @blur="validateField('pan')" class="w-full border-b focus:border-blue-600 outline-none py-1 uppercase" :class="errors.pan ? 'border-red-500' : ''">
                            <div x-show="errors.pan" class="text-[10px] text-red-500" x-text="errors.pan"></div>
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Aadhar Number</label>
                            <input type="text" x-model="newEnquiry.aadhar" maxlength="12" @blur="validateField('aadhar')" class="w-full border-b focus:border-blue-600 outline-none py-1" :class="errors.aadhar ? 'border-red-500' : ''">
                            <div x-show="errors.aadhar" class="text-[10px] text-red-500" x-text="errors.aadhar"></div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Service</label>
                            <select x-model="newEnquiry.service" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-white">
                                <option value="">-- Select Service --</option>
                                <template x-for="svc in servicesList" :key="svc.id">
                                    <option :value="svc.name" x-text="svc.name"></option>
                                </template>
                            </select>
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Budget</label>
                            <select x-model="newEnquiry.budget" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-white">
                                <option value="">-- Select Budget --</option>
                                <template x-for="bdg in budgetList" :key="bdg.id">
                                    <option :value="bdg.name" x-text="bdg.name + ' (' + bdg.range + ')'"></option>
                                </template>
                            </select>
                        </div>
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Address</label>
                        <input type="text" x-model="newEnquiry.address" class="w-full border-b focus:border-blue-600 outline-none py-1">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">State</label>
                        <select x-model="newEnquiry.state" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-white">
                            <option value="">-- Select State --</option>
                            <template x-for="st in indianStates" :key="st">
                                <option :value="st" x-text="st"></option>
                            </template>
                        </select>
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Message</label>
                        <textarea x-model="newEnquiry.message" rows="4" class="w-full border rounded-md p-2 focus:ring-1 focus:ring-blue-600 outline-none mt-2"></textarea>
                    </div>

                    <div class="">
                        <h4 class="text-[10px] md:text-xs font-semibold text-gray-600 uppercase tracking-wider mb-4">Assignment & Status</h4>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                            <div class="space-y-1">
                                <label class="text-xs font-medium text-gray-500">Assign To</label>
                                <select x-model="newEnquiry.assigned_to" class="w-full border-b border-gray-300 focus:border-blue-600 outline-none py-1 bg-transparent">
                                    <option value="">-- Unassigned --</option>
                                    <optgroup label="Staff">
                                        <template x-for="staff in staffList" :key="staff.id">
                                            <option :value="staff.id" x-text="staff.name"></option>
                                        </template>
                                    </optgroup>
                                    
                                </select>
                            </div>
                            <div class="space-y-1">
                                <label class="text-xs font-medium text-gray-500">Status</label>
                                <select x-model="newEnquiry.status" class="w-full border-b border-gray-300 focus:border-blue-600 outline-none py-1 bg-transparent">
                                    <option value="New">New</option>
                                    <option value="Approved">Approved</option>
                                    <option value="Rejected">Rejected</option>
                                    <option value="Converted">Converted</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mt-8 flex flex-col sm:flex-row items-center justify-between gap-4 border-t pt-6">
                    <div class="w-full sm:w-auto">
                        <!-- Show button only if NOT linked to a client AND status is not 'Converted' -->
                        <template x-if="newEnquiry.id && !newEnquiry.client_id && newEnquiry.status !== 'Converted'">
                            <button type="button" @click.stop="convertToClient(newEnquiry.id)" class="w-full sm:w-auto px-6 py-2 text-sm font-bold text-white bg-green-600 hover:bg-green-700 rounded-md shadow-md transition-all transform hover:scale-105">
                                Convert to Client
                            </button>
                        </template>
                        
                        <!-- Show badge if ALREADY linked to a client OR status is 'Converted' -->
                        <template x-if="newEnquiry.client_id || newEnquiry.status === 'Converted'">
                            <span class="bg-green-100 text-green-700 px-4 py-2 rounded-md text-xs font-bold border border-green-200 flex items-center justify-center shadow-sm text-center">
                                <svg class="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg>
                                Linked to Client
                            </span>
                        </template>
                    </div>

                    <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto">
                        <button type="button" @click="showModal = false" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 border rounded-md hover:bg-gray-50 transition-colors">Cancel</button>
                        
                        <template x-if="newEnquiry.id && newEnquiry.status === 'New'">
                            <div class="flex gap-2">
                                <button type="button" @click.stop="updateStatus(newEnquiry.id, 'Approved')" class="flex-1 sm:flex-none px-4 py-2 text-sm font-medium text-green-600 hover:bg-green-50 rounded-md border border-green-200 transition-colors">Approve</button>
                                <button type="button" @click.stop="updateStatus(newEnquiry.id, 'Rejected')" class="flex-1 sm:flex-none px-4 py-2 text-sm font-medium text-red-600 hover:bg-red-50 rounded-md border border-red-200 transition-colors">Reject</button>
                            </div>
                        </template>

                        <button type="button" @click="submitEnquiry()" class="btn-google shadow-md hover:shadow-lg transition-all py-2.5">Save Enquiry</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Approval Modal -->
    <div x-show="showApprovalModal" class="fixed inset-0 z-50 overflow-y-auto px-4 py-6 md:p-0" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="showApprovalModal = false" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            
            <div class="inline-block w-full max-w-lg p-4 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg md:text-xl font-medium leading-6 text-gray-900 mb-6">Create Approval</h3>
                
                <div class="space-y-4">
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Client</label>
                        <div class="py-1 font-medium text-sm md:text-base" x-text="newApproval.client_name + ' (' + newApproval.email + ')'"></div>
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Subject*</label>
                        <input type="text" x-model="newApproval.subject" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm md:text-base">
                    </div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Amount ($)*</label>
                            <input type="number" x-model="newApproval.amount" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm md:text-base">
                        </div>
                        <div class="space-y-1">
                            <label class="text-xs font-medium text-gray-500">Approval Date*</label>
                            <input type="date" x-model="newApproval.approval_date" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm md:text-base">
                        </div>
                    </div>
                </div>

                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3">
                    <button type="button" @click="showApprovalModal = false" class="w-full sm:w-auto px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800 transition">Cancel</button>
                    <button type="button" @click="submitApproval()" class="w-full sm:w-auto btn-google py-2 md:py-1.5">Create Approval</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-50" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
            <div class="fixed inset-0 transition-opacity bg-black bg-opacity-25"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl">
                <h3 class="text-lg font-medium leading-6 text-gray-900 mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Preview Modal -->
    <div x-show="activePreview !== null" class="fixed inset-0 z-50 overflow-y-auto px-4 py-6 md:p-0" style="display: none;">
        <div class="flex items-center justify-center min-h-screen">
            <div @click="activePreview = null" class="fixed inset-0 bg-black bg-opacity-40 transition-opacity backdrop-blur-sm"></div>
            
            <div class="inline-block w-full max-w-2xl p-4 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex justify-between items-start mb-6">
                    <div>
                        <h3 class="text-lg md:text-xl font-medium leading-6 text-gray-900" x-text="'Enquiry: ' + (activePreview?.enquiry_no || '')"></h3>
                        <p class="text-[10px] md:text-xs text-gray-500 mt-1" x-text="activePreview?.created_at"></p>
                    </div>
                    <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-500 transition">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                
                <div class="space-y-4 md:space-y-6 max-h-[70vh] overflow-y-auto px-1">
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 bg-gray-50 p-4 rounded-xl border border-gray-100">
                        <div class="flex items-start space-x-4">
                            <template x-if="activePreview?.client_photo">
                                <img :src="url(activePreview.client_photo)" class="w-12 h-12 md:w-16 md:h-16 rounded-full object-cover border-2 border-white shadow-sm">
                            </template>
                            <template x-if="!activePreview?.client_photo">
                                <div class="w-12 h-12 md:w-16 md:h-16 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-lg md:text-xl" x-text="activePreview?.client_name.charAt(0)"></div>
                            </template>
                            <div class="overflow-hidden">
                                <span class="block text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Client</span>
                                <div class="font-medium text-gray-900 text-sm md:text-base truncate" x-text="activePreview?.client_name"></div>
                                <div class="text-xs md:text-sm text-gray-600 mt-1 truncate">
                                    <a :href="'mailto:' + activePreview?.email" class="text-blue-600 hover:underline" x-text="activePreview?.email"></a>
                                </div>
                                <div class="text-xs md:text-sm text-gray-600 mt-1" x-text="activePreview?.phone || 'No phone'"></div>
                            </div>
                        </div>
                        <div>
                            <span class="block text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Tax & Identity</span>
                            <div class="text-xs md:text-sm text-gray-900"><span class="font-medium">PAN:</span> <span x-text="activePreview?.pan || '-'"></span></div>
                            <div class="text-xs md:text-sm text-gray-900 mt-1"><span class="font-medium">Aadhar:</span> <span x-text="activePreview?.aadhar || '-'"></span></div>
                            <div class="text-xs md:text-sm text-gray-900 mt-1"><span class="font-medium">GST:</span> <span x-text="activePreview?.gst || '-'"></span></div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6 bg-gray-50 p-4 rounded-xl border border-gray-100">
                        <div>
                            <span class="block text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Location</span>
                            <div class="text-xs md:text-sm text-gray-900" x-text="activePreview?.address || 'No address'"></div>
                            <div class="text-xs md:text-sm text-gray-600 mt-1" x-text="activePreview?.state || 'No state'"></div>
                        </div>
                        <div>
                            <span class="block text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Assignment & Status</span>
                            <div class="flex items-center space-x-2 text-xs md:text-sm text-gray-900">
                                <span class="font-medium">Assigned To:</span>
                                <span x-text="staffList.find(s => s.id === activePreview?.assigned_to)?.name || rolesList.find(r => r.id === activePreview?.assigned_to)?.name || 'Unassigned'"></span>
                            </div>
                            <div class="flex items-center space-x-2 text-xs md:text-sm text-gray-900 mt-1">
                                <span class="font-medium">Status:</span>
                                <span :class="{
                                    'bg-blue-100 text-blue-700': activePreview?.status === 'New',
                                    'bg-green-100 text-green-700': activePreview?.status === 'Converted' || activePreview?.status === 'Approved',
                                    'bg-red-100 text-red-700': activePreview?.status === 'Rejected'
                                }" class="px-2 py-0.5 text-[10px] md:text-xs rounded-full font-medium" x-text="activePreview?.status"></span>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 md:gap-6">
                        <div>
                            <span class="block text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Requirements</span>
                            <div class="flex items-center space-x-2 text-xs md:text-sm text-gray-900">
                                <span class="font-medium">Service:</span>
                                <span x-text="activePreview?.service || 'Not specified'"></span>
                            </div>
                            <div class="flex items-center space-x-2 text-xs md:text-sm text-gray-900 mt-1">
                                <span class="font-medium">Budget:</span>
                                <span class="bg-gray-100 px-2 py-0.5 rounded text-[10px] md:text-xs" x-text="activePreview?.budget || 'Not specified'"></span>
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <span class="block text-[9px] md:text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Message</span>
                        <div class="text-xs md:text-sm text-gray-700 whitespace-pre-wrap bg-gray-50 p-4 rounded-xl border border-gray-100 min-h-[100px]" x-text="activePreview?.message || 'No message content.'"></div>
                    </div>
                </div>

                <div class="mt-8 flex flex-col sm:flex-row justify-end gap-3">
                    <?php if (\App\Services\PermissionHelper::check('enquiries', 'edit')): ?>
                        <button type="button" @click="openEditModal(activePreview)" class="w-full sm:w-auto btn-google bg-blue-600 hover:bg-blue-700">Edit Enquiry</button>
                    <?php endif; ?>
                    <template x-if="activePreview && !activePreview.client_id">
                        <button type="button" @click="convertToClient(activePreview.id)" class="w-full sm:w-auto btn-google bg-green-600 hover:bg-green-700">Convert to Client</button>
                    </template>
                    <button type="button" @click="activePreview = null" class="w-full sm:w-auto btn-google bg-gray-600 hover:bg-gray-700">Close Preview</button>
                </div>
            </div>
        </div>
    </div>

    <?php include __DIR__ . '/partials/footer.php'; ?>
</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('enquiryManager', () => ({
        searchQuery: '',
        enquiries: <?= json_encode($enquiries) ?>,
        staffList: <?= json_encode($staffMembers) ?>,
        rolesList: <?= json_encode($roles) ?>,
        servicesList: <?= json_encode($settings['services'] ?? []) ?>,
        budgetList: <?= json_encode($settings['budgets'] ?? []) ?>,
        clientsList: [],
        indianStates: ['Andhra Pradesh','Arunachal Pradesh','Assam','Bihar','Chhattisgarh','Goa','Gujarat','Haryana','Himachal Pradesh','Jharkhand','Karnataka','Kerala','Madhya Pradesh','Maharashtra','Manipur','Meghalaya','Mizoram','Nagaland','Odisha','Punjab','Rajasthan','Sikkim','Tamil Nadu','Telangana','Tripura','Uttar Pradesh','Uttarakhand','West Bengal','Andaman and Nicobar Islands','Chandigarh','Dadra and Nagar Haveli and Daman and Diu','Delhi','Jammu and Kashmir','Ladakh','Lakshadweep','Puducherry'],
        selected: [],
        selectAll: false,
        showModal: false,
        showAssignModal: false,
        showApprovalModal: false,
        showTrash: false,
        filterStatus: '',
        filterStaff: '',
        pagination: <?php echo json_encode($pagination) ?>,
        bulkAssignTo: '',
        newEnquiry: { id: '', client_id: '', client_name: '', email: '', phone: '', message: '', status: 'New', assigned_to: '', service: '', budget: '', address: '', state: '', pan: '', aadhar: '', gst: '', client_photo: '' },
        newApproval: { enquiry_id: '', client_name: '', email: '', subject: '', amount: 0, approval_date: '' },
        errors: {},
        sortKey: 'created_at',
        sortOrder: 'desc',
        toast: { show: false, message: '' },
        confirmModal: { show: false, message: '', callback: null },
        activePreview: null,
        
        async init() {
            const res = await fetch(url('/clients'), {
                headers: { 'Accept': 'application/json' }
            });
            if(res.ok) {
                const text = await res.text();
                try {
                    const data = JSON.parse(text);
                    this.clientsList = data.clients || [];
                } catch(e) {}
            }

            this.$watch('searchQuery', () => this.fetchData(1));
            setTimeout(() => {
                document.querySelectorAll('input[type="text"][x-model]').forEach(el => {
                    if (el.getAttribute('x-model') === 'searchQuery') {
                        el.value = '';
                        el.dispatchEvent(new Event('input'));
                    }
                });
            }, 50);
        },

        async fetchData(page = 1) {
            const params = new URLSearchParams({
                page: page,
                q: this.searchQuery,
                status: this.filterStatus,
                staff: this.filterStaff,
                trash: this.showTrash ? '1' : '0'
            });
            const res = await fetch(url('/enquiries?' + params.toString()), {
                headers: { 'Accept': 'application/json' }
            });
            const data = await res.json();
            this.enquiries = data.enquiries;
            this.pagination = {
                current_page: page,
                per_page: 25,
                total: data.total,
                total_pages: Math.ceil(data.total / 25)
            };
        },
        
        selectClient(clientId) {
            const client = this.clientsList.find(c => c.id === clientId);
            if (client) {
                this.newEnquiry.client_id = client.id;
                this.newEnquiry.client_name = client.client_name;
                this.newEnquiry.email = client.email;
                this.newEnquiry.phone = client.phone;
                this.newEnquiry.address = client.address;
                this.newEnquiry.state = client.state;
                this.newEnquiry.pan = client.pan;
                this.newEnquiry.aadhar = client.aadhar;
                this.newEnquiry.gst = client.gst;
                this.newEnquiry.client_photo = client.client_photo;
            } else {
                this.newEnquiry.client_id = '';
                this.newEnquiry.client_name = '';
                this.newEnquiry.email = '';
                this.newEnquiry.phone = '';
                this.newEnquiry.address = '';
                this.newEnquiry.state = '';
                this.newEnquiry.pan = '';
                this.newEnquiry.aadhar = '';
                this.newEnquiry.gst = '';
                this.newEnquiry.client_photo = '';
            }
        },

        async convertToClient(enquiryId) {
            try {
                const res = await fetch(url('/clients/convert'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ enquiry_id: enquiryId })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Converted to Client successfully!');
                    this.fetchData(this.pagination.current_page);
                } else {
                    this.showToast(data.message || 'Failed to convert');
                }
            } catch (e) {
                this.showToast('Connection error');
            }
        },

        async restoreEnquiry(id) {
            try {
                const res = await fetch(url('/enquiries/restore'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Enquiry restored');
                    this.fetchData(this.pagination.current_page);
                }
            } catch (e) {
                this.showToast('Restore failed');
            }
        },

        closeAllModals() {
            this.showModal = false;
            this.showAssignModal = false;
            this.showApprovalModal = false;
            this.confirmModal.show = false;
            this.activePreview = null;
        },

        openPreviewModal(enquiry) {
            this.closeAllModals();
            this.activePreview = enquiry;
        },
        sortBy(key) {
            if (this.sortKey === key) {
                this.sortOrder = this.sortOrder === 'asc' ? 'desc' : 'asc';
            } else {
                this.sortKey = key;
                this.sortOrder = 'asc';
            }
            // In real app, would call fetchData with sort params
        },
        async validateField(field) {
            const res = await fetch(url('/enquiries/validate'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ field, value: this.newEnquiry[field] })
            });
            const data = await res.json();
            if (data.status === 'error') {
                this.errors[field] = data.errors[field];
            } else {
                delete this.errors[field];
            }
        },
        async uploadClientPhoto(event) {
            const file = event.target.files[0];
            if (!file) return;

            const formData = new FormData();
            formData.append('photo', file);

            try {
                const res = await fetch(url('/enquiries/upload-photo'), {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.newEnquiry.client_photo = data.url;
                    this.showToast('Photo uploaded successfully');
                } else {
                    this.showToast(data.message || 'Error uploading photo');
                }
            } catch (e) {
                this.showToast('Upload failed');
            }
        },
        get filteredEnquiries() {
            return this.enquiries;
        },
        toggleSelectAll() {
            if (this.selectAll) {
                this.selected = this.enquiries.map(e => e.id);
            } else {
                this.selected = [];
            }
        },
        showToast(msg) {
            this.toast.message = msg;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        async executeConfirm() {
            if (this.confirmModal.callback) {
                try {
                    await this.confirmModal.callback();
                } catch (e) {
                    this.showToast('Action failed');
                }
            }
            this.confirmModal.show = false;
        },
        openEditModal(enquiry) {
            this.closeAllModals();
            this.errors = {};
            this.newEnquiry = JSON.parse(JSON.stringify(enquiry));
            this.showModal = true;
        },
        openNewModal() {
            this.closeAllModals();
            this.errors = {};
            this.newEnquiry = { id: '', client_id: '', client_name: '', email: '', phone: '', message: '', status: 'New', assigned_to: '', service: '', budget: '', address: '', state: '', pan: '', aadhar: '', gst: '', client_photo: '' };
            this.showModal = true;
        },
        async submitEnquiry() {
            const targetUrl = this.newEnquiry.id ? url('/enquiries/update') : url('/enquiries');
            try {
                const res = await fetch(targetUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.newEnquiry)
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast(this.newEnquiry.id ? 'Enquiry updated!' : 'Enquiry saved! Number: ' + data.enquiry_no);
                    this.showModal = false;
                    this.fetchData(this.pagination.current_page);
                } else if (data.errors) {
                    this.errors = data.errors;
                    this.showToast('Please fix the errors');
                } else {
                    this.showToast(data.message || 'Error saving enquiry');
                }
            } catch (e) {
                this.showToast('Connection error');
            }
        },
        async updateStatus(id, status) {
            try {
                const res = await fetch(url('/enquiries/update'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, status })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Status updated to ' + status);
                    this.fetchData(this.pagination.current_page);
                } else {
                    this.showToast(data.message || 'Error updating status');
                }
            } catch (e) {
                this.showToast('Connection error');
            }
        },
        async bulkAction(action) {
            if (this.selected.length === 0) return;
            
            let targetUrl = '';
            let payload = { ids: this.selected };
            
            if (action === 'delete') {
                this.confirmAction('Delete selected enquiries?', async () => {
                    try {
                        const delRes = await fetch(url('/enquiries/bulk-delete'), {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(payload)
                        });
                        const delData = await delRes.json();
                        if (delData.status === 'success') {
                            this.showToast('Bulk action completed');
                            this.showAssignModal = false;
                            this.fetchData(this.pagination.current_page);
                        } else {
                            this.showToast(delData.message || 'Error deleting enquiries');
                        }
                    } catch (e) {
                        this.showToast('Connection error');
                    }
                });
                return;
            } else if (action === 'approve') {
                targetUrl = url('/enquiries/bulk-update');
                payload.updates = { status: 'Approved' };
            } else if (action === 'reject') {
                targetUrl = url('/enquiries/bulk-update');
                payload.updates = { status: 'Rejected' };
            } else if (action === 'assign') {
                if (!this.bulkAssignTo) return;
                targetUrl = url('/enquiries/bulk-update');
                payload.updates = { assigned_to: this.bulkAssignTo };
            }

            try {
                const res = await fetch(targetUrl, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Bulk action completed');
                    this.showAssignModal = false;
                    this.fetchData(this.pagination.current_page);
                } else {
                    this.showToast(data.message || 'Error updating enquiries');
                }
            } catch (e) {
                this.showToast('Connection error');
            }
        },
        async deleteEnquiry(id) {
            this.closeAllModals();
            this.confirmAction('Are you sure you want to delete this enquiry?', async () => {
                try {
                    const res = await fetch(url('/enquiries/delete'), {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    });
                    const data = await res.json();
                    if (data.status === 'success') {
                        this.showToast('Enquiry deleted');
                        this.fetchData(this.pagination.current_page);
                    } else {
                        this.showToast(data.message || 'Error deleting enquiry');
                    }
                } catch (e) {
                    this.showToast('Connection error');
                }
            });
        },
        exportToCSV() {
            if (this.enquiries.length === 0) return;
            const q = String.fromCharCode(34);
            const headers = ['Enquiry No', 'Client Name', 'Email', 'Phone', 'Service', 'Budget', 'Status', 'Assigned To', 'Date'];
            const rows = this.enquiries.map(e => [
                e.enquiry_no,
                e.client_name,
                e.email,
                e.phone,
                e.service,
                e.budget,
                e.status,
                this.staffList.find(s => s.id === e.assigned_to)?.name || this.rolesList.find(r => r.id === e.assigned_to)?.name || 'Unassigned',
                e.created_at
            ]);
            let csvContent = 'data:text/csv;charset=utf-8,' 
                + headers.join(',') + '\n' 
                + rows.map(r => r.map(cell => q + (cell||'').toString().split(q).join(q+q) + q).join(',')).join('\n');
            
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement('a');
            link.setAttribute('href', encodedUri);
            link.setAttribute('download', 'enquiries_export.csv');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        },
        copySelected() {
            if (this.selected.length === 0) return;
            const toCopy = this.enquiries.filter(e => this.selected.includes(e.id));
            let text = toCopy.map(e => 'Enquiry: ' + e.enquiry_no + ' | Client: ' + e.client_name + ' | Email: ' + e.email + ' | Phone: ' + (e.phone || '-') + ' | Status: ' + e.status).join('\n');
            navigator.clipboard.writeText(text).then(() => {
                this.showToast('Copied to clipboard!');
            }).catch(err => {
                this.showToast('Failed to copy');
            });
        },
        createApproval(enquiry) {
            this.closeAllModals();
            this.newApproval = {
                enquiry_id: enquiry.id,
                client_name: enquiry.client_name,
                email: enquiry.email,
                subject: 'Approval for: ' + (enquiry.service || 'Enquiry'),
                amount: 0,
                approval_date: new Date().toISOString().split('T')[0]
            };
            this.showApprovalModal = true;
        },
        async submitApproval() {
            try {
                const res = await fetch(url('/approvals'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.newApproval)
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showApprovalModal = false;
                    window.location.href = url('/approvals?open=' + data.id);
                } else {
                    this.showToast(data.message || 'Error creating approval');
                }
            } catch (e) {
                this.showToast('Connection error');
            }
        }
    }));
});
</script>

</body>
</html>
