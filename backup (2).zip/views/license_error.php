<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>License Required</title>
    <style>
        body { font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f3f4f6; }
        .card { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); width: 100%; max-width: 400px; text-align: center; }
        input { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 4px; box-sizing: border-box; }
        button { width: 100%; padding: 10px; background: #2563eb; color: white; border: none; border-radius: 4px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="card">
        <h2>License Required</h2>
        <p>This application is not licensed for this domain.</p>
        <form method="POST">
            <input type="password" name="license_key" placeholder="Enter License Key" required>
            <button type="submit">Activate</button>
        </form>
    </div>
</body>
</html>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $key = $_POST['license_key'] ?? '';
    // Basic verification: in a real scenario, you'd verify the key structure
    file_put_contents(__DIR__ . '/../storage/db/license.key', $key);
    header("Refresh:0");
}
?>
