<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roles & Permissions - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="rolesComponent" class="min-h-screen flex flex-col" x-cloak>

    <?php 
    $activePage = 'roles';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <!-- Actions Toolbar -->
    <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 shadow-sm sticky top-0 z-30 no-print">
        <h1 class="text-xl md:text-2xl tracking-tight">Roles & Permissions</h1>
        <button type="button" @click="createNewRole()" class="btn-google text-sm font-semibold shadow-md hover:shadow-lg transition-all flex items-center justify-center">
            <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
            New Role
        </button>
    </div>

    <main class="flex-grow p-4 md:p-8 grid grid-cols-1 md:grid-cols-4 gap-8 max-w-full mx-auto w-full">
        
        <!-- Role Sidebar -->
        <div class="col-span-1 space-y-4">
            <h2 class="text-lg mb-2 md:mb-4">Roles</h2>
            <div class="card p-2 flex flex-row md:flex-col overflow-x-auto md:overflow-x-hidden space-x-2 md:space-x-0 md:space-y-1">
                <template x-for="role in roles" :key="role.id">
                    <button type="button" @click="activeRole = JSON.parse(JSON.stringify(role))" 
                            :class="activeRole?.id === role.id ? 'bg-blue-50 text-blue-700' : 'hover:bg-gray-50 text-gray-700'"
                            class="whitespace-nowrap md:whitespace-normal flex-shrink-0 md:flex-shrink w-auto md:w-full text-left px-4 py-2 rounded-md text-sm font-medium transition"
                            x-text="role.name"></button>
                </template>
            </div>
        </div>

        <!-- Permissions Editor -->
        <div class="col-span-1 md:col-span-3">
            <h2 class="text-lg mb-2 md:mb-4">Permissions</h2>
            <template x-if="activeRole">
                <div class="card p-4 md:p-8 space-y-6 md:space-y-8">
                    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        <div class="space-y-1 w-full lg:w-1/2">
                            <label class="text-xs font-medium text-gray-500 uppercase">Role Name</label>
                            <input type="text" x-model="activeRole.name" class="text-xl md:text-2xl font-medium border-b border-transparent focus:border-blue-600 outline-none w-full">
                        </div>
                        <div class="flex items-center justify-end space-x-3">
                            <template x-if="activeRole.id && activeRole.id !== 'admin'">
                                <button type="button" @click="deleteRole(activeRole.id)" class="text-sm text-red-600 hover:underline font-medium">Delete Role</button>
                            </template>
                            <button type="button" @click="saveRole()" class="btn-google whitespace-nowrap">Save Role</button>
                        </div>
                    </div>

                    <div class="overflow-x-auto border rounded-lg">
                        <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                            <thead>
                                <tr class="text-xs font-medium text-gray-500 uppercase border-b bg-gray-50">
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs">Module</th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs text-center">View</th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs text-center">Edit/Create</th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs text-center">Delete</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y">
                                <template x-for="mod in modules" :key="mod">
                                    <tr class="hover:bg-gray-50">
                                        <td class="px-3 md:px-4 py-4 font-medium capitalize" x-text="mod"></td>
                                        <template x-for="action in ['view', 'edit', 'delete']">
                                            <td class="px-3 md:px-4 py-4 text-center">
                                                <select x-model="activeRole.permissions[mod][action]" class="w-full sm:w-auto text-xs border rounded px-2 py-1 outline-none focus:ring-1 focus:ring-blue-600 bg-white">
                                                    <option value="none">None</option>
                                                    <option value="own">Own Only</option>
                                                    <option value="global">Global</option>
                                                </select>
                                            </td>
                                        </template>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                </div>
            </template>
            <template x-if="!activeRole">
                <div class="h-64 card flex items-center justify-center text-gray-400 italic">
                    Select a role to manage permissions
                </div>
            </template>
        </div>

    </main>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-50" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
            <div class="fixed inset-0 transition-opacity bg-black bg-opacity-25"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl">
                <h3 class="text-lg font-medium leading-6 text-gray-900 mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('rolesComponent', () => ({
        roles: <?php echo json_encode($roles ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        modules: <?php echo json_encode($modules ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        activeRole: null,
        toast: { show: false, message: '' },
        confirmModal: { show: false, message: '', callback: null },
        showToast(msg) {
            this.toast.message = msg;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) {
                this.confirmModal.callback();
            }
            this.confirmModal.show = false;
        },
        async saveRole() {
            try {
                const res = await fetch(url('/roles'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.activeRole)
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Role saved successfully');
                    window.location.reload();
                }
            } catch(e) { this.showToast('Network error'); }
        },
        async deleteRole(id) {
            this.confirmAction('Are you sure you want to delete this role?', async () => {
                try {
                    const res = await fetch(url('/roles/delete'), {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    });
                    const data = await res.json();
                    if (data.status === 'success') {
                        this.showToast('Role deleted');
                        window.location.reload();
                    } else {
                        this.showToast(data.message || 'Error deleting role');
                    }
                } catch(e) { this.showToast('Network error'); }
            });
        },
        createNewRole() {
            const newRole = { id: '', name: 'New Role', permissions: {} };
            this.modules.forEach(m => {
                newRole.permissions[m] = { view: 'none', edit: 'none', delete: 'none' };
            });
            this.activeRole = newRole;
        }
    }));
});
</script>

</body>
</html>
