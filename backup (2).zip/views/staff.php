<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Management - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="staffComponent" class="min-h-screen flex flex-col" x-cloak>

    <?php 
    $activePage = 'staff';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <!-- Actions Toolbar -->
    <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4 shadow-sm sticky top-0 z-30 no-print">
        <div class="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 flex-grow">
            <div class="relative group">
                <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 group-focus-within:text-blue-500 transition-colors">
                    <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                </span>
                <input type="text" x-model="searchQuery" autocomplete="off" placeholder="Search staff..." class="bg-gray-50 border border-gray-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full lg:w-64 transition-all">
            </div>

             <div class="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                 <select x-model="filterRole" @change="fetchData()" class="bg-gray-50 border border-gray-200 rounded-lg py-2 px-3 text-sm focus:ring-2 focus:ring-blue-500 outline-none flex-shrink-0 cursor-pointer hover:bg-white transition-colors">
                     <option value="">All Roles</option>
                     <template x-for="r in roles" :key="r.id">
                         <option :value="r.id" x-text="r.name"></option>
                     </template>
                 </select>

                 <button type="button" @click="showTrash = !showTrash; fetchData()" class="flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all flex-shrink-0" :class="showTrash ? 'bg-red-100 text-red-700 shadow-inner' : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-white hover:shadow-sm'">
                     <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                     <span x-text="showTrash ? 'Viewing Trash' : 'Trash'"></span>
                 </button>
                 <button type="button" @click="filterRole=''; searchQuery=''; showTrash=false; fetchData()" class="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline px-2 flex-shrink-0">Reset</button>
             </div>
        </div>
        <div class="flex items-center justify-end space-x-3">
            <button type="button" @click="addStaff()" class="flex-1 lg:flex-none justify-center btn-google py-2 px-6 rounded-lg text-sm font-semibold shadow-md hover:shadow-lg transition-all flex items-center whitespace-nowrap">
                <svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
                Add Staff
            </button>
        </div>
    </div>

    <main class="flex-grow p-4 md:p-8 max-w-full mx-auto w-full">
        <h1 class="text-xl md:text-2xl mb-4 md:mb-8">Staffs</h1>

        <div class="card overflow-x-auto">
            <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                <thead class="bg-gray-50 border-b">
                    <tr>
                        <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Name</th>
                        <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Username</th>
                        <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Role</th>
                        <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y">
                    <template x-for="member in filteredStaff" :key="member.id">
                        <tr class="hover:bg-gray-50 transition group">
                            <td class="px-3 md:px-4 py-4 font-medium" x-text="member.name"></td>
                            <td class="px-3 md:px-4 py-4 text-gray-600" x-text="member.username"></td>
                            <td class="px-3 md:px-4 py-4">
                                <span class="px-2 py-1 text-xs rounded-full bg-blue-100 text-blue-700 font-medium" 
                                      x-text="roles.find(r => r.id === member.role_id)?.name || 'Unknown'"></span>
                            </td>
                            <td class="px-3 md:px-4 py-4 space-x-1 md:space-x-2 whitespace-nowrap text-right">
                                <button type="button" @click="editStaff(member)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">Edit</button>
                                <?php if (\App\Services\PermissionHelper::check('staff', 'delete')): ?>
                                    <template x-if="!member.deleted_at">
                                        <button type="button" @click="deleteStaff(member.id)" class="text-gray-400 hover:text-red-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-red-50"><svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                    </template>
                                    <template x-if="member.deleted_at">
                                        <button type="button" @click="restoreStaff(member.id)" class="text-gray-400 hover:text-green-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-green-50"><svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg></button>
                                    </template>
                                <?php endif; ?>
                            </td>
                        </tr>
                    </template>
                </tbody>
            </table>
            <template x-if="filteredStaff.length === 0">
                <div class="p-12 text-center text-gray-500 italic">
                    No staff members found matching your search.
                </div>
            </template>
        </div>
    </main>

    <!-- Staff Modal -->
    <div x-show="showModal" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
            
            <div class="inline-block w-full max-w-md p-6 md:p-8 bg-white shadow-2xl rounded-2xl transform transition-all">
                <h3 class="text-xl font-medium mb-6" x-text="activeStaff.id ? 'Edit Staff Member' : 'Add New Staff Member'"></h3>
                
                <div class="space-y-4">
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Full Name*</label>
                        <input type="text" x-model="activeStaff.name" class="w-full border-b focus:border-blue-600 outline-none py-1">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Username*</label>
                        <input type="text" x-model="activeStaff.username" class="w-full border-b focus:border-blue-600 outline-none py-1">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Password <span x-show="activeStaff.id" class="text-gray-400">(leave blank to keep current)</span></label>
                        <input type="password" x-model="activeStaff.password" class="w-full border-b focus:border-blue-600 outline-none py-1">
                    </div>
                    <div class="space-y-1">
                        <label class="text-xs font-medium text-gray-500">Assign Role*</label>
                        <select x-model="activeStaff.role_id" class="w-full border-b focus:border-blue-600 outline-none py-1 bg-white">
                            <option value="">Select a role</option>
                            <template x-for="role in roles" :key="role.id">
                                <option :value="role.id" x-text="role.name"></option>
                            </template>
                        </select>
                    </div>
                </div>

                <div class="mt-8 flex justify-end space-x-3">
                    <button type="button" @click="showModal = false" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800">Cancel</button>
                    <button type="button" @click="saveStaff()" class="btn-google">Save Member</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-50" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center">
            <div class="fixed inset-0 transition-opacity bg-black bg-opacity-25"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl">
                <h3 class="text-lg font-medium leading-6 text-gray-900 mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600 hover:text-gray-800">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('staffComponent', () => ({
        staff: <?php echo json_encode($staff ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        roles: <?php echo json_encode($roles ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        showModal: false,
        searchQuery: '',
        filterRole: '',
        activeStaff: { id: '', name: '', username: '', password: '', role_id: '' },
        toast: { show: false, message: '' },
        confirmModal: { show: false, message: '', callback: null },

        init() {
            setTimeout(() => {
                document.querySelectorAll('input[type="text"][x-model]').forEach(el => {
                    if (el.getAttribute('x-model') === 'searchQuery') {
                        el.value = '';
                        el.dispatchEvent(new Event('input'));
                    }
                });
            }, 50);
        },

        get filteredStaff() {
            try {
                let list = JSON.parse(JSON.stringify(this.staff || []));
                if (!Array.isArray(list)) list = Object.values(list);

                if (this.searchQuery) {
                    const q = String(this.searchQuery).toLowerCase();
                    list = list.filter(s => 
                        String(s.name || '').toLowerCase().includes(q) ||
                        String(s.username || '').toLowerCase().includes(q)
                    );
                }
                if (this.filterRole) {
                    list = list.filter(s => String(s.role_id) === String(this.filterRole));
                }
                return list;
            } catch (e) {
                console.error("Filter error:", e);
                return this.staff || [];
            }
        },
        showToast(msg) {
            this.toast.message = msg;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) {
                this.confirmModal.callback();
            }
            this.confirmModal.show = false;
        },
        async saveStaff() {
            try {
                const res = await fetch(url('/staff'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(this.activeStaff)
                });
                const data = await res.json();
                if (data.status === 'success') {
                    this.showToast('Staff member saved');
                    window.location.reload();
                } else {
                    this.showToast(data.message || 'Error saving staff member');
                }
            } catch(e) { this.showToast('Network Error'); }
        },
        async deleteStaff(id) {
            this.confirmAction('Are you sure you want to delete this staff member?', async () => {
                try {
                    const res = await fetch(url('/staff/delete'), {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    });
                    const data = await res.json();
                    if (data.status === 'success') {
                        this.showToast('Staff member deleted');
                        window.location.reload();
                    } else {
                        this.showToast(data.message || 'Error deleting staff member');
                    }
                } catch(e) { this.showToast('Network Error'); }
            });
        },
        addStaff() {
            this.activeStaff = { id: '', name: '', username: '', password: '', role_id: '' };
            this.showModal = true;
        },
        editStaff(member) {
            this.activeStaff = JSON.parse(JSON.stringify(member));
            this.activeStaff.password = ''; // Clear password field for security
            this.showModal = true;
        }
    }));
});
</script>

</body>
</html>
