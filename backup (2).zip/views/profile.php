<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="{ 
    user: <?php echo htmlspecialchars(json_encode($user)); ?>,
    passwords: { current: '', new: '', confirm: '' },
    toast: { show: false, message: '', type: 'success' },
    showToast(msg, type = 'success') {
        this.toast.message = msg;
        this.toast.type = type;
        this.toast.show = true;
        setTimeout(() => this.toast.show = false, 3000);
    },
    async updateProfile() {
        if (this.passwords.new && this.passwords.new !== this.passwords.confirm) {
            this.showToast('Passwords do not match', 'error');
            return;
        }

        const res = await fetch(url('/profile'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                name: this.user.name,
                email: this.user.email,
                current_password: this.passwords.current,
                new_password: this.passwords.new
            })
        });
        const data = await res.json();
        if (data.status === 'success') {
            this.showToast(data.message);
            this.passwords = { current: '', new: '', confirm: '' };
        } else {
            this.showToast(data.message, 'error');
        }
    }
}" class="min-h-screen flex flex-col">

    <?php 
    $activePage = 'profile';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <main class="flex-grow p-4 sm:p-8 max-w-4xl mx-auto w-full">
        <h1 class="text-xl sm:text-2xl mb-6 sm:mb-8 font-medium">My Profile</h1>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 sm:gap-8">
            <div class="md:col-span-1">
                <div class="card p-6 text-center">
                    <div class="w-24 h-24 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-3xl mx-auto mb-4">
                        <?= substr($user['name'], 0, 1) ?>
                    </div>
                    <h2 class="text-lg font-medium"><?php echo htmlspecialchars($user['name']) ?></h2>
                    <p class="text-sm text-gray-500"><?= htmlspecialchars($_SESSION['role_name']) ?></p>
                </div>
            </div>

            <div class="md:col-span-2 space-y-6">
                <div class="card p-6">
                    <h3 class="text-lg font-medium mb-6">Personal Information</h3>
                    <form @submit.prevent="updateProfile()" class="space-y-4">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="space-y-1">
                                <label class="text-sm font-medium text-gray-600">Full Name</label>
                                <input type="text" x-model="user.name" class="w-full border rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                            <div class="space-y-1">
                                <label class="text-sm font-medium text-gray-600">Email Address</label>
                                <input type="email" x-model="user.email" class="w-full border rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500">
                            </div>
                        </div>

                        <div class="border-t pt-6 mt-6">
                            <h3 class="text-lg font-medium mb-6">Change Password</h3>
                            <div class="space-y-4">
                                <div class="space-y-1">
                                    <label class="text-sm font-medium text-gray-600">Current Password</label>
                                    <input type="password" x-model="passwords.current" class="w-full border rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500" placeholder="Required to change password">
                                </div>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div class="space-y-1">
                                        <label class="text-sm font-medium text-gray-600">New Password</label>
                                        <input type="password" x-model="passwords.new" class="w-full border rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                    <div class="space-y-1">
                                        <label class="text-sm font-medium text-gray-600">Confirm New Password</label>
                                        <input type="password" x-model="passwords.confirm" class="w-full border rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-blue-500">
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="pt-6 flex justify-end">
                            <button type="submit" class="btn-google">Update Profile</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <!-- Toast -->
    <div x-show="toast.show" 
         x-transition
         class="fixed bottom-8 left-1/2 transform -translate-x-1/2 px-6 py-3 rounded-full text-white shadow-lg z-50"
         :class="toast.type === 'success' ? 'bg-gray-900' : 'bg-red-600'"
         x-text="toast.message">
    </div>

</div>

</body>
</html>
