<nav class="bg-white border-b px-4 md:px-6 py-3 flex items-center justify-between sticky top-0 z-40" x-data="{ mobileMenuOpen: false }">
    <div class="flex items-center space-x-4 md:space-x-8">
        <div class="flex items-center space-x-2 md:space-x-3">
            <button @click="mobileMenuOpen = !mobileMenuOpen" class="md:hidden text-gray-500 hover:text-blue-600 focus:outline-none">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path x-show="!mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path><path x-show="mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
            </button>
            <?php if (!empty($settings['logo_url'])): ?>
                <img src="<?php echo url($settings['logo_url']) ?>" class="h-6 md:h-8">
            <?php endif; ?>
            <span class="text-lg md:text-xl font-medium text-blue-600">Client Portal</span>
        </div>
        <div class="hidden md:flex space-x-6 text-sm font-medium text-gray-500">
            <a href="<?php echo url('/portal/dashboard'); ?>" class="<?php echo $activePage === 'dashboard' ? 'text-blue-600 border-b-2 border-blue-600 pb-1 -mb-3' : 'hover:text-blue-600 transition' ?>">Dashboard</a>
            <a href="<?php echo url('/portal/approvals'); ?>" class="<?php echo $activePage === 'approvals' ? 'text-blue-600 border-b-2 border-blue-600 pb-1 -mb-3' : 'hover:text-blue-600 transition' ?>">Approvals</a>
            <a href="<?php echo url('/portal/invoices'); ?>" class="<?php echo $activePage === 'invoices' ? 'text-blue-600 border-b-2 border-blue-600 pb-1 -mb-3' : 'hover:text-blue-600 transition' ?>">Invoices</a>
            <a href="<?php echo url('/portal/payments'); ?>" class="<?php echo $activePage === 'payments' ? 'text-blue-600 border-b-2 border-blue-600 pb-1 -mb-3' : 'hover:text-blue-600 transition' ?>">Payments</a>
        </div>
    </div>
    <div class="flex items-center space-x-2 md:space-x-4">
        <div @click="showProfile = true" class="flex items-center space-x-2 cursor-pointer hover:bg-gray-100 p-1 rounded-full pr-2 md:pr-3 transition">
            <div class="w-7 h-7 md:w-8 md:h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-[10px] md:text-xs" x-text="client.client_name.charAt(0)"></div>
            <span class="text-xs md:text-sm font-medium hidden sm:inline" x-text="client.client_name"></span>
        </div>
        <a href="<?php echo url('/portal/logout'); ?>" class="text-gray-400 hover:text-red-600 transition">
            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
        </a>
    </div>

    <!-- Mobile Nav -->
    <div x-show="mobileMenuOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 -translate-y-4"
         x-transition:enter-end="opacity-100 translate-y-0"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 translate-y-0"
         x-transition:leave-end="opacity-0 -translate-y-4"
         class="absolute top-full left-0 right-0 bg-white border-b shadow-lg p-4 space-y-3 md:hidden z-50">
        <a href="<?php echo url('/portal/dashboard'); ?>" class="block px-4 py-2 rounded-lg <?php echo $activePage === 'dashboard' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-gray-600 hover:bg-gray-50' ?>">Dashboard</a>
        <a href="<?php echo url('/portal/approvals'); ?>" class="block px-4 py-2 rounded-lg <?php echo $activePage === 'approvals' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-gray-600 hover:bg-gray-50' ?>">Approvals</a>
        <a href="<?php echo url('/portal/invoices'); ?>" class="block px-4 py-2 rounded-lg <?php echo $activePage === 'invoices' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-gray-600 hover:bg-gray-50' ?>">Invoices</a>
        <a href="<?php echo url('/portal/payments'); ?>" class="block px-4 py-2 rounded-lg <?php echo $activePage === 'payments' ? 'bg-blue-50 text-blue-600 font-bold' : 'text-gray-600 hover:bg-gray-50' ?>">Payments</a>
    </div>
</nav>

<!-- Profile Modal -->
<div x-show="showProfile" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
    <div class="flex items-center justify-center min-h-screen px-4">
        <div @click="showProfile = false" class="fixed inset-0 bg-black bg-opacity-25"></div>
        <div class="inline-block w-full max-w-md p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-10">
            <div class="text-center mb-6">
                <div class="w-20 h-20 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-2xl mx-auto mb-4" x-text="client.client_name.charAt(0)"></div>
                <h3 class="text-xl font-medium" x-text="client.client_name"></h3>
                <p class="text-sm text-gray-500" x-text="client.email"></p>
            </div>
            <div class="space-y-4 text-sm border-t pt-6">
                <div class="flex justify-between"><span class="text-gray-400 font-medium">Phone</span><span x-text="client.phone"></span></div>
                <div class="border-t pt-4">
                    <h4 class="font-medium text-gray-700 mb-4">Change Password</h4>
                    <div class="space-y-3">
                        <input type="password" x-model="passwords.current" placeholder="Current Password" class="w-full border rounded px-3 py-2 outline-none focus:ring-1 focus:ring-blue-500">
                        <input type="password" x-model="passwords.new" placeholder="New Password" class="w-full border rounded px-3 py-2 outline-none focus:ring-1 focus:ring-blue-500">
                        <input type="password" x-model="passwords.confirm" placeholder="Confirm New Password" class="w-full border rounded px-3 py-2 outline-none focus:ring-1 focus:ring-blue-500">
                        <button @click="updatePassword()" class="w-full bg-blue-600 text-white py-2 rounded font-medium hover:bg-blue-700 transition">Update Password</button>
                    </div>
                </div>
            </div>
            <button type="button" @click="showProfile = false" class="w-full mt-4 text-gray-400 hover:text-gray-600 text-xs text-center">Close</button>
        </div>
    </div>
</div>

<!-- Toast -->
<div x-show="toast.show" 
     x-transition
     class="fixed bottom-8 left-1/2 transform -translate-x-1/2 px-6 py-3 rounded-full text-white shadow-lg z-50"
     :class="toast.type === 'success' ? 'bg-gray-900' : 'bg-red-600'"
     x-text="toast.message">
</div>
