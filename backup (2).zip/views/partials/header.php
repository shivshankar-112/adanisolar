<?php
$settings = $settings ?? [];
$activePage = $activePage ?? '';
?>
<header class="bg-white border-b px-4 md:px-6 py-4 sticky top-0 z-50" x-data="{ mobileMenuOpen: false }">
    <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4 md:space-x-8">
            <!-- Mobile Menu Toggle -->
            <button @click="mobileMenuOpen = !mobileMenuOpen" class="md:hidden text-gray-500 hover:text-gray-700 focus:outline-none">
                <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path x-show="!mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    <path x-show="mobileMenuOpen" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
                </svg>
            </button>

            <a href="<?php echo url('/dashboard'); ?>" class="flex items-center space-x-2 md:space-x-3">
                <?php if (!empty($settings['logo_url'])): ?>
                    <img src="<?php echo url($settings['logo_url']) ?>" alt="Logo" class="h-7 w-7 md:h-8 md:w-8 object-contain">
                <?php else: ?>
                    <div class="h-7 w-7 md:h-8 md:w-8 bg-blue-600 rounded-md flex items-center justify-center text-white font-bold text-[10px] md:text-xs">CRM</div>
                <?php endif; ?>
                <span class="text-lg md:text-xl font-medium text-gray-700 hidden sm:inline-block"><?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?></span>
            </a>

            <!-- Desktop Nav -->
            <nav class="hidden md:flex space-x-4 text-sm font-medium">
                <?php if (\App\Services\PermissionHelper::check('dashboard', 'view')): ?>
                <a href="<?php echo url('/dashboard'); ?>" class="<?= $activePage === 'dashboard' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Dashboard</a>
                <?php endif; ?>

                <?php if (isset($_SESSION['user_id'])): ?>
                <a href="<?php echo url('/clients'); ?>" class="<?= $activePage === 'clients' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Clients</a>
                <a href="<?php echo url('/enquiries'); ?>" class="<?= $activePage === 'enquiries' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Enquiries</a>
                <?php if (\App\Services\PermissionHelper::check('approvals', 'view')): ?>
                <a href="<?php echo url('/approvals'); ?>" class="<?= $activePage === 'approvals' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Approvals</a>
                <?php endif; ?>
                <?php endif; ?>
                
                <?php if (\App\Services\PermissionHelper::check('invoices', 'view')): ?>
                <a href="<?php echo url('/invoices'); ?>" class="<?= $activePage === 'invoices' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Invoices</a>
                <?php endif; ?>
                
                <?php if (\App\Services\PermissionHelper::check('payments', 'view')): ?>
                <a href="<?php echo url('/payments'); ?>" class="<?= $activePage === 'payments' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Payments</a>
                <?php endif; ?>
                
                <?php if (\App\Services\PermissionHelper::check('staff', 'view')): ?>
                <a href="<?php echo url('/staff'); ?>" class="<?= $activePage === 'staff' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Staff</a>
                <?php endif; ?>
                
                <?php if (\App\Services\PermissionHelper::check('roles', 'view')): ?>
                <a href="<?php echo url('/roles'); ?>" class="<?= $activePage === 'roles' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Roles</a>
                <?php endif; ?>
                
                <?php if (\App\Services\PermissionHelper::check('settings', 'view')): ?>
                <a href="<?php echo url('/settings'); ?>" class="<?= $activePage === 'settings' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Settings</a>
                <?php endif; ?>

                <a href="<?php echo url('/help'); ?>" class="<?= $activePage === 'help' ? 'text-blue-600 border-b-2 border-blue-600 pb-1' : 'text-gray-600 hover:text-gray-800' ?>">Help</a>
            </nav>
        </div>

        <div class="flex items-center space-x-3 md:space-x-6">
            <!-- Notifications -->
            <div x-data="{ 
                open: false, 
                notifications: [], 
                unreadCount: 0,
                async fetchNotifications() {
                    const res = await fetch(url('/notifications'));
                    const data = await res.json();
                    this.notifications = data.notifications;
                    this.unreadCount = data.unread_count;
                },
                async markRead(id) {
                    await fetch(url('/notifications/mark-read'), {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ id })
                    });
                    this.fetchNotifications();
                }
            }" x-init="fetchNotifications(); setInterval(() => fetchNotifications(), 30000)">
                <button @click="open = true" class="relative text-gray-500 hover:text-gray-700 transition p-1">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                    <template x-if="unreadCount > 0">
                        <span class="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center border-2 border-white" x-text="unreadCount"></span>
                    </template>
                </button>

                <!-- Notification Drawer -->
                <div x-show="open" class="fixed inset-0 z-[100] overflow-hidden" style="display: none;">
                    <!-- Backdrop -->
                    <div x-show="open" 
                         x-transition:enter="transition-opacity ease-linear duration-300"
                         x-transition:enter-start="opacity-0"
                         x-transition:enter-end="opacity-100"
                         x-transition:leave="transition-opacity ease-linear duration-300"
                         x-transition:leave-start="opacity-100"
                         x-transition:leave-end="opacity-0"
                         @click="open = false"
                         class="absolute inset-0 bg-black bg-opacity-40 backdrop-blur-sm"></div>

                    <!-- Drawer Panel -->
                    <div class="fixed inset-y-0 right-0 max-w-full flex">
                        <div x-show="open"
                             x-transition:enter="transform transition ease-in-out duration-300"
                             x-transition:enter-start="translate-x-full"
                             x-transition:enter-end="translate-x-0"
                             x-transition:leave="transform transition ease-in-out duration-300"
                             x-transition:leave-start="translate-x-0"
                             x-transition:leave-end="translate-x-full"
                             class="w-screen max-w-md bg-white shadow-2xl flex flex-col h-full">
                            
                            <!-- Header -->
                            <div class="px-6 py-4 border-b flex items-center justify-between bg-gray-50">
                                <div class="flex items-center space-x-2">
                                    <span class="text-xs font-bold uppercase tracking-widest text-gray-500">Notifications</span>
                                    <template x-if="unreadCount > 0">
                                        <span class="bg-red-500 text-white text-[10px] px-1.5 py-0.5 rounded-full font-bold" x-text="unreadCount"></span>
                                    </template>
                                </div>
                                <div class="flex items-center space-x-4">
                                    <button @click="fetchNotifications()" class="text-[10px] text-blue-600 hover:underline">Refresh</button>
                                    <button @click="open = false" class="text-gray-400 hover:text-gray-600 transition">
                                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                                    </button>
                                </div>
                            </div>

                            <!-- List -->
                            <div class="flex-grow overflow-y-auto">
                                <template x-for="n in notifications" :key="n.id">
                                    <div class="px-6 py-4 border-b last:border-0 hover:bg-gray-50 transition cursor-pointer" 
                                         :class="{'bg-blue-50/30': !n.is_read}"
                                         @click="markRead(n.id); if(n.link !== '#') window.location.href = url(n.link)">
                                        <div class="flex justify-between items-start mb-1">
                                            <span class="text-sm font-bold text-gray-800" x-text="n.title"></span>
                                            <span class="text-[10px] text-gray-400 whitespace-nowrap ml-4" x-text="n.created_at"></span>
                                        </div>
                                        <p class="text-xs text-gray-600 leading-normal" x-text="n.message"></p>
                                    </div>
                                </template>
                                <template x-if="notifications.length === 0">
                                    <div class="h-full flex flex-col items-center justify-center p-12 text-center text-gray-400">
                                        <svg class="w-16 h-16 mb-4 opacity-20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"></path></svg>
                                        <p class="italic text-sm">No notifications yet</p>
                                    </div>
                                </template>
                            </div>

                            <!-- Footer -->
                            <div class="p-6 border-t bg-gray-50 mt-auto">
                                <button type="button" @click="open = false" class="w-full bg-white border border-gray-200 text-gray-700 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 transition shadow-sm">Close Drawer</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Global Search -->
            <div class="relative" x-data="{ 
                query: '', 
                results: [], 
                show: false,
                isExpanded: false,
                init() {
                    setTimeout(() => {
                        this.query = '';
                        const el = this.$el.querySelector('input');
                        if(el) { el.value = ''; el.dispatchEvent(new Event('input')); }
                    }, 50);
                },
                async search() {
                    if (this.query.length < 2) { this.results = []; return; }
                    const res = await fetch(url('/search?q=' + encodeURIComponent(this.query)));
                    const data = await res.json();
                    this.results = data.results;
                    this.show = true;
                }
            }" @click.away="show = false; isExpanded = false">
                <div class="relative flex items-center">
                    <button @click="isExpanded = !isExpanded" class="md:hidden text-gray-500 p-1">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </button>
                    <div :class="{'hidden': !isExpanded && window.innerWidth < 768, 'absolute right-0 top-0': isExpanded}" class="md:block">
                        <input type="text" 
                               x-model="query" 
                               autocomplete="off"
                               @input.debounce.300ms="search()" 
                               @focus="if(results.length) show = true"
                               placeholder="Search CRM..." 
                               class="bg-gray-100 border-none rounded-full px-10 py-1.5 text-xs focus:ring-2 focus:ring-blue-500 outline-none w-48 md:w-48 md:focus:w-64 transition-all duration-300">
                        <svg class="w-4 h-4 text-gray-400 absolute left-3 top-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </div>
                </div>
                
                <div x-show="show && results.length" 
                     x-transition
                     class="absolute top-full right-0 mt-2 bg-white rounded-lg shadow-xl border overflow-hidden z-[100] w-72 md:w-80">
                    <template x-for="result in results">
                        <a :href="url(result.url)" class="block px-4 py-2 hover:bg-gray-50 border-b last:border-0 transition">
                            <div class="flex items-center justify-between">
                                <span class="text-[9px] font-bold uppercase text-blue-600" x-text="result.type"></span>
                                <span class="text-[9px] text-gray-400" x-text="result.title"></span>
                            </div>
                            <div class="text-xs font-medium text-gray-800" x-text="result.subtitle"></div>
                        </a>
                    </template>
                </div>
            </div>

            <div class="flex items-center space-x-2 md:space-x-4">
                <a href="<?php echo url('/profile'); ?>" class="flex items-center space-x-2 cursor-pointer hover:bg-gray-100 p-1 rounded-full md:pr-3 transition">
                    <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-xs"><?php echo substr($_SESSION['name'], 0, 1) ?></div>
                    <span class="text-sm font-medium whitespace-nowrap hidden sm:inline-block"><?php echo htmlspecialchars($_SESSION['name']) ?></span>
                </a>
                <a href="<?php echo url('/logout'); ?>" class="text-gray-400 hover:text-red-600 transition" title="Logout">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path></svg>
                </a>
            </div>
        </div>
    </div>

    <!-- Mobile Nav -->
    <div x-show="mobileMenuOpen" 
         x-transition:enter="transition ease-out duration-200"
         x-transition:enter-start="opacity-0 -translate-y-4"
         x-transition:enter-end="opacity-100 translate-y-0"
         x-transition:leave="transition ease-in duration-150"
         x-transition:leave-start="opacity-100 translate-y-0"
         x-transition:leave-end="opacity-0 -translate-y-4"
         class="md:hidden mt-4 pb-2 border-t pt-4 space-y-1">
        
        <?php if (\App\Services\PermissionHelper::check('dashboard', 'view')): ?>
        <a href="<?php echo url('/dashboard'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'dashboard' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Dashboard</a>
        <?php endif; ?>

        <?php if (isset($_SESSION['user_id'])): ?>
        <a href="<?php echo url('/clients'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'clients' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Clients</a>
        <a href="<?php echo url('/enquiries'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'enquiries' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Enquiries</a>
        <?php if (\App\Services\PermissionHelper::check('approvals', 'view')): ?>
        <a href="<?php echo url('/approvals'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'approvals' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Approvals</a>
        <?php endif; ?>
        <?php endif; ?>
        
        <?php if (\App\Services\PermissionHelper::check('invoices', 'view')): ?>
        <a href="<?php echo url('/invoices'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'invoices' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Invoices</a>
        <?php endif; ?>
        
        <?php if (\App\Services\PermissionHelper::check('payments', 'view')): ?>
        <a href="<?php echo url('/payments'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'payments' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Payments</a>
        <?php endif; ?>
        
        <?php if (\App\Services\PermissionHelper::check('staff', 'view')): ?>
        <a href="<?php echo url('/staff'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'staff' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Staff</a>
        <?php endif; ?>
        
        <?php if (\App\Services\PermissionHelper::check('roles', 'view')): ?>
        <a href="<?php echo url('/roles'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'roles' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Roles</a>
        <?php endif; ?>
        
        <?php if (\App\Services\PermissionHelper::check('settings', 'view')): ?>
        <a href="<?php echo url('/settings'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'settings' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Settings</a>
        <?php endif; ?>

        <a href="<?php echo url('/help'); ?>" class="block px-3 py-2 rounded-md text-base font-medium <?= $activePage === 'help' ? 'bg-blue-50 text-blue-600' : 'text-gray-600 hover:bg-gray-50' ?>">Help</a>
    </div>
</header>

