<footer class="mt-auto py-8 px-6 text-center text-gray-400 text-xs">
    <div class="max-w-7xl mx-auto border-t pt-8">
        <p>&copy; <?php echo date('Y'); ?> <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?>. All rights reserved.</p>
        <p class="mt-1 font-medium text-gray-300">App Version 1.6.0</p>
    </div>
</footer>