<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Payments - Client Portal</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <script src="<?= url('/assets/js/html2pdf.bundle.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
    </style>
</head>
<body class="text-gray-800">

<div x-data="paymentPortal">

    <?php 
    $activePage = 'payments';
    include __DIR__ . '/../partials/client_header.php'; 
    ?>

    <main class="p-4 md:p-8 max-w-7xl mx-auto">
        <header class="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-xl md:text-2xl font-medium">My Payments</h1>
                <p class="text-sm md:text-base text-gray-500">History of payments made for your invoices.</p>
            </div>
        </header>

        <div class="card overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left min-w-[600px] md:min-w-0">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Payment No</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Invoice No</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase text-right">Method</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <template x-for="p in payments" :key="p.id">
                            <tr class="hover:bg-gray-50 transition text-xs md:text-sm">
                                <td class="px-4 md:px-6 py-4 font-medium text-blue-600" x-text="p.payment_no"></td>
                                <td class="px-4 md:px-6 py-4 text-gray-600" x-text="p.invoice_no"></td>
                                <td class="px-4 md:px-6 py-4 text-gray-600" x-text="p.date"></td>
                                <td class="px-4 md:px-6 py-4 font-medium" x-text="'₹' + parseFloat(p.amount).toLocaleString()"></td>
                                <td class="px-4 md:px-6 py-4 text-right text-gray-500" x-text="p.method"></td>
                                <td class="px-4 md:px-6 py-4 text-right">
                                    <button type="button" @click="activePreview = p" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm whitespace-nowrap">View Receipt</button>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
            <template x-if="payments.length === 0">
                <div class="p-8 md:p-12 text-center text-gray-500 italic text-sm">No payment history found.</div>
            </template>
        </div>
    </main>

    <!-- Preview Modal -->
    <div x-show="activePreview" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen p-2 md:p-4 text-center">
            <div @click="activePreview = null" class="fixed inset-0 bg-black bg-opacity-50"></div>
            
            <div class="inline-block w-full max-w-4xl bg-white shadow-2xl rounded-2xl overflow-hidden relative z-10 text-left align-middle transition-all">
                <div class="bg-gray-50 px-4 md:px-8 py-3 md:py-4 border-b flex justify-between items-center">
                    <h3 class="text-base md:text-lg font-medium" x-text="'Payment Receipt: ' + activePreview?.payment_no"></h3>
                    <div class="flex items-center space-x-2 md:space-x-3">
                        <button type="button" @click="downloadPDF(activePreview)" class="bg-blue-600 text-white px-3 md:px-4 py-1 md:py-1.5 rounded text-xs md:text-sm font-bold hover:bg-blue-700 transition flex items-center">
                            <span class="hidden sm:inline">Download</span> PDF
                        </button>
                        <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-600"><svg class="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                    </div>
                </div>

                <div class="p-4 md:p-12 bg-gray-100 flex justify-center overflow-auto max-h-[85vh]">
                    <!-- Standard Receipt Template -->
                    <div id="payment-print-area" class="bg-white shadow-lg mx-auto p-6 md:p-12 origin-top sm:origin-center scale-[0.4] sm:scale-[0.6] md:scale-100" style="width: 210mm; min-height: 148mm;">
                        <div class="flex justify-between items-start border-b-2 border-blue-600 pb-6 mb-8">
                            <div>
                                <h1 class="text-3xl font-bold text-blue-600 mb-2">PAYMENT RECEIPT</h1>
                                <p class="text-sm text-gray-500 uppercase font-bold">Receipt No: <span class="text-gray-900 ml-2" x-text="activePreview?.payment_no"></span></p>
                                <p class="text-sm text-gray-500 uppercase font-bold">Date: <span class="text-gray-900 ml-2" x-text="activePreview?.date"></span></p>
                            </div>
                            <div class="text-right">
                                <template x-if="org.logo_url"><img :src="url(org.logo_url)" class="h-12 ml-auto mb-4 object-contain"></template>
                                <div style="margin-top: 10px; text-align: right;">
                                    <h3 style="margin: 0; font-size: 16px; font-weight: bold; color: #000;" x-text="org.name"></h3>
                                    <p style="margin: 3px 0; font-size: 13px; color: #444;" x-text="'Phone: ' + org.phone"></p>
                                    <p style="margin: 3px 0; font-size: 13px; color: #444;" x-text="'Email: ' + org.email"></p>
                                    <p style="margin: 3px 0; font-size: 13px; color: #444;" x-text="'Website: ' + org.website"></p>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-6">
                            <div class="flex justify-between border-b pb-4">
                                <span class="text-gray-500 uppercase font-bold text-xs">Received From:</span>
                                <span class="font-bold text-lg" x-text="activePreview?.client_name"></span>
                            </div>
                            <div class="flex justify-between border-b pb-4">
                                <span class="text-gray-500 uppercase font-bold text-xs">For Invoice:</span>
                                <span class="font-bold" x-text="activePreview?.invoice_no"></span>
                            </div>
                            <div class="flex justify-between border-b pb-4 text-blue-600">
                                <span class="uppercase font-bold text-xs">Amount Received:</span>
                                <span class="text-2xl font-bold" x-text="'₹' + parseFloat(activePreview?.amount || 0).toLocaleString()"></span>
                            </div>
                            <div class="flex justify-between border-b pb-4">
                                <span class="text-gray-500 uppercase font-bold text-xs">Payment Method:</span>
                                <span class="font-bold" x-text="activePreview?.method"></span>
                            </div>
                        </div>

                        <div class="mt-12 text-center text-gray-400 italic text-sm">This is a computer-generated receipt. No signature is required.</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('paymentPortal', () => ({
        client: <?php echo json_encode($client, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        payments: <?php echo json_encode($payments, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        org: <?php echo json_encode([
            'name' => $settings['org_name'] ?? '',
            'logo_url' => $settings['logo_url'] ?? ''
        ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        showProfile: false,
        passwords: { current: '', new: '', confirm: '' },
        activePreview: null,
        toast: { show: false, message: '', type: 'success' },
        
        showToast(msg, type = 'success') {
            this.toast.message = msg;
            this.toast.type = type;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        async updatePassword() {
            if (!this.passwords.current || !this.passwords.new) {
                this.showToast('Please fill all password fields', 'error');
                return;
            }
            if (this.passwords.new !== this.passwords.confirm) {
                this.showToast('New passwords do not match', 'error');
                return;
            }
            const res = await fetch(url('/portal/profile'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    current_password: this.passwords.current,
                    new_password: this.passwords.new,
                    confirm_password: this.passwords.confirm
                })
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showToast(data.message);
                this.passwords = { current: '', new: '', confirm: '' };
                this.showProfile = false;
            } else {
                this.showToast(data.message, 'error');
            }
        },
        async downloadPDF(payment) {
            this.showToast('Generating PDF...');
            const element = document.getElementById('payment-print-area');
            const opt = {
                margin: 0,
                filename: `Receipt_${payment.payment_no}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { 
                    scale: 2, 
                    useCORS: true,
                    onclone: (clonedDoc) => {
                        const el = clonedDoc.getElementById('payment-print-area');
                        if (el) { el.style.transform = 'none'; el.style.margin = '0'; el.style.position = 'static'; el.style.display = 'block'; }
                    }
                },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    }))
})
</script>

</body>
</html>
