<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Invoices - Client Portal</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <script src="<?= url('/assets/js/html2pdf.bundle.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
    </style>
</head>
<body class="text-gray-800">

<div x-data="invoicePortal">

    <?php 
    $activePage = 'invoices';
    include __DIR__ . '/../partials/client_header.php'; 
    ?>

    <main class="p-4 md:p-8 max-w-7xl mx-auto">
        <header class="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-xl md:text-2xl font-medium">My Invoices</h1>
                <p class="text-sm md:text-base text-gray-500">View and download your invoices.</p>
            </div>
        </header>

        <div class="card overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left min-w-[600px] md:min-w-0">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Invoice No</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Date</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase text-right">Status</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <template x-for="i in invoices" :key="i.id">
                            <tr class="hover:bg-gray-50 transition text-xs md:text-sm">
                                <td class="px-4 md:px-6 py-4 font-medium text-blue-600" x-text="i.invoice_no"></td>
                                <td class="px-4 md:px-6 py-4 text-gray-600" x-text="i.created_at"></td>
                                <td class="px-4 md:px-6 py-4 font-medium" x-text="'₹' + parseFloat(i.amount).toLocaleString()"></td>
                                <td class="px-4 md:px-6 py-4 text-right">
                                    <span :class="{
                                        'bg-green-100 text-green-700': i.status === 'Paid',
                                        'bg-yellow-100 text-yellow-700': i.status === 'Sent',
                                        'bg-gray-100 text-gray-700': i.status === 'Draft'
                                    }" class="px-2 py-0.5 md:py-1 text-[9px] md:text-[10px] rounded-full font-bold uppercase" x-text="i.status"></span>
                                </td>
                                <td class="px-4 md:px-6 py-4 text-right">
                                    <button type="button" @click="activePreview = i" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm whitespace-nowrap">View Invoice</button>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
            <template x-if="invoices.length === 0">
                <div class="p-8 md:p-12 text-center text-gray-500 italic text-sm">You don't have any invoices yet.</div>
            </template>
        </div>
    </main>

    <!-- Preview Modal -->
    <div x-show="activePreview" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen p-2 md:p-4 text-center">
            <div @click="activePreview = null" class="fixed inset-0 bg-black bg-opacity-50"></div>
            
            <div class="inline-block w-full max-w-5xl bg-white shadow-2xl rounded-2xl overflow-hidden relative z-10 text-left align-middle transition-all">
                <div class="bg-gray-50 px-4 md:px-8 py-3 md:py-4 border-b flex justify-between items-center">
                    <h3 class="text-base md:text-lg font-medium" x-text="'Invoice: ' + activePreview?.invoice_no"></h3>
                    <div class="flex items-center space-x-2 md:space-x-3">
                        <button type="button" @click="downloadPDF(activePreview)" class="bg-blue-600 text-white px-3 md:px-4 py-1 md:py-1.5 rounded text-xs md:text-sm font-bold hover:bg-blue-700 transition flex items-center">
                            <span class="hidden sm:inline">Download</span> PDF
                        </button>
                        <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-600"><svg class="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                    </div>
                </div>

                <div class="p-4 md:p-8 bg-gray-100 flex justify-center min-h-[400px] md:min-h-[600px] overflow-auto max-h-[85vh]">
                    <!-- Standard Invoice Template -->
                    <div id="invoice-print-area" class="bg-white shadow-lg mx-auto origin-top sm:origin-center scale-[0.4] sm:scale-[0.6] md:scale-100" style="width: 210mm; min-height: 297mm; padding: 15mm; color: #333;">
                        <div class="flex justify-between items-start border-b-2 border-blue-600 pb-6 mb-6">
                            <div class="w-1/2">
                                <h1 class="text-3xl font-bold text-blue-600 mb-2 tracking-tight">INVOICE</h1>
                                <div class="space-y-0.5">
                                    <p class="text-xs font-bold uppercase text-gray-500">Invoice No: <span class="text-gray-900 ml-2" x-text="activePreview?.invoice_no"></span></p>
                                    <p class="text-xs font-bold uppercase text-gray-500">Date: <span class="text-gray-900 ml-2" x-text="activePreview?.created_at"></span></p>
                                </div>
                                <div class="mt-4 text-left">
                                    <h3 class="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Bill To:</h3>
                                    <p class="text-md font-bold text-gray-900" x-text="activePreview?.client_name"></p>
                                    <p class="text-gray-600 text-xs" x-text="activePreview?.email"></p>
                                </div>
                            </div>
                            <div class="w-1/2 text-right">
                                <template x-if="org.logo_url"><img :src="url(org.logo_url)" class="h-14 ml-auto mb-2 object-contain"></template>
                                <h2 class="text-lg font-bold uppercase tracking-wide" x-text="org.name"></h2>
                                <p class="text-xs text-gray-600" x-text="org.email"></p>
                                <p class="text-xs text-gray-600" x-text="org.phone"></p>
                                <p class="text-xs text-gray-600" x-text="org.website"></p>
                            </div>
                        </div>
                        
                        <table class="w-full mb-6"><thead class="bg-gray-50 border-y border-gray-200"><tr class="text-[10px] font-bold uppercase text-gray-500 tracking-wider text-left"><th class="py-2 px-4">Description</th><th class="py-2 px-4 text-right">Amount</th></tr></thead><tbody class="divide-y"><template x-for="item in activePreview?.items"><tr><td class="py-2 px-4 text-xs" x-text="item.service"></td><td class="py-2 px-4 text-right text-xs font-medium" x-text="'₹' + parseFloat(item.price || 0).toLocaleString()"></td></tr></template></tbody><tfoot><tr class="border-t-2 border-blue-600"><td class="py-2 px-4 text-right font-bold uppercase text-[10px] text-gray-500">Total Due</td><td class="py-2 px-4 text-right text-lg font-bold text-blue-600" x-text="'₹' + parseFloat(activePreview?.amount || 0).toLocaleString()"></td></tr></tfoot></table>
                        
                        <div class="mb-6 p-3 bg-gray-50 rounded border border-gray-100"><span class="text-[9px] font-bold text-gray-400 uppercase block mb-0.5">In Words:</span><p class="text-xs font-medium italic text-gray-700 text-left" x-text="amountInWords(activePreview?.amount)"></p></div>

                        <div class="flex justify-between items-end mt-4">
                            <div class="w-3/5">
                                <template x-if="activePreview?.bank_id"><div class="text-[10px] space-y-0.5 text-gray-600 text-left"><h3 class="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-1">Bank Details:</h3><template x-if="banks.find(b => b.id === activePreview.bank_id)"><div><p><b>Name:</b> <span x-text="banks.find(b => b.id === activePreview.bank_id).account_name"></span></p><p><b>A/C:</b> <span x-text="banks.find(b => b.id === activePreview.bank_id).account_no"></span></p><p><b>IFSC:</b> <span x-text="banks.find(b => b.id === activePreview.bank_id).ifsc"></span></p><p><b>Branch:</b> <span x-text="banks.find(b => b.id === activePreview.bank_id).branch"></span></p></div></template></div></template>
                            </div>
                            <div class="w-2/5 text-center border-t border-gray-300 pt-3"><p class="text-[9px] font-bold text-gray-400 uppercase">Authorized Signatory</p><p class="text-[10px] font-medium" x-text="org.name"></p></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('invoicePortal', () => ({
        client: <?php echo json_encode($client, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        invoices: <?php echo json_encode($invoices, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        banks: <?php echo json_encode($settings['bank_accounts'] ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        org: <?php echo json_encode([
            'name' => $settings['org_name'] ?? '',
            'website' => $settings['website_url'] ?? '',
            'email' => $settings['email'] ?? '',
            'phone' => $settings['phone'] ?? '',
            'logo_url' => $settings['logo_url'] ?? ''
        ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        showProfile: false,
        passwords: { current: '', new: '', confirm: '' },
        activePreview: null,
        toast: { show: false, message: '', type: 'success' },
        
        showToast(msg, type = 'success') {
            this.toast.message = msg;
            this.toast.type = type;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        async updatePassword() {
            if (!this.passwords.current || !this.passwords.new) {
                this.showToast('Please fill all password fields', 'error');
                return;
            }
            if (this.passwords.new !== this.passwords.confirm) {
                this.showToast('New passwords do not match', 'error');
                return;
            }
            const res = await fetch(url('/portal/profile'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    current_password: this.passwords.current,
                    new_password: this.passwords.new,
                    confirm_password: this.passwords.confirm
                })
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showToast(data.message);
                this.passwords = { current: '', new: '', confirm: '' };
                this.showProfile = false;
            } else {
                this.showToast(data.message, 'error');
            }
        },
        amountInWords(num) {
            if (!num) return 'Zero Rupees Only';
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            const inWords = (n) => {
                if ((n = n.toString()).length > 9) return 'overflow';
                let nArr = ('000000000' + n).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                if (!nArr) return ''; 
                let str = '';
                str += (nArr[1] != 0) ? (a[Number(nArr[1])] || b[nArr[1][0]] + ' ' + a[nArr[1][1]]) + 'Crore ' : '';
                str += (nArr[2] != 0) ? (a[Number(nArr[2])] || b[nArr[2][0]] + ' ' + a[nArr[2][1]]) + 'Lakh ' : '';
                str += (nArr[3] != 0) ? (a[Number(nArr[3])] || b[nArr[3][0]] + ' ' + a[nArr[3][1]]) + 'Thousand ' : '';
                str += (nArr[4] != 0) ? (a[Number(nArr[4])] || b[nArr[4][0]] + ' ' + a[nArr[4][1]]) + 'Hundred ' : '';
                str += (nArr[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(nArr[5])] || b[nArr[5][0]] + ' ' + a[nArr[5][1]]) : '';
                return str;
            }
            return inWords(Math.floor(num)) + ' Rupees Only';
        },
        async downloadPDF(invoice) {
            this.showToast('Generating PDF...');
            const element = document.getElementById('invoice-print-area');
            const opt = {
                margin: 0,
                filename: `Invoice_${invoice.invoice_no}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { 
                    scale: 2, 
                    useCORS: true,
                    onclone: (clonedDoc) => {
                        const el = clonedDoc.getElementById('invoice-print-area');
                        if (el) { 
                            el.style.transform = 'none'; 
                            el.style.margin = '0'; 
                            el.style.position = 'static'; 
                            el.style.display = 'block'; 
                            el.style.minHeight = 'auto';
                            el.style.height = 'auto';
                        }
                        clonedDoc.querySelectorAll('.hide-in-pdf').forEach(node => node.style.display = 'none');
                    }
                },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    }))
})
</script>

</body>
</html>
