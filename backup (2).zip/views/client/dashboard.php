<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Client Dashboard - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        #client-map .leaflet-popup-content-wrapper { font-family: 'Google Sans', sans-serif; font-size: 13px; }
        #client-map { min-height: 320px; background: #eef2f5; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="dashboardPortal" x-init="init()">

    <?php 
    $activePage = 'dashboard';
    include __DIR__ . '/../partials/client_header.php'; 
    ?>

    <main class="p-8 max-w-7xl mx-auto">
        <header class="mb-8">
            <h1 class="text-2xl font-medium">Welcome, <span x-text="client.client_name"></span></h1>
            <p class="text-gray-500 text-sm">Here's an overview of your projects and payments.</p>
        </header>

        <!-- Client Application Card -->
        <div class="card overflow-hidden mb-8">
            <div class="px-6 py-4 border-b bg-gray-50 flex flex-wrap justify-between items-center gap-3">
                <h3 class="font-medium text-gray-900">Client Application Details</h3>
            </div>
            <div class="p-6 md:p-8">
                <!-- Photo + Application No -->
                <div class="flex flex-col md:flex-row items-start md:items-center gap-6 mb-6">
                    <div class="flex-shrink-0">
                        <template x-if="client.client_photo">
                            <img :src="url(client.client_photo)" class="w-32 h-32 rounded-full object-cover border-4 border-blue-50 shadow-md">
                        </template>
                        <template x-if="!client.client_photo">
                            <div class="w-32 h-32 rounded-full bg-blue-100 flex items-center justify-center text-blue-600 font-bold text-2xl" x-text="client.client_name ? client.client_name.charAt(0) : '?'"></div>
                        </template>
                    </div>
                    <div class="flex-grow min-w-0">
                        <div class="flex items-center gap-2 mb-1">
                            <span class="text-xs font-bold uppercase text-blue-600">Application No</span>
                        </div>
                        <div class="text-xl font-medium text-gray-900" x-text="applicationNo || '-'></div>
                        <div class="text-[10px] text-gray-500 mt-1">Enquiry Reference</div>
                    </div>
                </div>

                <!-- Details Grid -->
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6 mb-6">
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Name</label>
                        <p class="text-gray-900 font-medium" x-text="client.client_name || '-'"></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Status</label>
                        <p class="text-gray-900 font-medium" :class="enquiryStatus === 'Approved' ? 'text-green-600' : enquiryStatus === 'Rejected' ? 'text-red-600' : 'text-blue-600'" x-text="enquiryStatus || '-'"></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Email</label>
                        <p class="text-blue-600 font-medium break-all" x-text="client.email || '-'"></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Mobile</label>
                        <p class="text-gray-900 font-medium" x-text="client.phone || '-'"></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Pin-code</label>
                        <p class="text-gray-900 font-medium" x-text="clientPincode || '-'"></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">State</label>
                        <p class="text-gray-900 font-medium uppercase" x-text="client.state || '-'"></p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Service Type</label>
                        <p class="text-gray-900 font-medium">Choosed Service</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Refund Amount</label>
                        <p class="text-gray-900 font-medium text-lg" x-text="'₹' + refundAmount.toLocaleString()"></p>
                        <p class="text-[10px] text-gray-500 mt-1">90% of total invoiced amount</p>
                    </div>
                    <div class="bg-gray-50 p-4 rounded-lg border col-span-1 sm:col-span-2 lg:col-span-3">
                        <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-1">Approved Location</label>
                        <p class="text-gray-900 leading-relaxed break-all" x-text="client.address || '-'"></p>
                    </div>
                </div>

                <!-- Map -->
                <div class="bg-gray-50 p-4 rounded-lg border">
                    <label class="text-[10px] font-bold text-gray-400 uppercase tracking-widest block mb-3">Approved Location Map</label>
                    <div id="client-map" class="w-full h-64 md:h-80 rounded-lg border overflow-hidden"></div>
                    <p class="text-[10px] text-gray-500 mt-2 text-center">Marker shows client location · Circle indicates 5 km service radius</p>
                </div>
            </div>
        </div>

        <!-- Stats -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div class="card p-6 border-l-4 border-blue-500">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-xs font-bold text-blue-600 uppercase">Pending Approvals</div>
                    <svg class="w-5 h-5 text-blue-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                <div class="text-3xl font-medium" x-text="approvals.filter(p => p.status === 'Sent').length"></div>
                <div class="text-[10px] text-gray-400 mt-1">Requiring your review</div>
            </div>
            <div class="card p-6 border-l-4 border-purple-500">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-xs font-bold text-purple-600 uppercase">Total Invoices</div>
                    <svg class="w-5 h-5 text-purple-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                </div>
                <div class="text-3xl font-medium" x-text="invoices.length"></div>
                <div class="text-[10px] text-gray-400 mt-1">Total billed records</div>
            </div>
            <div class="card p-6 border-l-4 border-green-500">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-xs font-bold text-green-600 uppercase">Total Paid</div>
                    <svg class="w-5 h-5 text-green-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div class="text-3xl font-medium" x-text="'₹' + payments.reduce((sum, p) => sum + parseFloat(p.amount), 0).toLocaleString()"></div>
                <div class="text-[10px] text-gray-400 mt-1">Successfully processed</div>
            </div>
            <div class="card p-6 border-l-4 border-orange-500">
                <div class="flex items-center justify-between mb-2">
                    <div class="text-xs font-bold text-orange-600 uppercase">Remaining Due</div>
                    <svg class="w-5 h-5 text-orange-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                </div>
                <div class="text-3xl font-medium text-orange-600" x-text="'₹' + (invoices.reduce((sum, i) => sum + parseFloat(i.amount), 0) - payments.reduce((sum, p) => sum + parseFloat(p.amount), 0)).toLocaleString()"></div>
                <div class="text-[10px] text-gray-400 mt-1">Pending settlement</div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- Recent Invoices -->
            <div class="card overflow-hidden">
                <div class="px-6 py-4 border-b flex justify-between items-center bg-gray-50">
                    <h3 class="font-medium">Recent Invoices</h3>
                    <a href="/portal/invoices" class="text-xs text-blue-600 font-bold hover:underline">View All</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <tbody class="divide-y">
                            <template x-for="i in invoices.slice(0, 5)" :key="i.id">
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 text-sm font-medium text-blue-600" x-text="i.invoice_no"></td>
                                    <td class="px-6 py-4 text-sm" x-text="'₹' + parseFloat(i.amount).toLocaleString()"></td>
                                    <td class="px-6 py-4 text-right">
                                        <span :class="{
                                            'bg-green-100 text-green-700': i.status === 'Paid',
                                            'bg-yellow-100 text-yellow-700': i.status === 'Sent',
                                            'bg-gray-100 text-gray-700': i.status === 'Draft'
                                        }" class="px-2 py-0.5 text-[10px] rounded-full font-bold uppercase" x-text="i.status"></span>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Recent Approvals -->
            <div class="card overflow-hidden">
                <div class="px-6 py-4 border-b flex justify-between items-center bg-gray-50">
                    <h3 class="font-medium">Pending Approvals</h3>
                    <a href="/portal/approvals" class="text-xs text-blue-600 font-bold hover:underline">View All</a>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <tbody class="divide-y">
                            <template x-for="p in approvals.filter(p => p.status === 'Sent').slice(0, 5)" :key="p.id">
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4 text-sm font-medium text-blue-600" x-text="p.approval_no"></td>
                                    <td class="px-6 py-4 text-sm" x-text="p.subject"></td>
                                    <td class="px-6 py-4 text-right">
                                        <a :href="'/portal/approvals?open=' + p.id" class="text-xs bg-blue-50 text-blue-600 px-3 py-1 rounded font-bold hover:bg-blue-100">Review</a>
                                    </td>
                                </tr>
                            </template>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('dashboardPortal', () => ({
        client: <?php echo json_encode($client, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        enquiries: <?php echo json_encode($enquiries ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        approvals: <?php echo json_encode($approvals, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        invoices: <?php echo json_encode($invoices, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        payments: <?php echo json_encode($payments, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        org: <?php echo json_encode($settings, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        applicationNo: '',
        enquiryStatus: '',
        clientPincode: '',
        refundAmount: 0,
        showProfile: false,
        passwords: { current: '', new: '', confirm: '' },
        toast: { show: false, message: '', type: 'success' },
        
        init() {
            const enquiry = (this.enquiries && this.enquiries[0]) || {};
            this.applicationNo = enquiry.enquiry_no || enquiry.id || '-';
            this.enquiryStatus = enquiry.status || '-';
            const addr = this.client?.address || '';
            const m = addr.match(/\b\d{6}\b/);
            this.clientPincode = m ? m[0] : '-';
            const total = (this.invoices || []).reduce((sum, i) => sum + (parseFloat(i.amount) || 0), 0);
            this.refundAmount = Math.round(total * 0.9 * 100) / 100;
            this.initMap();
        },
        async initMap() {
            const el = document.getElementById('client-map');
            const address = this.client?.address;
            if (!address) {
                el.innerHTML = '<div class="w-full h-full flex items-center justify-center text-gray-400 text-sm px-4">No address available for this client</div>';
                return;
            }
            if (typeof L === 'undefined') {
                el.innerHTML = '<div class="w-full h-full flex flex-col items-center justify-center text-gray-400 text-sm px-4 py-2 text-center">Map library not loaded (check internet/CDN)</div>';
                return;
            }
            el.innerHTML = '';
            const map = L.map('client-map', { scrollWheelZoom: false }).setView([20.5937, 78.9629], 5);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap contributors'
            }).addTo(map);

            const lat = this.client?.latitude ? parseFloat(this.client.latitude) : null;
            const lon = this.client?.longitude ? parseFloat(this.client.longitude) : null;

            if (lat !== null && lon !== null) {
                // Use stored coordinates — works offline, no geocoding API needed
                map.setView([lat, lon], 14);
                L.marker([lat, lon]).addTo(map).bindPopup('<strong>' + (this.client?.client_name || 'Client') + '</strong><br>' + address).openPopup();
                L.circle([lat, lon], {
                    radius: 5000,
                    color: '#1a73e8',
                    fillColor: '#1a73e8',
                    fillOpacity: 0.25,
                    weight: 3,
                    interactive: true
                }).addTo(map).bindPopup('<strong>5 km Service Radius</strong><br>Centered on client address');
                map.invalidateSize();
            } else {
                // Fallback: geocode via Nominatim (requires internet, blocked on localhost)
                try {
                    const res = await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q=' + encodeURIComponent(address), {
                        headers: { 'User-Agent': 'dadmin-crm/1.4.0' }
                    });
                    const data = await res.json();
                    if (data && data.length > 0) {
                        const glat = parseFloat(data[0].lat);
                        const glon = parseFloat(data[0].lon);
                        map.setView([glat, glon], 14);
                        L.marker([glat, glon]).addTo(map).bindPopup('<strong>' + (this.client?.client_name || 'Client') + '</strong><br>' + address).openPopup();
                        L.circle([glat, glon], {
                            radius: 5000,
                            color: '#1a73e8',
                            fillColor: '#1a73e8',
                            fillOpacity: 0.25,
                            weight: 3,
                            interactive: true
                        }).addTo(map).bindPopup('<strong>5 km Service Radius</strong><br>Centered on client address');
                        map.invalidateSize();
                    } else {
                        L.popup().setLatLng([20.5937, 78.9629]).setContent('No coordinates stored for this client').openOn(map);
                    }
                } catch (e) {
                    console.error('Map geocoding failed', e);
                    L.popup().setLatLng([20.5937, 78.9629]).setContent('No coordinates stored (offline)').openOn(map);
                }
            }
        },
        showToast(msg, type = 'success') {
            this.toast.message = msg;
            this.toast.type = type;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        async updatePassword() {
            if (!this.passwords.current || !this.passwords.new) {
                this.showToast('Please fill all password fields', 'error');
                return;
            }
            if (this.passwords.new !== this.passwords.confirm) {
                this.showToast('New passwords do not match', 'error');
                return;
            }
            const res = await fetch(url('/portal/profile'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    current_password: this.passwords.current,
                    new_password: this.passwords.new,
                    confirm_password: this.passwords.confirm
                })
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showToast(data.message);
                this.passwords = { current: '', new: '', confirm: '' };
                this.showProfile = false;
            } else {
                this.showToast(data.message, 'error');
            }
        }
    }))
})
</script>

</body>
</html>
