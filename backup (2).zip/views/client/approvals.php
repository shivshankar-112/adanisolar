<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Approvals - Client Portal</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <script src="<?= url('/assets/js/html2pdf.bundle.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .prose b, .prose strong { font-weight: bold !important; }
        .prose i, .prose em { font-style: italic !important; }
    </style>
</head>
<body class="text-gray-800">

<div x-data="approvalPortal">

    <?php 
    $activePage = 'approvals';
    include __DIR__ . '/../partials/client_header.php'; 
    ?>

    <main class="p-4 md:p-8 max-w-7xl mx-auto">
        <header class="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h1 class="text-xl md:text-2xl font-medium">My Approvals</h1>
                <p class="text-sm md:text-base text-gray-500">Review and accept your project approvals.</p>
            </div>
        </header>

        <div class="card overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left min-w-[700px] md:min-w-0">
                    <thead class="bg-gray-50 border-b">
                        <tr>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Approval No</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Subject</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase">Amount</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase text-right">Status</th>
                            <th class="px-4 md:px-6 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y">
                        <template x-for="p in approvals" :key="p.id">
                            <tr class="hover:bg-gray-50 transition text-xs md:text-sm">
                                <td class="px-4 md:px-6 py-4 font-medium text-blue-600" x-text="p.approval_no"></td>
                                <td class="px-4 md:px-6 py-4 text-gray-600" x-text="p.subject"></td>
                                <td class="px-4 md:px-6 py-4 font-medium" x-text="'₹' + parseFloat(p.amount).toLocaleString()"></td>
                                <td class="px-4 md:px-6 py-4 text-right">
                                    <span :class="{
                                        'bg-blue-100 text-blue-700': p.status === 'Sent',
                                        'bg-green-100 text-green-700': p.status === 'Accepted',
                                        'bg-red-100 text-red-700': p.status === 'Rejected',
                                        'bg-gray-100 text-gray-700': p.status === 'Invoiced'
                                    }" class="px-2 py-0.5 md:py-1 text-[9px] md:text-[10px] rounded-full font-bold uppercase" x-text="p.status"></span>
                                </td>
                                <td class="px-4 md:px-6 py-4 text-right space-x-1 md:space-x-2 whitespace-nowrap">
                                    <template x-if="p.status === 'Sent'">
                                        <div class="inline-flex bg-gray-100 rounded-full p-0.5 mr-1 md:mr-2">
                                            <button type="button" @click="updateStatus(p.id, 'Accepted')" class="px-3 py-1 text-[10px] md:text-xs rounded-full font-bold transition-all hover:bg-white hover:shadow-sm text-gray-500 hover:text-green-600">Accept</button>
                                            <button type="button" @click="updateStatus(p.id, 'Rejected')" class="px-3 py-1 text-[10px] md:text-xs rounded-full font-bold transition-all hover:bg-white hover:shadow-sm text-gray-500 hover:text-red-600">Reject</button>
                                        </div>
                                    </template>
                                    <button type="button" @click="activePreview = p" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">View</button>
                                </td>
                            </tr>
                        </template>
                    </tbody>
                </table>
            </div>
            <template x-if="approvals.length === 0">
                <div class="p-8 md:p-12 text-center text-gray-500 italic text-sm">You don't have any approvals yet.</div>
            </template>
        </div>
    </main>

    <!-- Preview Modal -->
    <div x-show="activePreview" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen p-2 md:p-4 text-center">
            <div @click="activePreview = null" class="fixed inset-0 bg-black bg-opacity-50"></div>
            
            <div class="inline-block w-full max-w-5xl bg-white shadow-2xl rounded-2xl overflow-hidden relative z-10 text-left align-middle transition-all">
                <!-- Toolbar -->
                <div class="bg-gray-50 px-4 md:px-8 py-3 md:py-4 border-b flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <h3 class="text-base md:text-lg font-medium" x-text="'Approval: ' + activePreview?.approval_no"></h3>
                    <div class="flex items-center space-x-2 md:space-x-3 w-full sm:w-auto justify-between sm:justify-end">
                        <template x-if="activePreview?.status === 'Sent'">
                            <div class="flex space-x-1 md:space-x-2">
                                <button type="button" @click="updateStatus(activePreview.id, 'Accepted')" class="bg-green-600 text-white px-2 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-bold hover:bg-green-700 transition">Accept</button>
                                <button type="button" @click="updateStatus(activePreview.id, 'Rejected')" class="bg-red-50 text-red-600 px-2 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-bold hover:bg-red-100 transition">Reject</button>
                            </div>
                        </template>
                        <div class="flex items-center space-x-2">
                            <button type="button" @click="downloadPDF(activePreview)" class="bg-gray-200 text-gray-700 px-2 md:px-4 py-1.5 rounded text-[10px] md:text-sm font-bold hover:bg-gray-300 transition flex items-center">
                                <svg class="w-3 h-3 md:w-4 md:h-4 mr-1 md:mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                                PDF
                            </button>
                            <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-600"><svg class="w-5 h-5 md:w-6 md:h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg></button>
                        </div>
                    </div>
                </div>

                <!-- Content Area (A4) -->
                <div class="p-4 md:p-8 bg-gray-100 flex justify-center min-h-[400px] md:min-h-[600px] overflow-auto max-h-[85vh]">
                    <div id="approval-render-area" class="bg-white shadow-lg mx-auto origin-top sm:origin-center scale-[0.4] sm:scale-[0.6] md:scale-100" style="width: 210mm; min-height: 297mm; padding: 20mm;">
                        <template x-if="activePreview">
                            <div class="h-full flex flex-col">
                                <template x-if="templates.find(t => t.id === activePreview.template_id)?.header_graphic">
                                    <img :src="templates.find(t => t.id === activePreview.template_id).header_graphic" class="w-full mb-8">
                                </template>
                                
                                <div class="prose max-w-none flex-grow" x-html="renderTemplate(templates.find(t => t.id === activePreview.template_id)?.content, activePreview)"></div>

                                <div class="mt-12 flex justify-between items-end">
                                    <div class="w-1/2">
                                        <template x-if="templates.find(t => t.id === activePreview.template_id)?.footer_graphic">
                                            <img :src="templates.find(t => t.id === activePreview.template_id).footer_graphic" class="w-full">
                                        </template>
                                    </div>
                                    <div class="text-center">
                                        <template x-if="templates.find(t => t.id === activePreview.template_id)?.stamp_sign">
                                            <img :src="templates.find(t => t.id === activePreview.template_id).stamp_sign" class="h-24 mx-auto -mb-6 object-contain">
                                        </template>
                                        <div class="border-t pt-2 text-[10px] text-gray-400 uppercase font-bold">Authorized Signatory</div>
                                    </div>
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div @click="confirmModal.show = false" class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg font-medium mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-blue-600 hover:bg-blue-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-[60]" x-text="toast.message"></div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('approvalPortal', () => ({
        client: <?php echo json_encode($client, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        approvals: <?php echo json_encode($approvals, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        templates: <?php echo json_encode($settings['approval_templates'] ?? [], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        org: <?php echo json_encode([
            'name' => $settings['org_name'] ?? '',
            'logo_url' => $settings['logo_url'] ?? ''
        ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>,
        showProfile: false,
        passwords: { current: '', new: '', confirm: '' },
        activePreview: null,
        toast: { show: false, message: '', type: 'success' },
        confirmModal: { show: false, message: '', callback: null },
        
        init() {
            setTimeout(() => {
                document.querySelectorAll('input[type=text][x-model]').forEach(el => {
                    if (el.getAttribute('x-model') === 'searchQuery' || el.getAttribute('x-model') === 'query') {
                        el.value = '';
                        el.dispatchEvent(new Event('input'));
                    }
                });
            }, 50);
        },

        showToast(msg, type = 'success') {
            this.toast.message = msg;
            this.toast.type = type;
            this.toast.show = true;
            setTimeout(() => this.toast.show = false, 3000);
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) this.confirmModal.callback();
            this.confirmModal.show = false;
        },
        async updatePassword() {
            if (!this.passwords.current || !this.passwords.new) {
                this.showToast('Please fill all password fields', 'error');
                return;
            }
            if (this.passwords.new !== this.passwords.confirm) {
                this.showToast('New passwords do not match', 'error');
                return;
            }
            const res = await fetch(url('/portal/profile'), {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    current_password: this.passwords.current,
                    new_password: this.passwords.new,
                    confirm_password: this.passwords.confirm
                })
            });
            const data = await res.json();
            if (data.status === 'success') {
                this.showToast(data.message);
                this.passwords = { current: '', new: '', confirm: '' };
                this.showProfile = false;
            } else {
                this.showToast(data.message, 'error');
            }
        },
        async updateStatus(id, status) {
            this.confirmAction(`Are you sure you want to ${status.toLowerCase()} this approval?`, async () => {
                const res = await fetch(url('/portal/approval/status'), {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ id, status })
                });
                const data = await res.json();
                if (data.status === 'success') {
                    const p = this.approvals.find(pr => pr.id === id);
                    if(p) p.status = status;
                    if(this.activePreview) this.activePreview.status = status;
                    this.showToast(`Approval ${status}`);
                }
            });
        },
renderTemplate(content, approval) {
             let r = approval.custom_content || content || '';
             const orgLogo = this.org.logo_url ? `<img src='${url(this.org.logo_url)}' style='height: 100px;'>` : '';
             let sText = approval.items?.map(i => i.service).join(', ') || '';
             let cPhoto = '';
             if (this.client && this.client.client_photo) {
                 cPhoto = `<img src='${url(this.client.client_photo)}' style='height: 100px; border-radius: 50%;'>`;
             }
             
             let itemsTable = '';
             if (approval.items && approval.items.length > 0) {
                 itemsTable = '<table style="width: 100%; border-collapse: collapse; margin-bottom: 1em; font-size: 14px;">';
                 itemsTable += '<thead><tr style="border-bottom: 2px solid #ddd; text-align: left;"><th style="padding: 8px;">Service</th><th style="padding: 8px; text-align: right;">Price</th></tr></thead>';
                 itemsTable += '<tbody>';
                 let total = 0;
                 approval.items.forEach(item => {
                     let price = parseFloat(item.price || 0);
                     total += price;
                     itemsTable += `<tr style="border-bottom: 1px solid #eee;"><td style="padding: 8px;">${item.service}</td><td style="padding: 8px; text-align: right;">₹${price.toLocaleString()}</td></tr>`;
                 });
                 itemsTable += `<tr style="font-weight: bold; font-size: 16px;"><td style="padding: 8px; text-align: right;">Total</td><td style="padding: 8px; text-align: right;">₹${total.toLocaleString()}</td></tr>`;
                 itemsTable += '</tbody></table>';
             }
             
             const v = { '{{client_name}}': approval.client_name, '{{email}}': approval.email, '{{approval_no}}': approval.approval_no, '{{amount}}': approval.amount, '{{date}}': approval.created_at, '{{subject}}': approval.subject, '{{service}}': sText, '{{org_name}}': this.org.name, '{{org_logo}}': orgLogo, '{{client_photo}}': cPhoto, '{{items}}': itemsTable };
             for (const [k, val] of Object.entries(v)) r = r.split(k).join(val || '');
             return r;
         },
        async downloadPDF(approval) {
            this.showToast('Generating PDF...');
            const element = document.getElementById('approval-render-area');
            const opt = {
                margin: 0,
                filename: `Approval_${approval.approval_no}.pdf`,
                image: { type: 'jpeg', quality: 0.98 },
                html2canvas: { 
                    scale: 2, 
                    useCORS: true,
                    onclone: (clonedDoc) => {
                        const el = clonedDoc.getElementById('approval-render-area');
                        if (el) {
                            el.style.transform = 'none';
                            el.style.margin = '0';
                            el.style.position = 'static';
                            el.style.display = 'block';
                            el.style.minHeight = 'auto';
                            el.style.height = 'auto';
                        }
                    }
                },
                jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' }
            };
            html2pdf().set(opt).from(element).save();
        }
    }))
})
</script>

</body>
</html>
