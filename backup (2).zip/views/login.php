<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login - <?php echo htmlspecialchars($settings['org_name'] ?? 'iAdmin') ?></title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
    </style>
</head>
<body class="flex items-center justify-center min-h-screen">

<div x-data="{ 
    username: '', 
    password: '', 
    remember: false,
    error: '',
    async login() {
        this.error = '';
        const res = await fetch(url('/admin/login'), {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                username: this.username, 
                password: this.password,
                remember: this.remember
            })
        });
        const data = await res.json();
        if (data.status === 'success') {
            window.location.href = url('/dashboard');
        } else {
            this.error = data.message;
        }
    }
}" class="w-full max-w-md p-4 sm:p-8">

    <div class="card p-6 sm:p-8 space-y-6 sm:space-y-8">
        <div class="text-center">
            <?php if (!empty($settings['logo_url'])): ?>
                <img src="<?= url($settings['logo_url']) ?>" alt="Logo" class="h-12 mx-auto mb-4 object-contain">
            <?php else: ?>
                <div class="h-12 w-12 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-lg mx-auto mb-4">iA</div>
            <?php endif; ?>
            <h1 class="text-2xl font-bold text-gray-800 tracking-tight"><?php echo htmlspecialchars($settings['org_name'] ?? 'iAdmin') ?></h1>
            <p class="text-sm text-gray-500 mt-1 uppercase tracking-widest font-bold">Admin Panel</p>
        </div>

        <form @submit.prevent="login()" class="space-y-6">
            <div class="space-y-1">
                <label class="text-sm font-medium text-gray-600">Username</label>
                <input type="text" x-model="username" class="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none" required>
            </div>
            <div class="space-y-1">
                <label class="text-sm font-medium text-gray-600">Password</label>
                <input type="password" x-model="password" class="w-full border rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none" required>
            </div>

            <div class="flex items-center">
                <input type="checkbox" x-model="remember" id="remember" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded cursor-pointer">
                <label for="remember" class="ml-2 block text-sm text-gray-600 cursor-pointer">Remember me</label>
            </div>

            <template x-if="error">
                <p class="text-sm text-red-600 font-medium" x-text="error"></p>
            </template>

            <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md font-medium transition duration-200">
                Sign In
            </button>
        </form>

        <div class="pt-4 border-t text-xs text-gray-500 space-y-1 text-center">
            <p>Protected Admin Access</p>
        </div>
    </div>

</div>

</body>
</html>
