<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payments - Simple CRM</title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <script src="<?= url('/assets/js/html2pdf.bundle.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 8px; box-shadow: 0 1px 2px 0 rgba(60,64,67,.3), 0 1px 3px 1px rgba(60,64,67,.15); }
        .btn-google { background-color: #1a73e8; color: white; padding: 0.5rem 1.5rem; border-radius: 4px; font-weight: 500; }
        .btn-google:hover { background-color: #1765cc; }
        @media print {
            .no-print { display: none !important; }
            body { background-color: white !important; margin: 0; padding: 0; }
            .print-only { display: block !important; }
            #payment-print-area { transform: none !important; margin: 0 !important; padding: 20mm !important; width: 100% !important; }
        }
    </style>
</head>
<body class="text-gray-800">

<div x-data="paymentManager" class="min-h-screen flex flex-col">

    <div class="no-print">
        <?php 
        $activePage = 'payments';
        include __DIR__ . '/partials/header.php'; 
        ?>

        <!-- Actions Toolbar -->
        <div class="bg-white border-b px-4 md:px-6 py-3 flex flex-col xl:flex-row items-stretch xl:items-center justify-between gap-4 shadow-sm sticky top-0 z-30">
            <div class="flex flex-col lg:flex-row items-stretch lg:items-center gap-4 flex-grow">
                <div class="relative group">
                    <span class="absolute inset-y-0 left-0 pl-3 flex items-center text-gray-400 group-focus-within:text-blue-500 transition-colors">
                        <svg class="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </span>
                    <input type="text" x-model="searchQuery" autocomplete="off" placeholder="Search payments..." class="bg-gray-50 border border-gray-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none w-full lg:w-64 transition-all">
                </div>

                <div class="flex flex-wrap items-center gap-2 pb-1 lg:pb-0">
                    <button type="button" @click="showTrash = !showTrash; fetchData(1)" class="flex items-center space-x-1.5 px-4 py-2 text-xs font-semibold rounded-lg transition-all flex-shrink-0" :class="showTrash ? 'bg-red-100 text-red-700 shadow-inner' : 'bg-gray-50 border border-gray-200 text-gray-600 hover:bg-white hover:shadow-sm'">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        <span x-text="showTrash ? 'Viewing Trash' : 'Trash'"></span>
                    </button>
                    
                    <button type="button" @click="searchQuery=''; showTrash=false; fetchData(1)" class="text-xs font-medium text-blue-600 hover:text-blue-800 hover:underline px-2 flex-shrink-0">Reset</button>
                </div>
            </div>
            <div class="flex items-center gap-3">
                <button type="button" @click="exportToCSV()" class="flex-1 lg:flex-none justify-center bg-white border border-gray-200 text-gray-700 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-gray-50 hover:shadow-sm transition-all flex items-center">
                    <svg class="w-4 h-4 mr-2 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a2 2 0 002 2h12a2 2 0 002-2v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                    Export
                </button>
            </div>
        </div>

        <main class="flex-grow p-4 md:p-8">
            <div class="max-w-full mx-auto">
                <h1 class="text-xl md:text-2xl mb-6 md:mb-8">Payments</h1>
                <div class="card overflow-hidden">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse min-w-[1000px] md:min-w-0">
                            <thead class="bg-gray-50 border-b">
                                <tr>
                                    <th @click="sortBy('payment_no')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Payment No
                                        <span x-show="sortKey === 'payment_no'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('invoice_no')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Invoice No
                                        <span x-show="sortKey === 'invoice_no'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('client_name')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Client
                                        <span x-show="sortKey === 'client_name'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('method')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Method
                                        <span x-show="sortKey === 'method'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('amount')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap cursor-pointer hover:bg-gray-100">
                                        Amount (₹)
                                        <span x-show="sortKey === 'amount'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th @click="sortBy('date')" class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right cursor-pointer hover:bg-gray-100">
                                        Date
                                        <span x-show="sortKey === 'date'" x-text="sortOrder === 'asc' ? '↑' : '↓'"></span>
                                    </th>
                                    <th class="px-3 md:px-4 py-3 text-[10px] md:text-xs font-medium text-gray-500 uppercase whitespace-nowrap text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y">
                                <template x-for="p in payments" :key="p.id">
                                    <tr class="hover:bg-gray-50 transition group">
                                        <td class="px-4 py-4 text-xs md:text-sm font-bold text-gray-900" x-text="p.payment_no"></td>
                                        <td class="px-4 py-4 text-xs md:text-sm font-medium text-blue-600" x-text="p.invoice_no || 'Manual'"></td>
                                        <td class="px-4 py-4">
                                            <div class="text-xs md:text-sm font-medium text-gray-900" x-text="p.client_name"></div>
                                            <div class="text-[10px] text-gray-400 italic" x-text="p.note || ''"></div>
                                        </td>
                                        <td class="px-4 py-4 text-xs md:text-sm text-gray-600" x-text="p.method"></td>
                                        <td class="px-4 py-4 text-xs md:text-sm font-bold text-gray-900" x-text="'₹' + parseFloat(p.amount || 0).toLocaleString()"></td>
                                        <td class="px-4 py-4 text-xs md:text-sm text-gray-500 text-right font-medium" x-text="p.date"></td>
                                        <td class="px-4 py-4 text-right space-x-1 md:space-x-2 whitespace-nowrap">
                                            <button type="button" @click="openPreviewModal(p)" class="text-[10px] md:text-xs bg-white border border-gray-200 text-gray-600 px-3 py-1.5 rounded-lg font-bold hover:bg-gray-50 hover:text-blue-600 hover:border-blue-200 transition-all shadow-sm">View</button>
                                            <?php if (\App\Services\PermissionHelper::check('payments', 'delete')): ?>
                                                <template x-if="!p.deleted_at">
                                                    <button type="button" @click="deletePayment(p.id)" class="text-gray-400 hover:text-red-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-red-50"><svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                                                </template>
                                                <template x-if="p.deleted_at">
                                                    <button type="button" @click="restorePayment(p.id)" class="text-gray-400 hover:text-green-600 p-1.5 transition-all opacity-0 group-hover:opacity-100 rounded-lg hover:bg-green-50"><svg class="w-4 h-4 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg></button>
                                                </template>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </template>
                            </tbody>
                        </table>
                    </div>
                    <template x-if="pagination.total_pages > 1">
                        <div class="px-4 py-3 border-t bg-gray-50 flex flex-col sm:flex-row items-center justify-between gap-3">
                            <div class="text-[10px] md:text-xs text-gray-500">
                                Showing <span x-text="(pagination.current_page - 1) * pagination.per_page + 1"></span> 
                                to <span x-text="Math.min(pagination.current_page * pagination.per_page, pagination.total)"></span> 
                                of <span x-text="pagination.total"></span> entries
                            </div>
                            <div class="flex space-x-2">
                                <button @click="fetchData(pagination.current_page - 1)" :disabled="pagination.current_page <= 1" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50">Previous</button>
                                <button @click="fetchData(pagination.current_page + 1)" :disabled="pagination.current_page >= pagination.total_pages" class="px-3 py-1 border rounded text-[10px] md:text-xs font-medium bg-white hover:bg-gray-50 disabled:opacity-50">Next</button>
                            </div>
                        </div>
                    </template>
                </div>
            </div>
        </main>
    </div>

    <!-- Receipt Preview Modal -->
    <div x-show="activePreview !== null" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-2 md:px-4 pt-4 pb-20 text-center">
            <div @click="activePreview = null" class="fixed inset-0 transition-opacity bg-black bg-opacity-25"></div>
            <div class="inline-block w-full max-w-full lg:max-w-6xl p-4 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                    <h3 class="text-lg md:text-xl font-medium" x-text="'Receipt: ' + (activePreview?.payment_no || '')"></h3>
                    <div class="flex flex-wrap gap-2 md:space-x-3">
                        <button type="button" @click="openEmailModal(activePreview)" class="bg-blue-50 text-blue-600 hover:bg-blue-100 px-3 md:px-4 py-1.5 rounded text-xs md:text-sm font-bold flex items-center"><svg class="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>Send Receipt</button>
                        <button type="button" @click="downloadPDF(activePreview)" class="bg-gray-100 hover:bg-gray-200 px-3 md:px-4 py-1.5 rounded text-xs md:text-sm font-medium">Download PDF</button>
                        <button type="button" @click="activePreview = null" class="text-gray-400 hover:text-gray-500"><svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" /></svg></button>
                    </div>
                </div>

                <div class="overflow-x-auto border rounded-lg bg-gray-50 p-2 md:p-4">
                    <div class="border shadow-inner mx-auto bg-white" id="payment-print-area" style="width: 210mm; min-height: 148mm; transform: scale(0.9); transform-origin: top center; margin-bottom: -100px; padding: 20mm; color: #333;">
                        <div class="flex justify-between items-start border-b-2 border-green-600 pb-10 mb-10">
                            <div class="w-1/2 text-left">
                                <h1 class="text-4xl font-bold text-green-600 tracking-tight mb-4">PAYMENT RECEIPT</h1>
                                <div class="space-y-1">
                                    <p class="text-sm font-bold uppercase text-gray-500">Receipt No: <span class="text-gray-900 ml-2" x-text="activePreview?.payment_no"></span></p>
                                    <p class="text-sm font-bold uppercase text-gray-500">Date: <span class="text-gray-900 ml-2" x-text="activePreview?.date"></span></p>
                                    <p class="text-sm font-bold uppercase text-gray-500">Invoice Ref: <span class="text-gray-900 ml-2" x-text="activePreview?.invoice_no || 'Manual Entry'"></span></p>
                                </div>
                            </div>
                            <div class="w-1/2 text-right">
                                <template x-if="org.logo_url"><img :src="url(org.logo_url)" class="h-16 ml-auto mb-4 object-contain"></template>
                                <div style="margin-top: 10px; text-align: right;">
                                    <h3 style="margin: 0; font-size: 16px; font-weight: bold; color: #000;" x-text="org.name"></h3>
                                    <p style="margin: 3px 0; font-size: 13px; color: #444;" x-text="'Phone: ' + org.phone"></p>
                                    <p style="margin: 3px 0; font-size: 13px; color: #444;" x-text="'Email: ' + org.email"></p>
                                    <p style="margin: 3px 0; font-size: 13px; color: #444;" x-text="'Website: ' + org.website"></p>
                                </div>
                            </div>
                        </div>
                        <div class="mb-12 text-left"><p class="text-lg text-gray-700 leading-relaxed">Received with thanks from <span class="font-bold border-b border-gray-400 px-2" x-text="activePreview?.client_name"></span> the sum of <span class="font-bold border-b border-gray-400 px-2" x-text="'₹' + parseFloat(activePreview?.amount || 0).toLocaleString()"></span> towards <span class="font-bold border-b border-gray-400 px-2" x-text="activePreview?.note || 'Professional Services'"></span>.</p></div>
                        <div class="mb-12 p-4 bg-gray-50 rounded border border-gray-100"><span class="text-[10px] font-bold text-gray-400 uppercase block mb-1 text-left">Amount in Words:</span><p class="text-md font-medium italic text-gray-800 text-left" x-text="amountInWords(activePreview?.amount)"></p></div>
                        <div class="flex justify-between items-end mt-20">
                            <div class="w-1/3 text-left"><div class="border-t border-gray-300 pt-2"><p class="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Method</p><p class="text-sm font-medium" x-text="activePreview?.method"></p></div></div>
                            <div class="w-1/3 text-center"><div class="border-2 border-green-600 text-green-600 font-bold py-2 px-4 rounded transform -rotate-12 inline-block uppercase tracking-widest">Payment Received</div></div>
                            <div class="w-1/3 text-right"><div class="border-t border-gray-300 pt-4"><p class="text-[10px] font-bold text-gray-400 uppercase">Authorized Signatory</p><p class="text-xs font-medium" x-text="org.name"></p></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Email Modal -->
    <div x-show="showEmailModal" class="fixed inset-0 z-[60] overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4 text-center">
            <div @click="showEmailModal = false" class="fixed inset-0 transition-opacity bg-black bg-opacity-50"></div>
            <div class="inline-block w-full max-w-2xl p-6 md:p-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-xl font-medium mb-6">Send Receipt via Email</h3>
                <div class="space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">To</label><input type="text" x-model="emailData.to" class="w-full border-b bg-gray-50 py-1 text-sm font-medium" readonly></div>
                        <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">CC</label><input type="text" x-model="emailData.cc" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm" placeholder="Additional recipients..."></div>
                    </div>
                    <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">Subject</label><input type="text" x-model="emailData.subject" class="w-full border-b focus:border-blue-600 outline-none py-1 text-sm font-bold"></div>
                    <div class="space-y-1"><label class="text-[10px] font-bold text-gray-400 uppercase">Message</label><textarea x-model="emailData.body" rows="6" class="w-full border rounded-md p-3 text-sm focus:border-blue-600 outline-none"></textarea></div>
                    <div class="p-3 bg-blue-50 rounded flex items-center">
                        <div class="flex-grow font-bold text-blue-800 text-xs">Receipt Attached as PDF</div>
                        <template x-if="emailData.attachment"><span class="text-[10px] bg-green-500 text-white px-2 py-0.5 rounded-full font-bold uppercase">Ready</span></template>
                    </div>
                </div>
                <div class="mt-8 flex justify-end space-x-3"><button type="button" @click="showEmailModal = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button><button type="button" @click="submitManualEmail()" class="btn-google">Send Email</button></div>
            </div>
        </div>
    </div>

    <!-- Toast -->
    <div x-show="toast.show" class="fixed bottom-8 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-lg z-50" x-text="toast.message"></div>

    <!-- Confirmation Modal -->
    <div x-show="confirmModal.show" class="fixed inset-0 z-50 overflow-y-auto" style="display: none;">
        <div class="flex items-center justify-center min-h-screen px-4">
            <div @click="confirmModal.show = false" class="fixed inset-0 bg-black bg-opacity-25 transition-opacity"></div>
            <div class="inline-block w-full max-w-sm p-6 md:p-8 bg-white shadow-2xl rounded-2xl relative z-10">
                <h3 class="text-lg font-medium mb-2">Confirm Action</h3>
                <p class="text-sm text-gray-500 mb-6" x-text="confirmModal.message"></p>
                <div class="flex justify-end space-x-3">
                    <button type="button" @click="confirmModal.show = false" class="px-4 py-2 text-sm font-medium text-gray-600">Cancel</button>
                    <button type="button" @click="executeConfirm()" class="btn-google bg-red-600 hover:bg-red-700">Confirm</button>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
document.addEventListener('alpine:init', () => {
    Alpine.data('paymentManager', () => ({
        searchQuery: '',
        payments: <?= json_encode($payments) ?>,
        org: <?= json_encode([
            'name' => $settings['org_name'] ?? '',
            'website' => $settings['website_url'] ?? '',
            'email' => $settings['email'] ?? '',
            'phone' => $settings['phone'] ?? '',
            'logo_url' => $settings['logo_url'] ?? ''
        ]); ?>,
        emailTemplates: <?= json_encode($settings['templates'] ?? []); ?>,
        selected: [],
        selectAll: false,
        showTrash: false,
        pagination: <?php echo json_encode($pagination) ?>,
        toast: { show: false, message: '', type: 'success' },
        activePreview: null,
        showEmailModal: false,
        emailData: { to: '', cc: '', subject: '', body: '', attachment: '' },
        confirmModal: { show: false, message: '', callback: null },
        
        async init() {
            this.$watch('searchQuery', () => this.fetchData(1));
            setTimeout(() => {
                document.querySelectorAll('input[type="text"][x-model]').forEach(el => {
                    if (el.getAttribute('x-model') === 'searchQuery') {
                        el.value = '';
                        el.dispatchEvent(new Event('input'));
                    }
                });
            }, 50);
        },
        async fetchData(page = 1) {
            const params = new URLSearchParams({
                page: page,
                q: this.searchQuery,
                trash: this.showTrash ? '1' : '0'
            });
            const res = await fetch(url('/payments?') + params.toString(), {
                headers: { 'Accept': 'application/json' }
            });
            const data = await res.json();
            this.payments = data.payments;
            this.pagination = {
                current_page: page,
                per_page: 25,
                total: data.total,
                total_pages: Math.ceil(data.total / 25)
            };
        },
        showToast(m, t='success') { this.toast.message = m; this.toast.type = t; this.toast.show = true; setTimeout(() => this.toast.show = false, 3000); },
        openPreviewModal(p) { this.activePreview = p; },
        amountInWords(num) {
            if (!num) return 'Zero Rupees Only';
            const a = ['','One ','Two ','Three ','Four ', 'Five ','Six ','Seven ','Eight ','Nine ','Ten ','Eleven ','Twelve ','Thirteen ','Fourteen ','Fifteen ','Sixteen ','Seventeen ','Eighteen ','Nineteen '];
            const b = ['', '', 'Twenty','Thirty','Forty','Fifty', 'Sixty','Seventy','Eighty','Ninety'];
            const inWords = (n) => {
                if ((n = n.toString()).length > 9) return 'overflow';
                let nArr = ('000000000' + n).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/);
                if (!nArr) return ''; 
                let str = '';
                str += (nArr[1] != 0) ? (a[Number(nArr[1])] || b[nArr[1][0]] + ' ' + a[nArr[1][1]]) + 'Crore ' : '';
                str += (nArr[2] != 0) ? (a[Number(nArr[2])] || b[nArr[2][0]] + ' ' + a[nArr[2][1]]) + 'Lakh ' : '';
                str += (nArr[3] != 0) ? (a[Number(nArr[3])] || b[nArr[3][0]] + ' ' + a[nArr[3][1]]) + 'Thousand ' : '';
                str += (nArr[4] != 0) ? (a[Number(nArr[4])] || b[nArr[4][0]] + ' ' + a[nArr[4][1]]) + 'Hundred ' : '';
                str += (nArr[5] != 0) ? ((str != '') ? 'and ' : '') + (a[Number(nArr[5])] || b[nArr[5][0]] + ' ' + a[nArr[5][1]]) : '';
                return str;
            }
            return inWords(Math.floor(num)) + ' Rupees Only';
        },
        renderTemplate(content, payment) {
            let r = content || '';
            const v = { '{{name}}': payment.client_name, '{{client_name}}': payment.client_name, '{{payment_no}}': payment.payment_no, '{{invoice_no}}': payment.invoice_no, '{{amount}}': payment.amount, '{{date}}': payment.date, '{{org_name}}': this.org.name, '{{org_website}}': this.org.website, '{{org_email}}': this.org.email, '{{org_phone}}': this.org.phone };
            for (const [k, val] of Object.entries(v)) r = r.split(k).join(val || '');
            return r;
        },
        async downloadPDF(payment) {
            this.showToast('Generating PDF...');
            this.activePreview = payment;
            await new Promise(r => setTimeout(r, 300));
            const element = document.getElementById('payment-print-area');
            if(!element) { this.showToast('Preview element not found', 'error'); return; }
            const opt = { margin: 0, filename: `Receipt_${payment.payment_no}.pdf`, image: { type: 'jpeg', quality: 0.98 }, html2canvas: { scale: 2, useCORS: true, onclone: (clonedDoc) => { const el = clonedDoc.getElementById('payment-print-area'); if (el) { el.style.transform = 'none'; el.style.margin = '0'; el.style.position = 'static'; el.style.display = 'block'; } } }, jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' } };
            html2pdf().set(opt).from(element).save().catch(err => { console.error('PDF Error:', err); this.showToast('Error generating PDF', 'error'); });
        },
        openEmailModal(payment) {
            if (!payment?.id) { this.showToast('Invalid payment', 'error'); return; }
            this.showEmailModal = true;
            const tpl = this.emailTemplates.find(t => t.id === 'payslip_sent');
            this.emailData = { id: payment.id, to: payment.email || '', cc: '', subject: tpl ? this.renderTemplate(tpl.subject, payment) : `Receipt: ${payment.payment_no}`, body: tpl ? this.renderTemplate(tpl.body, payment) : `Hi ${payment.client_name}, attached is your receipt.`, attachment: '' };
            this.showToast('Opening email modal...');
        },
        async submitManualEmail() {
            this.showToast('Sending...');
            const res = await fetch(url('/payments/send-email'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(this.emailData) });
            const data = await res.json();
            if (data.status === 'success') { this.showToast('Sent!'); this.showEmailModal = false; }
            else { this.showToast(data.message || 'Send failed', 'error'); }
        },
        confirmAction(message, callback) {
            this.confirmModal.message = message;
            this.confirmModal.callback = callback;
            this.confirmModal.show = true;
        },
        executeConfirm() {
            if (this.confirmModal.callback) this.confirmModal.callback();
            this.confirmModal.show = false;
        },
        async deletePayment(id) {
            this.confirmAction('Are you sure you want to delete this payment record?', async () => {
                const res = await fetch(url('/payments/delete'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
                if ((await res.json()).status === 'success') this.fetchData(this.pagination.current_page);
            });
        },
        async restorePayment(id) {
            const res = await fetch(url('/payments/restore'), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) });
            if ((await res.json()).status === 'success') { this.showToast('Payment restored'); this.fetchData(this.pagination.current_page); }
        },
        exportToCSV() {
            const h = ['Payment No', 'Invoice No', 'Client', 'Amount', 'Method', 'Date'];
            const r = this.payments.map(p => [p.payment_no, p.invoice_no, p.client_name, p.amount, p.method, p.date]);
            let csv = 'data:text/csv;charset=utf-8,' + h.join(',') + '\n' + r.map(row => row.map(c => '"' + (c||'').toString().replace(/"/g, '""') + '"').join(',')).join('\n');
            const link = document.createElement('a'); link.href = encodeURI(csv); link.download = 'payments.csv'; link.click();
        },
        toggleSelectAll() { this.selected = this.selectAll ? this.payments.map(p => p.id) : []; }
    }));
});
</script>

</body>
</html>
html>
