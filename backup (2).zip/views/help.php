<!DOCTYPE html>
<html lang="en">
<head>
    <script>
        const BASE_URL = '<?= BASE_URL ?>';
        function url(path) {
            if (!path) return '';
            if (path.indexOf('://') !== -1 || path.startsWith('mailto:') || path.startsWith('tel:') || path.startsWith('#') || path.startsWith('data:')) return path;
            return BASE_URL + path;
        }
    </script>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Center - <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?></title>
    <script src="<?= url('/assets/js/tailwindcss.js') ?>"></script>
    <script defer src="<?= url('/assets/js/alpine.min.js') ?>"></script>
    <link href="<?= url('/assets/css/google-sans.css') ?>" rel="stylesheet">
    <style>
        body { font-family: 'Google Sans', sans-serif; background-color: #f8f9fa; }
        .card { background: white; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24); transition: all 0.3s cubic-bezier(.25,.8,.25,1); }
        .card:hover { box-shadow: 0 14px 28px rgba(0,0,0,0.1), 0 10px 10px rgba(0,0,0,0.1); }
        .step-number { width: 32px; height: 32px; border-radius: 8px; display: flex; items-center: center; justify-content: center; font-weight: 700; font-size: 14px; }
    </style>
</head>
<body class="text-gray-800">

<div class="min-h-screen flex flex-col">

    <?php 
    $activePage = 'help';
    include __DIR__ . '/partials/header.php'; 
    ?>

    <main class="flex-grow p-8 mx-auto w-full space-y-12">
        <header class="text-center space-y-2">
            <h1 class="text-3xl font-bold text-gray-900">Knowledge Hub</h1>
            <p class="text-gray-500 max-w-2xl mx-auto">Master your <?php echo htmlspecialchars($settings['org_name'] ?? 'Simple CRM') ?> ecosystem with our comprehensive workflow guides and module documentation.</p>
        </header>

        <!-- Business Workflow -->
        <section class="space-y-6">
            <div class="flex items-center space-x-3">
                <div class="step-number bg-blue-600 text-white">1</div>
                <h2 class="text-xl font-bold">Standard Business Workflow</h2>
            </div>
            
            <div class="grid grid-cols-1 md:grid-cols-5 gap-4 relative">
                <!-- Connectors for Desktop -->
                <div class="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-gray-100 -z-10"></div>

                <div class="card p-5 text-center space-y-2 border-t-4 border-blue-500">
                    <div class="text-xs font-bold uppercase tracking-widest text-blue-600">Capture</div>
                    <div class="font-bold text-gray-800">Enquiries</div>
                    <p class="text-[11px] text-gray-500 leading-relaxed">Leads from web forms or manual entry.</p>
                </div>

                <div class="card p-5 text-center space-y-2 border-t-4 border-purple-500">
                    <div class="text-xs font-bold uppercase tracking-widest text-purple-600">Nurture</div>
                    <div class="font-bold text-gray-800">Approvals</div>
                    <p class="text-[11px] text-gray-500 leading-relaxed">Send professional estimates to clients.</p>
                </div>

                <div class="card p-5 text-center space-y-2 border-t-4 border-yellow-500">
                    <div class="text-xs font-bold uppercase tracking-widest text-yellow-600">Accept</div>
                    <div class="font-bold text-gray-800">Client Portal</div>
                    <p class="text-[11px] text-gray-500 leading-relaxed">Digital approval and project tracking.</p>
                </div>

                <div class="card p-5 text-center space-y-2 border-t-4 border-green-500">
                    <div class="text-xs font-bold uppercase tracking-widest text-green-600">Bill</div>
                    <div class="font-bold text-gray-800">Invoices</div>
                    <p class="text-[11px] text-gray-500 leading-relaxed">Convert approvals to billable records.</p>
                </div>

                <div class="card p-5 text-center space-y-2 border-t-4 border-indigo-500">
                    <div class="text-xs font-bold uppercase tracking-widest text-indigo-600">Reconcile</div>
                    <div class="font-bold text-gray-800">Payments</div>
                    <p class="text-[11px] text-gray-500 leading-relaxed">Track revenue and issue receipts.</p>
                </div>
            </div>
        </section>

        <!-- Detailed Modules -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Dashboard</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-blue-500 mr-2">•</span> View an overview of your CRM with key metrics and recent activity.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-purple-50 text-purple-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Clients</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-purple-500 mr-2">•</span> Manage your client information, view communication history, and convert enquiries into clients.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-orange-50 text-orange-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Enquiries</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-orange-500 mr-2">•</span> Capture and manage incoming project requests. Assign them to team members and convert to clients with ease.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Approvals</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-green-500 mr-2">•</span> Create detailed project estimates, send them to clients for approval, and track their status.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Invoices</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-indigo-500 mr-2">•</span> Generate invoices from approved approvals, send them to clients, and record payments received.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-yellow-50 text-yellow-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Payments</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-yellow-500 mr-2">•</span> Track all payments received from clients, view payment history, and manage overdue amounts.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-pink-50 text-pink-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Staff</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-pink-500 mr-2">•</span> Add and manage team members, their contact information, and assign them to roles.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-red-50 text-red-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Roles</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-red-500 mr-2">•</span> Define what each team member can do in the system by setting permissions for different roles.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-blue-50 text-blue-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Settings</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-blue-500 mr-2">•</span> Configure your organization's details, branding, email settings, and system preferences.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-purple-50 text-purple-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">AuditLog</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-purple-500 mr-2">•</span> View a chronological log of all important actions taken in the system for security and tracking.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-orange-50 text-orange-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Database</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-orange-500 mr-2">•</span> Perform database maintenance tasks such as cleaning up old data or clearing logs to keep the system running smoothly.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-green-50 text-green-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Notifications</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-green-500 mr-2">•</span> View and manage system notifications, including alerts for new enquiries, approval updates, and payment reminders.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Search</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-indigo-500 mr-2">•</span> Quickly find clients, enquiries, approvals, invoices, and more by typing keywords in the search bar.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-yellow-50 text-yellow-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Backup</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-yellow-500 mr-2">•</span> Download a complete backup of your CRM data or restore from a previous backup to safeguard your information.</li>
                    </ul>
                    </div>
                    <div class="card p-6 space-y-4">
                <div class="w-10 h-10 bg-pink-50 text-pink-600 rounded-lg flex items-center justify-center">
<svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                </div>
                    <h3 class="font-bold text-gray-800">Profile</h3>
                    <ul class="text-sm text-gray-600 space-y-3">
                    <li class="flex items-start"><span class="text-pink-500 mr-2">•</span> View and update your own profile information, including your name, email, and password.</li>
                    </ul>
                    </div>
        </div>

        <!-- FAQ -->
        <section class="space-y-6">
            <h2 class="text-xl font-bold">Common Questions</h2>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div class="space-y-2">
                    <h4 class="font-bold text-gray-800">How do I give staff members access?</h4>
                    <p class="text-sm text-gray-500 leading-relaxed">Navigate to the **Staff** module, create a new profile, and assign a **Role**. Permissions (View/Edit/Delete) can be globally adjusted in the **Roles** module.</p>
                </div>
                <div class="space-y-2">
                    <h4 class="font-bold text-gray-800">Is my data secure and backed up?</h4>
                    <p class="text-sm text-gray-500 leading-relaxed">Yes. All sensitive data is hashed. You can download a complete JSON snapshot of your entire database anytime from **Settings > Download Backup**.</p>
                </div>
            </div>
        </section>
    </main>

    <?php include __DIR__ . '/partials/footer.php'; ?>
</div>

</body>
</html>