<?php

namespace App\Repositories;

class JsonNoSqlRepository implements NoSqlRepositoryInterface {
    private $storagePath;

    public function __construct(string $storagePath) {
        $this->storagePath = rtrim($storagePath, '/');
    }

    private function getFilePath(string $collection): string {
        return "{$this->storagePath}/{$collection}.json";
    }

    private function readCollection(string $collection): array {
        $file = $this->getFilePath($collection);
        if (!file_exists($file)) return [];
        $content = file_get_contents($file);
        if ($content === false) return [];
        $data = json_decode($content, true);
        return is_array($data) ? $data : [];
    }

    private function writeCollection(string $collection, array $data): bool {
        $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        if ($json === false) {
            error_log("JSON encode failed for collection: {$collection}. Error: " . json_last_error_msg());
            return false;
        }
        $file = $this->getFilePath($collection);
        $result = file_put_contents($file, $json, LOCK_EX);
        if ($result === false) {
            $err = error_get_last();
            $reason = ($err['message'] ?? 'unknown');
            error_log("Write failed for collection: {$collection} at {$file}. Error: {$reason} | is_writable(file)=" . var_export(is_writable($file), true) . " | is_writable(dir)=" . var_export(is_writable(dirname($file)), true));
        }
        return $result !== false;
    }

    public function findOne(string $collection, array $criteria, bool $includeDeleted = false): ?array {
        $items = $this->readCollection($collection);
        foreach ($items as $item) {
            if (!$includeDeleted && !empty($item['deleted_at'])) continue;
            
            $match = true;
            foreach ($criteria as $key => $value) {
                if (!isset($item[$key]) || $item[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) return $item;
        }
        return null;
    }

    public function findAll(string $collection, array $criteria = [], array $options = []): array {
        $items = $this->readCollection($collection);
        $includeDeleted = $options['includeDeleted'] ?? false;
        
        $results = [];
        foreach ($items as $item) {
            if (!$includeDeleted && !empty($item['deleted_at'])) continue;

            $match = true;
            foreach ($criteria as $key => $value) {
                if (!isset($item[$key]) || $item[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) $results[] = $item;
        }

        // Apply Sorting if provided
        if (!empty($options['sort'])) {
            $sortKey = $options['sort']['key'];
            $sortOrder = $options['sort']['order'] ?? 'asc';
            usort($results, function($a, $b) use ($sortKey, $sortOrder) {
                $valA = $a[$sortKey] ?? '';
                $valB = $b[$sortKey] ?? '';
                if ($sortOrder === 'desc') {
                    return $valB <=> $valA;
                }
                return $valA <=> $valB;
            });
        }

        // Apply Pagination
        if (isset($options['limit'])) {
            $offset = $options['offset'] ?? 0;
            $results = array_slice($results, $offset, $options['limit']);
        }

        return $results;
    }

    public function count(string $collection, array $criteria = [], bool $includeDeleted = false): int {
        $items = $this->readCollection($collection);
        $count = 0;
        foreach ($items as $item) {
            if (!$includeDeleted && !empty($item['deleted_at'])) continue;
            
            $match = true;
            foreach ($criteria as $key => $value) {
                if (!isset($item[$key]) || $item[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) $count++;
        }
        return $count;
    }

    public function updateOne(string $collection, array $criteria, array $data): bool {
        $items = $this->readCollection($collection);
        $updated = false;
        $oldData = null;
        $newData = null;

        foreach ($items as &$item) {
            $match = true;
            foreach ($criteria as $key => $value) {
                if (!isset($item[$key]) || $item[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match) {
                $oldData = $item;
                $item = array_merge($item, $data);
                $newData = $item;
                $updated = true;
                break;
            }
        }

        $success = $updated ? $this->writeCollection($collection, $items) : false;
        
        if ($success && $collection !== 'audit_logs') {
            \App\Services\AuditLogger::getInstance()->log('update', $collection, $oldData['id'] ?? null, $oldData, $newData);
        }

        return $success;
    }

    public function insertOne(string $collection, array $data): bool {
        $items = $this->readCollection($collection);
        $items[] = $data;
        $success = $this->writeCollection($collection, $items);

        if ($success && $collection !== 'audit_logs') {
            \App\Services\AuditLogger::getInstance()->log('create', $collection, $data['id'] ?? null, null, $data);
        }

        return $success;
    }

    public function deleteOne(string $collection, array $criteria, bool $permanent = false): bool {
        $items = $this->readCollection($collection);
        $updated = false;
        $deletedItem = null;
        
        if ($permanent) {
            $initialCount = count($items);
            $newItems = [];
            foreach ($items as $item) {
                $match = true;
                foreach ($criteria as $key => $value) {
                    if (!isset($item[$key]) || $item[$key] !== $value) {
                        $match = false;
                        break;
                    }
                }
                if ($match && $deletedItem === null) {
                    $deletedItem = $item;
                    continue;
                }
                $newItems[] = $item;
            }
            $items = $newItems;
            $updated = count($items) < $initialCount;
        } else {
            foreach ($items as &$item) {
                $match = true;
                foreach ($criteria as $key => $value) {
                    if (!isset($item[$key]) || $item[$key] !== $value) {
                        $match = false;
                        break;
                    }
                }
                if ($match) {
                    $item['deleted_at'] = date('Y-m-d H:i:s');
                    $deletedItem = $item;
                    $updated = true;
                    break;
                }
            }
        }

        $success = $updated ? $this->writeCollection($collection, $items) : false;

        if ($success && $collection !== 'audit_logs' && $deletedItem) {
            \App\Services\AuditLogger::getInstance()->log($permanent ? 'permanent_delete' : 'soft_delete', $collection, $deletedItem['id'] ?? null, $deletedItem, null);
        }

        return $success;
    }

    public function restore(string $collection, array $criteria): bool {
        $items = $this->readCollection($collection);
        $updated = false;
        $restoredItem = null;

        foreach ($items as &$item) {
            $match = true;
            foreach ($criteria as $key => $value) {
                if (!isset($item[$key]) || $item[$key] !== $value) {
                    $match = false;
                    break;
                }
            }
            if ($match && !empty($item['deleted_at'])) {
                unset($item['deleted_at']);
                $restoredItem = $item;
                $updated = true;
                break;
            }
        }

        $success = $updated ? $this->writeCollection($collection, $items) : false;

        if ($success && $collection !== 'audit_logs' && $restoredItem) {
            \App\Services\AuditLogger::getInstance()->log('restore', $collection, $restoredItem['id'] ?? null, null, $restoredItem);
        }

        return $success;
    }
}
