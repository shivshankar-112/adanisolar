<?php

namespace App\Repositories;

interface NoSqlRepositoryInterface {
    public function findOne(string $collection, array $criteria, bool $includeDeleted = false): ?array;
    public function findAll(string $collection, array $criteria = [], array $options = []): array;
    public function updateOne(string $collection, array $criteria, array $data): bool;
    public function insertOne(string $collection, array $data): bool;
    public function deleteOne(string $collection, array $criteria, bool $permanent = false): bool;
    public function count(string $collection, array $criteria = [], bool $includeDeleted = false): int;
}
