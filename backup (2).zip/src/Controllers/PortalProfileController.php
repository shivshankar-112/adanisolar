<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;

class PortalProfileController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function update() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        $clientId = $_SESSION['client_id'];
        $client = $this->repository->findOne('clients', ['id' => $clientId]);

        if (empty($data['current_password']) || !password_verify($data['current_password'], $client['password'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Current password incorrect']);
            return;
        }

        if (empty($data['new_password']) || $data['new_password'] !== $data['confirm_password']) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'New passwords do not match']);
            return;
        }

        $success = $this->repository->updateOne('clients', ['id' => $clientId], [
            'password' => password_hash($data['new_password'], PASSWORD_DEFAULT)
        ]);

        if ($success) {
            $client = $this->repository->findOne('clients', ['id' => $clientId]);
            \App\Services\NotificationService::getInstance()->notifyAdmins(
                "Security Update", 
                "Client {$client['client_name']} has changed their portal password.",
                'warning',
                '/clients'
            );
            echo json_encode(['status' => 'success', 'message' => 'Password changed successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to change password']);
        }
    }
}
