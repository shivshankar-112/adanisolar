<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\EmailService;

use App\Services\PermissionHelper;

class InvoiceController {
    private $repository;
    private $dbPath;

    public function __construct() {
        $this->dbPath = __DIR__ . '/../../storage/db';
        $this->repository = new JsonNoSqlRepository($this->dbPath);
    }

    public function index() {
        if (!PermissionHelper::check('invoices', 'view')) {
            http_response_code(403); echo "Access Denied"; exit;
        }

        $page = (int)($_GET['page'] ?? 1);
        $perPage = 25;
        $offset = ($page - 1) * $perPage;
        
        $search = $_GET['q'] ?? '';
        $status = $_GET['status'] ?? '';
        $trash = ($_GET['trash'] ?? '') === '1';

        $criteria = [];
        if ($status) $criteria['status'] = $status;

        $options = [
            'sort' => ['key' => 'created_at', 'order' => 'desc'],
            'limit' => $perPage,
            'offset' => $offset,
            'includeDeleted' => $trash
        ];

        if ($search) {
            $all = $this->repository->findAll('invoices', $criteria, ['includeDeleted' => $trash]);
            $invoices = array_filter($all, function($i) use ($search) {
                return strpos(strtolower($i['client_name'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($i['invoice_no'] ?? ''), strtolower($search)) !== false;
            });
            $totalInvoices = count($invoices);
            $invoices = array_slice($invoices, $offset, $perPage);
        } else {
            $totalInvoices = $this->repository->count('invoices', $criteria, $trash);
            $invoices = $this->repository->findAll('invoices', $criteria, $options);
        }

        $invoices = PermissionHelper::filterByOwnership($invoices, 'invoices', 'view');

        if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
            header('Content-Type: application/json');
            echo json_encode(['invoices' => array_values($invoices), 'total' => $totalInvoices]);
            exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        $pagination = [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $totalInvoices,
            'total_pages' => ceil($totalInvoices / $perPage)
        ];

        require_once __DIR__ . '/../../views/invoices.php';
    }

    public function restore() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->restore('invoices', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function store() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['client_name']) || empty($data['email'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        // Find default invoice template
        $defaultTemplateId = null;
        if (!empty($settings['invoice_templates'])) {
            foreach ($settings['invoice_templates'] as $tpl) {
                if (!empty($tpl['is_default'])) {
                    $defaultTemplateId = $tpl['id'];
                    break;
                }
            }
            if (!$defaultTemplateId) $defaultTemplateId = $settings['invoice_templates'][0]['id'];
        }
        
        // Generate Invoice Number
        $format = $settings['invoice_format'];
        if ($format['type'] === 'sequential') {
            $invoiceNo = $format['prefix'] . $format['start'];
            $settings['invoice_format']['start']++;
            $this->repository->updateOne('organization', ['id' => 'org_settings'], $settings);
        } else {
            $invoiceNo = $format['prefix'] . rand(10000, 99999);
        }

        $items = $data['items'] ?? [];
        $totalAmount = 0;
        foreach ($items as $item) {
            $totalAmount += floatval($item['price'] ?? 0);
        }

        // Link to client if exists
        $clientId = null;
        $client = $this->repository->findOne('clients', ['email' => $data['email']]);
        if ($client) {
            $clientId = $client['id'];
        }

        $invoice = [
            'id' => uniqid(),
            'invoice_no' => $invoiceNo,
            'client_id' => $clientId,
            'approval_id' => $data['approval_id'] ?? null,
            'template_id' => $defaultTemplateId,
            'client_name' => $data['client_name'],
            'email' => $data['email'],
            'subject' => $data['subject'] ?? 'Professional Services',
            'amount' => $totalAmount,
            'items' => $items,
            'bank_id' => $data['bank_id'] ?? '',
            'status' => 'Draft',
            'created_by' => $_SESSION['user_id'],
            'created_at' => !empty($data['invoice_date']) ? $data['invoice_date'] : date('Y-m-d')
        ];

        $this->repository->insertOne('invoices', $invoice);

        echo json_encode(['status' => 'success', 'message' => 'Invoice created', 'invoice_no' => $invoiceNo, 'id' => $invoice['id']]);
    }

    public function update() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        $invoice = $this->repository->findOne('invoices', ['id' => $data['id']]);
        if (!$invoice || !PermissionHelper::canAccessRecord($invoice, 'invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $success = $this->repository->updateOne('invoices', ['id' => $data['id']], $data);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function updateStatus() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['id']) || empty($data['status'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        // Ownership check
        $invoice = $this->repository->findOne('invoices', ['id' => $data['id']]);
        if (!$invoice || !PermissionHelper::canAccessRecord($invoice, 'invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Cannot update this record']); exit;
        }

        $success = $this->repository->updateOne('invoices', ['id' => $data['id']], ['status' => $data['status']]);
        
        if ($success) {
            $invoice = $this->repository->findOne('invoices', ['id' => $data['id']]);
            $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
            
            $tplId = null;
            if ($data['status'] === 'Paid') {
                $tplId = 'payment_received';
            } elseif ($data['status'] === 'Cancelled') {
                $tplId = 'invoice_cancelled';
            }

            $tpl = null;
            if ($tplId) {
                foreach ($settings['templates'] as $t) {
                    if ($t['id'] === $tplId) {
                        $tpl = $t;
                        break;
                    }
                }
            }

            if ($tpl) {
                $emailService = new EmailService($settings['smtp']);
                $body = $emailService->renderTemplate($tpl['body'], [
                    'name' => $invoice['client_name'],
                    'invoice_no' => $invoice['invoice_no'],
                    'amount' => $invoice['amount']
                ]);
                $emailService->send($invoice['email'], $tpl['subject'], $body, '', '', 'document.pdf', $invoice['client_id'] ?? null);
            }
        }

        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function sendInvoiceEmail() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['id']) || empty($data['to']) || empty($data['subject']) || empty($data['body'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        $invoice = $this->repository->findOne('invoices', ['id' => $data['id']]);
        if (!$invoice || !PermissionHelper::canAccessRecord($invoice, 'invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        try {
            $emailService = new EmailService($settings['smtp']);
            $success = $emailService->send(
                $data['to'], 
                $data['subject'], 
                $data['body'], 
                $data['cc'] ?? '', 
                $data['attachment'] ?? '', 
                "Invoice_{$invoice['invoice_no']}.pdf",
                $invoice['client_id'] ?? null
            );

            if ($success) {
                echo json_encode(['status' => 'success', 'message' => 'Email sent successfully']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to send email']);
            }
        } catch (\Exception $e) {
            http_response_code(500); echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function bulkUpdate() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids']) || empty($data['updates'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            $record = $this->repository->findOne('invoices', ['id' => $id]);
            if ($record && PermissionHelper::canAccessRecord($record, 'invoices', 'edit')) {
                if ($this->repository->updateOne('invoices', ['id' => $id], $data['updates'])) {
                    $successCount++;
                }
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function bulkDelete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            $record = $this->repository->findOne('invoices', ['id' => $id]);
            if ($record && PermissionHelper::canAccessRecord($record, 'invoices', 'delete')) {
                if ($this->repository->deleteOne('invoices', ['id' => $id])) {
                    $successCount++;
                }
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function getUnpaidInvoices() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'view')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $invoices = $this->repository->findAll('invoices');
        $unpaidInvoices = array_filter($invoices, function($inv) {
            return ($inv['status'] === 'Unpaid' || $inv['status'] === 'Partial Paid') && empty($inv['deleted_at']);
        });

        echo json_encode(['status' => 'success', 'invoices' => array_values($unpaidInvoices)]);
    }

    public function recordPayment() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('invoices', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['invoice_id']) || empty($data['amount_received'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        $invoice = $this->repository->findOne('invoices', ['id' => $data['invoice_id']]);
        if (!$invoice) {
            http_response_code(404); echo json_encode(['status' => 'error', 'message' => 'Invoice not found']); exit;
        }

        if ($invoice['status'] === 'Paid') {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invoice is already fully paid']); exit;
        }

        // Calculate Total Paid so far
        $allPayments = $this->repository->findAll('payments');
        $totalPaidBefore = 0;
        foreach ($allPayments as $p) {
            if ($p['invoice_id'] === $invoice['id']) {
                $totalPaidBefore += floatval($p['amount']);
            }
        }

        $remainingDue = floatval($invoice['amount']) - $totalPaidBefore;
        $amountReceived = floatval($data['amount_received']);

        if ($amountReceived > $remainingDue + 0.01) { // Adding small buffer for floating point
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Amount received exceeds remaining due: ₹' . number_format($remainingDue, 2)]); exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);

        // Generate Payment Number
        if (!isset($settings['payment_format'])) {
            $settings['payment_format'] = ['prefix' => 'PAY-', 'start' => 4001, 'type' => 'sequential'];
        }
        
        $format = $settings['payment_format'];
        $paymentNo = $format['prefix'] . $format['start'];
        $settings['payment_format']['start']++;
        $this->repository->updateOne('organization', ['id' => 'org_settings'], $settings);

        // Store Payment Record
        $payment = [
            'id' => uniqid(),
            'payment_no' => $paymentNo,
            'client_id' => $invoice['client_id'] ?? null,
            'invoice_id' => $data['invoice_id'],
            'invoice_no' => $invoice['invoice_no'],
            'client_name' => $invoice['client_name'],
            'email' => $invoice['email'] ?? '',
            'amount' => $amountReceived,
            'method' => $data['method'] ?? 'Bank Transfer',
            'date' => $data['date'] ?? date('Y-m-d'),
            'note' => $data['note'] ?? '',
            'created_at' => date('Y-m-d H:i:s')
        ];
        $this->repository->insertOne('payments', $payment);

        // Update Invoice Status
        $totalPaidAfter = $totalPaidBefore + $amountReceived;
        $newStatus = 'Partial Paid';
        if ($totalPaidAfter >= floatval($invoice['amount']) - 0.01) {
            $newStatus = 'Paid';
        }
        
        $this->repository->updateOne('invoices', ['id' => $invoice['id']], ['status' => $newStatus]);

        echo json_encode([
            'status' => 'success', 
            'message' => 'Payment recorded successfully', 
            'new_status' => $newStatus,
            'payment' => $payment
        ]);
    }

    public function delete() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        // Check Permission
        if (!PermissionHelper::check('invoices', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        // Check Ownership
        $invoice = $this->repository->findOne('invoices', ['id' => $data['id']]);
        if ($invoice && !PermissionHelper::canAccessRecord($invoice, 'invoices', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Not your record']); exit;
        }

        $success = $this->repository->deleteOne('invoices', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }
}
