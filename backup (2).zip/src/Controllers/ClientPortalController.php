<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;

class ClientPortalController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
        
        // Custom Auth Check for Client Portal
        if (session_status() === PHP_SESSION_NONE) session_start();
        
        if (!isset($_SESSION['client_id'])) {
            $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
            if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
                http_response_code(401);
                echo json_encode(['status' => 'error', 'message' => 'Unauthorized']);
                exit;
            }
            if ($uri !== '/login') {
                header('Location: ' . url('/login'));
                exit;
            }
        }
    }

    public function dashboard() {
        $clientId = $_SESSION['client_id'];
        $enquiries = $this->repository->findAll('enquiries', ['client_id' => $clientId]);
        $approvals = $this->repository->findAll('approvals', ['client_id' => $clientId]);
        $invoices = $this->repository->findAll('invoices', ['client_id' => $clientId]);
        
        $payments = $this->repository->findAll('payments', ['client_id' => $clientId]);

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']) ?: [];
        $client = $this->repository->findOne('clients', ['id' => $clientId]);

        require __DIR__ . '/../../views/client/dashboard.php';
    }

    public function approvals() {
        $clientId = $_SESSION['client_id'];
        $approvals = $this->repository->findAll('approvals', ['client_id' => $clientId]);
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']) ?: [];
        $client = $this->repository->findOne('clients', ['id' => $clientId]);
        require __DIR__ . '/../../views/client/approvals.php';
    }

    public function invoices() {
        $clientId = $_SESSION['client_id'];
        $invoices = $this->repository->findAll('invoices', ['client_id' => $clientId]);
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']) ?: [];
        $client = $this->repository->findOne('clients', ['id' => $clientId]);

        // If setting is enabled, hide invoices that have no payment recorded yet
        if (!empty($settings['hide_invoice_until_payment'])) {
            $payments = $this->repository->findAll('payments');
            $paidInvoiceIds = [];
            foreach ($payments as $p) {
                if (!empty($p['invoice_id'])) {
                    $paidInvoiceIds[] = $p['invoice_id'];
                }
            }
            $paidInvoiceIds = array_unique($paidInvoiceIds);
            $invoices = array_values(array_filter($invoices, function($inv) use ($paidInvoiceIds) {
                return in_array($inv['id'], $paidInvoiceIds);
            }));
        }

        require __DIR__ . '/../../views/client/invoices.php';
    }

    public function payments() {
        $clientId = $_SESSION['client_id'];
        $invoices = $this->repository->findAll('invoices', ['client_id' => $clientId]);
        $payments = $this->repository->findAll('payments', ['client_id' => $clientId]);
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']) ?: [];
        $client = $this->repository->findOne('clients', ['id' => $clientId]);
        require __DIR__ . '/../../views/client/payments.php';
    }

    public function updateApprovalStatus() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        $clientId = $_SESSION['client_id'];
        
        $approval = $this->repository->findOne('approvals', ['id' => $data['id'], 'client_id' => $clientId]);
        if (!$approval) {
            echo json_encode(['status' => 'error', 'message' => 'Approval not found']);
            exit;
        }

        if (!in_array($data['status'], ['Accepted', 'Rejected'])) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid status']);
            exit;
        }

        $success = $this->repository->updateOne('approvals', ['id' => $data['id']], ['status' => $data['status']]);
        
        if ($success) {
            $approval = $this->repository->findOne('approvals', ['id' => $data['id']]);
            $clientName = $_SESSION['client_name'] ?? 'Client';
            \App\Services\NotificationService::getInstance()->notifyAdmins(
                "Approval {$data['status']}", 
                "Client {$clientName} has {$data['status']} approval {$approval['approval_no']}",
                $data['status'] === 'Accepted' ? 'success' : 'warning',
                "/approvals?open={$data['id']}"
            );
        }

        echo json_encode(['status' => $success ? 'success' : 'error']);
    }
}
