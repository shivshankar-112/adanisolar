<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;

class AuthController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function showLogin() {
        if (isset($_SESSION['user_id'])) {
            header('Location: ' . url('/dashboard'));
            exit;
        }
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        require_once __DIR__ . '/../../views/login.php';
    }

    public function login() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['username']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Username and password required']);
            return;
        }

        $user = $this->repository->findOne('users', ['username' => $data['username']]);

        if ($user && password_verify($data['password'], $user['password'])) {
            $role = $this->repository->findOne('roles', ['id' => $user['role_id']]);
            
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['role_id'] = $user['role_id'];
            $_SESSION['role_name'] = $role['name'] ?? 'Guest';
            $_SESSION['permissions'] = $role['permissions'] ?? [];
            $_SESSION['last_activity'] = time();

            if (!empty($data['remember'])) {
                $token = bin2hex(random_bytes(32));
                setcookie('remember_me', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true); // 30 days
                
                // Save token to user
                $this->repository->updateOne('users', ['id' => $user['id']], ['remember_token' => $token]);
            }
            
            \App\Services\AuditLogger::getInstance()->log('login', 'users', $user['id'], null, ['username' => $user['username']]);

            echo json_encode(['status' => 'success', 'message' => 'Login successful']);
        } else {
            \App\Services\AuditLogger::getInstance()->log('login_failure', 'users', null, null, ['username' => $data['username']]);
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
        }
    }

    public function logout() {
        if (isset($_SESSION['user_id'])) {
            $this->repository->updateOne('users', ['id' => $_SESSION['user_id']], ['remember_token' => null]);
        }
        setcookie('remember_me', '', time() - 3600, '/');
        session_destroy();
        header('Location: ' . url('/admin/login'));
        exit;
    }
}
