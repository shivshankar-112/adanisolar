<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\EmailService;

use App\Services\PermissionHelper;

class ApprovalController {
    private $repository;
    private $dbPath;

    public function __construct() {
        $this->dbPath = __DIR__ . '/../../storage/db';
        $this->repository = new JsonNoSqlRepository($this->dbPath);
    }

    public function index() {
        if (!PermissionHelper::check('approvals', 'view')) {
            http_response_code(403); echo "Access Denied"; exit;
        }

        $page = (int)($_GET['page'] ?? 1);
        $perPage = 25;
        $offset = ($page - 1) * $perPage;
        
        $search = $_GET['q'] ?? '';
        $status = $_GET['status'] ?? '';
        $trash = ($_GET['trash'] ?? '') === '1';

        $criteria = [];
        if ($status) $criteria['status'] = $status;

        $options = [
            'sort' => ['key' => 'created_at', 'order' => 'desc'],
            'limit' => $perPage,
            'offset' => $offset,
            'includeDeleted' => $trash
        ];

        if ($search) {
            $all = $this->repository->findAll('approvals', $criteria, ['includeDeleted' => $trash]);
            $approvals = array_filter($all, function($p) use ($search) {
                return strpos(strtolower($p['client_name'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($p['email'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($p['approval_no'] ?? ''), strtolower($search)) !== false;
            });
            $totalApprovals = count($approvals);
            $approvals = array_slice($approvals, $offset, $perPage);
        } else {
            $totalApprovals = $this->repository->count('approvals', $criteria, $trash);
            $approvals = $this->repository->findAll('approvals', $criteria, $options);
        }

        // Enrich approvals with enquiry and client data for shortcodes
        $enquiries = $this->repository->findAll('enquiries');
        $enquiryMap = [];
        foreach ($enquiries as $e) {
            $enquiryMap[$e['id']] = $e;
        }

        $clients = $this->repository->findAll('clients');
        $clientMap = [];
        foreach ($clients as $c) {
            $clientMap[$c['id']] = $c;
        }

        foreach ($approvals as &$p) {
            $p['enquiry'] = (!empty($p['enquiry_id']) && isset($enquiryMap[$p['enquiry_id']])) ? $enquiryMap[$p['enquiry_id']] : null;
            $p['client'] = (!empty($p['client_id']) && isset($clientMap[$p['client_id']])) ? $clientMap[$p['client_id']] : null;
        }

        $approvals = PermissionHelper::filterByOwnership($approvals, 'approvals', 'view');
        
        if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
            header('Content-Type: application/json');
            echo json_encode(['approvals' => array_values($approvals), 'total' => $totalApprovals]);
            exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        $pagination = [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $totalApprovals,
            'total_pages' => ceil($totalApprovals / $perPage)
        ];

        require_once __DIR__ . '/../../views/approvals.php';
    }

    public function restore() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('approvals', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->restore('approvals', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function store() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('approvals', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['client_name']) || empty($data['email'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        // Find default template
        $defaultTemplateId = null;
        if (!empty($settings['approval_templates'])) {
            foreach ($settings['approval_templates'] as $tpl) {
                if (!empty($tpl['is_default'])) {
                    $defaultTemplateId = $tpl['id'];
                    break;
                }
            }
            // Fallback to first template if no default set
            if (!$defaultTemplateId) $defaultTemplateId = $settings['approval_templates'][0]['id'];
        }

        // Generate Approval Number
        $format = $settings['approval_format'];
        if ($format['type'] === 'sequential') {
            $approvalNo = $format['prefix'] . $format['start'];
            $settings['approval_format']['start']++;
            $this->repository->updateOne('organization', ['id' => 'org_settings'], $settings);
        } else {
            $approvalNo = $format['prefix'] . rand(10000, 99999);
        }

        $items = $data['items'] ?? [];
        $totalAmount = 0;
        foreach ($items as $item) {
            $totalAmount += floatval($item['price'] ?? 0);
        }

        // Link to client if exists
        $clientId = null;
        $client = $this->repository->findOne('clients', ['email' => $data['email']]);
        if ($client) {
            $clientId = $client['id'];
        }

        $approval = [
            'id' => uniqid(),
            'approval_no' => $approvalNo,
            'client_id' => $clientId,
            'enquiry_id' => $data['enquiry_id'] ?? null,
            'client_name' => $data['client_name'],
            'email' => $data['email'],
            'template_id' => $defaultTemplateId,
            'subject' => $data['subject'] ?? 'Business Approval',
            'amount' => $totalAmount,
            'items' => $items,
            'status' => 'Draft',
            'created_by' => $_SESSION['user_id'],
            'created_at' => !empty($data['approval_date']) ? $data['approval_date'] : date('Y-m-d')
        ];

        $this->repository->insertOne('approvals', $approval);

        // If converting from enquiry, update enquiry status
        if (!empty($data['enquiry_id'])) {
            $this->repository->updateOne('enquiries', ['id' => $data['enquiry_id']], ['status' => 'Converted']);
        }

        echo json_encode(['status' => 'success', 'message' => 'Approval created', 'approval_no' => $approvalNo, 'id' => $approval['id']]);
    }

    public function update() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('approvals', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        // Ownership check
        $approval = $this->repository->findOne('approvals', ['id' => $data['id']]);
        if (!$approval || !PermissionHelper::canAccessRecord($approval, 'approvals', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Cannot update this record']); exit;
        }

        // We only want to update specific fields if they are provided, but to be safe we'll use array_merge in repo
        $success = $this->repository->updateOne('approvals', ['id' => $data['id']], $data);
        
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function updateStatus() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['id']) || empty($data['status'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        // Ownership check
        $approval = $this->repository->findOne('approvals', ['id' => $data['id']]);
        if (!$approval || !PermissionHelper::canAccessRecord($approval, 'approvals', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Cannot update this record']); exit;
        }

        $success = $this->repository->updateOne('approvals', ['id' => $data['id']], ['status' => $data['status']]);
        
        if ($success) {
            $approval = $this->repository->findOne('approvals', ['id' => $data['id']]);
            
            // If Accepted, we don't automatically create invoice here because user needs to EDIT it first.
            // We'll handle the 'Convert to Invoice' logic in the frontend by opening a pre-filled Invoice modal.
            
            $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
            
            $tplId = ($data['status'] === 'Accepted') ? 'approval_accepted' : 'approval_rejected';
            $tpl = null;
            if (isset($settings['templates'])) {
                foreach ($settings['templates'] as $t) {
                    if ($t['id'] === $tplId) {
                        $tpl = $t;
                        break;
                    }
                }
            }

            if ($tpl) {
                try {
                    // Re-load settings to ensure latest data
                    $currentSettings = $this->repository->findOne('organization', ['id' => 'org_settings']);
                    $smtp = $currentSettings['smtp'] ?? [];
                    // Ensure a fallback from_email exists
                    if (empty($smtp['from_email'])) {
                        $smtp['from_email'] = $currentSettings['email'] ?? 'no-reply@crm.com';
                    }
                    
                    $emailService = new EmailService($smtp);
                    $body = $emailService->renderTemplate($tpl['body'], [
                        'name' => $approval['client_name'],
                        'approval_no' => $approval['approval_no'],
                        'status' => $data['status']
                    ]);
                    $emailService->send($approval['email'], $tpl['subject'], $body, '', '', 'document.pdf', $approval['client_id'] ?? null);
                } catch (\Exception $e) {
                    error_log("SMTP Error in ApprovalController: " . $e->getMessage());
                }
            }
        }

        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function sendApprovalEmail() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['id']) || empty($data['to']) || empty($data['subject']) || empty($data['body'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        $approval = $this->repository->findOne('approvals', ['id' => $data['id']]);
        if (!$approval || !PermissionHelper::canAccessRecord($approval, 'approvals', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        try {
            $emailService = new EmailService($settings['smtp']);
            $success = $emailService->send(
                $data['to'], 
                $data['subject'], 
                $data['body'], 
                $data['cc'] ?? '', 
                $data['attachment'] ?? '', 
                "Approval_{$approval['approval_no']}.pdf",
                $approval['client_id'] ?? null
            );

            if ($success) {
                // Auto update status to Sent if it was Draft
                if ($approval['status'] === 'Draft') {
                    $this->repository->updateOne('approvals', ['id' => $data['id']], ['status' => 'Sent']);
                }
                echo json_encode(['status' => 'success', 'message' => 'Email sent successfully']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to send email']);
            }
        } catch (\Exception $e) {
            http_response_code(500); echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function bulkUpdate() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('approvals', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids']) || empty($data['updates'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            $record = $this->repository->findOne('approvals', ['id' => $id]);
            if ($record && PermissionHelper::canAccessRecord($record, 'approvals', 'edit')) {
                if ($this->repository->updateOne('approvals', ['id' => $id], $data['updates'])) {
                    $successCount++;
                }
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function bulkDelete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('approvals', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            $record = $this->repository->findOne('approvals', ['id' => $id]);
            if ($record && PermissionHelper::canAccessRecord($record, 'approvals', 'delete')) {
                if ($this->repository->deleteOne('approvals', ['id' => $id])) {
                    $successCount++;
                }
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function delete() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        // Check Permission
        if (!PermissionHelper::check('approvals', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        // Check Ownership if scope is "own"
        $approval = $this->repository->findOne('approvals', ['id' => $data['id']]);
        if ($approval && !PermissionHelper::canAccessRecord($approval, 'approvals', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Not your record']); exit;
        }

        $success = $this->repository->deleteOne('approvals', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }
}
