<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class DashboardController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        // Fetch all data for analytics
        $enquiries = $this->repository->findAll('enquiries');
        $approvals = $this->repository->findAll('approvals');
        $invoices = $this->repository->findAll('invoices');

        // Apply RBAC filters
        $enquiries = PermissionHelper::filterByOwnership($enquiries, 'enquiries', 'view');
        $approvals = PermissionHelper::filterByOwnership($approvals, 'approvals', 'view');
        $invoices = PermissionHelper::filterByOwnership($invoices, 'invoices', 'view');

        // Fetch Settings for branding
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);

        // Calculate Stats
        $stats = [
            'total_enquiries' => count($enquiries),
            'pending_approvals' => count(array_filter($approvals, fn($p) => $p['status'] === 'Sent')),
            'paid_invoices' => count(array_filter($invoices, fn($i) => $i['status'] === 'Paid')),
            'revenue' => array_reduce($invoices, function($acc, $i) {
                return $acc + ($i['status'] === 'Paid' ? ($i['amount'] ?? 0) : 0);
            }, 0)
        ];

        // Recent Activity (last 5 items across modules)
        $activity = array_merge(
            array_map(fn($e) => ['type' => 'Enquiry', 'desc' => $e['client_name'], 'date' => $e['created_at'], 'no' => $e['enquiry_no']], $enquiries),
            array_map(fn($p) => ['type' => 'Approval', 'desc' => $p['client_name'], 'date' => $p['created_at'], 'no' => $p['approval_no']], $approvals),
            array_map(fn($i) => ['type' => 'Invoice', 'desc' => $i['client_name'], 'date' => $i['created_at'], 'no' => $i['invoice_no']], $invoices)
        );
        
        usort($activity, fn($a, $b) => strcmp($b['date'], $a['date']));
        $activity = array_slice($activity, 0, 5);

        require_once __DIR__ . '/../../views/dashboard.php';
    }
}
