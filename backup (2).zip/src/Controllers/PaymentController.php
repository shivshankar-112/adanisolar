<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\EmailService;
use App\Services\PermissionHelper;

class PaymentController {
    private $repository;
    private $dbPath;

    public function __construct() {
        $this->dbPath = __DIR__ . '/../../storage/db';
        $this->repository = new JsonNoSqlRepository($this->dbPath);
    }

    public function index() {
        if (!PermissionHelper::check('payments', 'view')) {
            http_response_code(403); echo "Access Denied"; exit;
        }

        $page = (int)($_GET['page'] ?? 1);
        $perPage = 25;
        $offset = ($page - 1) * $perPage;
        
        $search = $_GET['q'] ?? '';
        $trash = ($_GET['trash'] ?? '') === '1';

        $criteria = [];
        $options = [
            'sort' => ['key' => 'created_at', 'order' => 'desc'],
            'limit' => $perPage,
            'offset' => $offset,
            'includeDeleted' => $trash
        ];

        if ($search) {
            $all = $this->repository->findAll('payments', $criteria, ['includeDeleted' => $trash]);
            $payments = array_filter($all, function($p) use ($search) {
                return strpos(strtolower($p['client_name'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($p['payment_no'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($p['invoice_no'] ?? ''), strtolower($search)) !== false;
            });
            $totalPayments = count($payments);
            $payments = array_slice($payments, $offset, $perPage);
        } else {
            $totalPayments = $this->repository->count('payments', $criteria, $trash);
            $payments = $this->repository->findAll('payments', $criteria, $options);
        }

        // Attach email to payments if missing
        $invoices = $this->repository->findAll('invoices');
        $invoiceMap = [];
        foreach ($invoices as $inv) { $invoiceMap[$inv['id']] = $inv; }
        foreach ($payments as &$p) {
            if (empty($p['email']) && !empty($p['invoice_id']) && isset($invoiceMap[$p['invoice_id']])) {
                $p['email'] = $invoiceMap[$p['invoice_id']]['email'] ?? '';
            }
        }

        $payments = PermissionHelper::filterByOwnership($payments, 'payments', 'view');

        if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
            header('Content-Type: application/json');
            echo json_encode(['payments' => array_values($payments), 'total' => $totalPayments]);
            exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        $pagination = [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $totalPayments,
            'total_pages' => ceil($totalPayments / $perPage)
        ];

        require_once __DIR__ . '/../../views/payments.php';
    }

    public function restore() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('payments', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->restore('payments', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function bulkDelete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('payments', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        $invoicesToReevaluate = [];

        foreach ($data['ids'] as $id) {
            $record = $this->repository->findOne('payments', ['id' => $id]);
            if ($record && PermissionHelper::canAccessRecord($record, 'payments', 'delete')) {
                if (!empty($record['invoice_id'])) {
                    $invoicesToReevaluate[] = $record['invoice_id'];
                }
                if ($this->repository->deleteOne('payments', ['id' => $id])) {
                    $successCount++;
                }
            }
        }

        // Re-evaluate statuses
        foreach (array_unique($invoicesToReevaluate) as $invId) {
            $this->syncInvoiceStatus($invId);
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function sendPaymentEmail() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['id']) || empty($data['to']) || empty($data['subject']) || empty($data['body'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        $payment = $this->repository->findOne('payments', ['id' => $data['id']]);
        if (!$payment || !PermissionHelper::canAccessRecord($payment, 'payments', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        // Find client_id via invoice
        $clientId = null;
        if (!empty($payment['invoice_id'])) {
            $invoice = $this->repository->findOne('invoices', ['id' => $payment['invoice_id']]);
            $clientId = $invoice['client_id'] ?? null;
        }

        try {
            $emailService = new EmailService($settings['smtp']);
            $success = $emailService->send(
                $data['to'], 
                $data['subject'], 
                $data['body'], 
                $data['cc'] ?? '', 
                $data['attachment'] ?? '', 
                "Receipt_{$payment['payment_no']}.pdf",
                $clientId
            );

            if ($success) {
                echo json_encode(['status' => 'success', 'message' => 'Receipt sent successfully']);
            } else {
                echo json_encode(['status' => 'error', 'message' => 'Failed to send email']);
            }
        } catch (\Exception $e) {
            http_response_code(500); echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
        }
    }

    public function delete() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        if (!PermissionHelper::check('payments', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $payment = $this->repository->findOne('payments', ['id' => $data['id']]);
        if ($payment && !PermissionHelper::canAccessRecord($payment, 'payments', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Not your record']); exit;
        }

        $invoiceId = $payment['invoice_id'] ?? null;
        $success = $this->repository->deleteOne('payments', ['id' => $data['id']]);

        if ($success && $invoiceId) {
            $this->syncInvoiceStatus($invoiceId);
        }

        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    private function syncInvoiceStatus($invoiceId) {
        $invoice = $this->repository->findOne('invoices', ['id' => $invoiceId]);
        if (!$invoice) return;

        $allPayments = $this->repository->findAll('payments');
        $totalPaid = 0;
        foreach ($allPayments as $p) {
            if ($p['invoice_id'] === $invoiceId) {
                $totalPaid += floatval($p['amount']);
            }
        }

        $newStatus = 'Overdue'; // Default if no payments left
        if ($totalPaid > 0) {
            $newStatus = ($totalPaid >= floatval($invoice['amount']) - 0.01) ? 'Paid' : 'Partial Paid';
        }
        
        $this->repository->updateOne('invoices', ['id' => $invoiceId], ['status' => $newStatus]);
    }
}
