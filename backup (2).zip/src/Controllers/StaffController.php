<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class StaffController {
    private $repository;
    private $collection = 'users';

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        if (!PermissionHelper::check('staff', 'view')) {
            http_response_code(403); echo "Access Denied"; exit;
        }

        $trash = ($_GET['trash'] ?? '') === '1';
        $staff = $this->repository->findAll($this->collection, [], ['includeDeleted' => $trash]);
        $roles = $this->repository->findAll('roles');
        
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);

        if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
            header('Content-Type: application/json');
            echo json_encode(['staff' => array_values($staff)]);
            exit;
        }

        require_once __DIR__ . '/../../views/staff.php';
    }

    public function restore() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('staff', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->restore($this->collection, ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function store() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('staff', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['username']) || empty($data['role_id'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Missing data']); exit;
        }

        // Check if username already exists
        $existingUser = $this->repository->findOne($this->collection, ['username' => $data['username']]);
        if ($existingUser && (empty($data['id']) || $existingUser['id'] !== $data['id'])) {
             echo json_encode(['status' => 'error', 'message' => 'Username already exists']); exit;
        }

        if (empty($data['id'])) {
            $data['id'] = uniqid('u');
            $data['password'] = password_hash($data['password'] ?? 'staff123', PASSWORD_DEFAULT);
            $this->repository->insertOne($this->collection, $data);
        } else {
            // Don't overwrite password if not provided
            if (empty($data['password'])) {
                unset($data['password']);
            } else {
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            $this->repository->updateOne($this->collection, ['id' => $data['id']], $data);
        }

        echo json_encode(['status' => 'success', 'message' => 'Staff member saved']);
    }

    public function delete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('staff', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        // Prevent self-deletion
        if ($data['id'] === $_SESSION['user_id']) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Cannot delete yourself']); exit;
        }

        $success = $this->repository->deleteOne('users', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }
}
