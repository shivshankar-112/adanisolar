<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;

class SearchController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function query() {
        header('Content-Type: application/json');
        $q = strtolower($_GET['q'] ?? '');
        if (strlen($q) < 2) {
            echo json_encode(['results' => []]);
            return;
        }

        $results = [];

        // Search Clients
        $clients = $this->repository->findAll('clients');
        foreach ($clients as $c) {
            if (strpos(strtolower($c['client_name'] ?? ''), $q) !== false || 
                strpos(strtolower($c['email'] ?? ''), $q) !== false ||
                strpos(strtolower($c['phone'] ?? ''), $q) !== false) {
                $results[] = [
                    'type' => 'Client',
                    'title' => $c['client_name'],
                    'subtitle' => ($c['email'] ?? '') . ' | ' . ($c['phone'] ?? ''),
                    'url' => '/clients?id=' . ($c['id'] ?? '')
                ];
            }
        }

        // Search Invoices
        $invoices = $this->repository->findAll('invoices');
        foreach ($invoices as $i) {
            if (strpos(strtolower($i['invoice_no'] ?? ''), $q) !== false || 
                strpos(strtolower($i['client_name'] ?? ''), $q) !== false) {
                $results[] = [
                    'type' => 'Invoice',
                    'title' => $i['invoice_no'],
                    'subtitle' => ($i['client_name'] ?? '') . ' - ₹' . ($i['total'] ?? 0),
                    'url' => '/invoices?id=' . ($i['id'] ?? '')
                ];
            }
        }

        // Search Approvals
        $approvals = $this->repository->findAll('approvals');
        foreach ($approvals as $p) {
            if (strpos(strtolower($p['approval_no'] ?? ''), $q) !== false || 
                strpos(strtolower($p['client_name'] ?? ''), $q) !== false) {
                $results[] = [
                    'type' => 'Approval',
                    'title' => $p['approval_no'],
                    'subtitle' => ($p['client_name'] ?? '') . ' - ' . ($p['service'] ?? ''),
                    'url' => '/approvals?id=' . ($p['id'] ?? '')
                ];
            }
        }
        
        // Search Enquiries
        $enquiries = $this->repository->findAll('enquiries');
        foreach ($enquiries as $e) {
            if (strpos(strtolower($e['client_name'] ?? ''), $q) !== false || 
                strpos(strtolower($e['email'] ?? ''), $q) !== false) {
                $results[] = [
                    'type' => 'Enquiry',
                    'title' => $e['client_name'] ?? 'New Enquiry',
                    'subtitle' => ($e['email'] ?? '') . ' - ' . ($e['service'] ?? ''),
                    'url' => '/enquiries?id=' . ($e['id'] ?? '')
                ];
            }
        }

        echo json_encode(['results' => array_slice($results, 0, 10)]);
    }
}
