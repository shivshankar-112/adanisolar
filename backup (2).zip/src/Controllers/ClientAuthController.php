<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;

class ClientAuthController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function showLogin() {
        if (isset($_SESSION['client_id'])) {
            header('Location: ' . url('/portal/dashboard'));
            exit;
        }
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        require_once __DIR__ . '/../../views/client_login.php';
    }

    public function login() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['email']) || empty($data['password'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Email and password required']);
            return;
        }

        $client = $this->repository->findOne('clients', ['email' => $data['email']]);

        if ($client && isset($client['password']) && password_verify($data['password'], $client['password'])) {
            $_SESSION['client_id'] = $client['id'];
            $_SESSION['client_name'] = $client['client_name'];
            $_SESSION['client_email'] = $client['email'];
            $_SESSION['client_last_activity'] = time();

            if (!empty($data['remember'])) {
                $token = bin2hex(random_bytes(32));
                setcookie('client_remember_me', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true); // 30 days
                
                // Save token to client
                $this->repository->updateOne('clients', ['id' => $client['id']], ['remember_token' => $token]);
            }
            
            echo json_encode(['status' => 'success', 'message' => 'Login successful']);
        } else {
            http_response_code(401);
            echo json_encode(['status' => 'error', 'message' => 'Invalid credentials']);
        }
    }

    public function logout() {
        if (isset($_SESSION['client_id'])) {
            $this->repository->updateOne('clients', ['id' => $_SESSION['client_id']], ['remember_token' => null]);
        }
        setcookie('client_remember_me', '', time() - 3600, '/');
        unset($_SESSION['client_id']);
        unset($_SESSION['client_name']);
        unset($_SESSION['client_email']);
        unset($_SESSION['client_last_activity']);
        header('Location: ' . url('/login'));
        exit;
    }
}
