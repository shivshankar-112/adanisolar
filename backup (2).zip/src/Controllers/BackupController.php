<?php

namespace App\Controllers;

use App\Services\PermissionHelper;
use ZipArchive;

class BackupController {
    public function download() {
        if (!PermissionHelper::check('settings', 'view')) {
            http_response_code(403); die("Access Denied");
        }

        if (!class_exists('ZipArchive')) {
            die("ZipArchive extension is not enabled in your PHP installation.");
        }

        $dbPath = __DIR__ . '/../../storage/db';
        $zipFile = sys_get_temp_dir() . '/crm_backup_' . date('Y-m-d_H-i-s') . '.zip';

        $zip = new ZipArchive();
        if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            die("Could not create zip");
        }

        $files = scandir($dbPath);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $zip->addFile($dbPath . '/' . $file, $file);
        }

        $zip->close();

        if (!file_exists($zipFile)) {
            die("Zip file was not created.");
        }

        // Log the backup action
        \App\Services\AuditLogger::getInstance()->log('backup_download', 'system', null, null, ['filename' => basename($zipFile)]);

        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . basename($zipFile) . '"');
        header('Content-Length: ' . filesize($zipFile));
        header('Pragma: no-cache');
        header('Expires: 0');
        
        readfile($zipFile);
        unlink($zipFile);
        exit;
    }
}
