<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class RoleController {
    private $repository;
    private $collection = 'roles';

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        if (!PermissionHelper::check('roles', 'view')) {
            http_response_code(403); echo "Access Denied"; exit;
        }

        $roles = $this->repository->findAll($this->collection);
        $modules = ['enquiries', 'approvals', 'invoices', 'payments', 'staff', 'roles', 'settings'];
        
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);

        require_once __DIR__ . '/../../views/roles.php';
    }

    public function store() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('roles', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['name'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Name required']); exit;
        }

        // Check if role name already exists
        $existingRole = $this->repository->findOne($this->collection, ['name' => $data['name']]);
        if ($existingRole && (empty($data['id']) || $existingRole['id'] !== $data['id'])) {
             echo json_encode(['status' => 'error', 'message' => 'Role name already exists']); exit;
        }

        if (empty($data['id'])) {
            $data['id'] = uniqid('r');
            $this->repository->insertOne($this->collection, $data);
        } else {
            $this->repository->updateOne($this->collection, ['id' => $data['id']], $data);
        }

        echo json_encode(['status' => 'success', 'message' => 'Role saved']);
    }

    public function delete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('roles', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        // Prevent deletion of 'admin' role (hardcoded safeguard for root admin)
        if ($data['id'] === 'admin') {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Cannot delete Admin role']); exit;
        }

        $success = $this->repository->deleteOne($this->collection, ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }
}
