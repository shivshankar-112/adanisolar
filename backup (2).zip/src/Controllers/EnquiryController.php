<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\EmailService;

use App\Services\PermissionHelper;

class EnquiryController {
    private $repository;
    private $dbPath;

    public function __construct() {
        $this->dbPath = __DIR__ . '/../../storage/db';
        $this->repository = new JsonNoSqlRepository($this->dbPath);
    }

    public function index() {
        $page = (int)($_GET['page'] ?? 1);
        $perPage = 25;
        $offset = ($page - 1) * $perPage;
        
        $search = $_GET['q'] ?? '';
        $status = $_GET['status'] ?? '';
        $staff = $_GET['staff'] ?? '';
        $trash = ($_GET['trash'] ?? '') === '1';

        $criteria = [];
        if ($status) $criteria['status'] = $status;
        if ($staff) $criteria['assigned_to'] = $staff;

        $options = [
            'sort' => ['key' => 'created_at', 'order' => 'desc'],
            'limit' => $perPage,
            'offset' => $offset,
            'includeDeleted' => $trash
        ];

        // Search is handled a bit differently in our NoSQL repo
        // For now, we fetch more and filter if search is present, 
        // but real production would index this.
        
        if ($search) {
            // Fetch all and filter (legacy behavior, but limited by search)
            $all = $this->repository->findAll('enquiries', $criteria, ['includeDeleted' => $trash]);
            $enquiries = array_filter($all, function($e) use ($search) {
                return strpos(strtolower($e['client_name'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($e['email'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($e['enquiry_no'] ?? ''), strtolower($search)) !== false;
            });
            $totalEnquiries = count($enquiries);
            $enquiries = array_slice($enquiries, $offset, $perPage);
        } else {
            $totalEnquiries = $this->repository->count('enquiries', $criteria, $trash);
            $enquiries = $this->repository->findAll('enquiries', $criteria, $options);
        }

        $enquiries = PermissionHelper::filterByOwnership($enquiries, 'enquiries', 'view');

        if (!PermissionHelper::check('enquiries', 'view') && empty($enquiries)) {
            if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
                http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
            }
            http_response_code(403); echo "Access Denied"; exit;
        }
        
        if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
            header('Content-Type: application/json');
            echo json_encode(['enquiries' => array_values($enquiries), 'total' => $totalEnquiries]);
            exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        $staffMembers = $this->repository->findAll('users');
        $roles = $this->repository->findAll('roles');
        $clients = $this->repository->findAll('clients');

        $pagination = [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $totalEnquiries,
            'total_pages' => ceil($totalEnquiries / $perPage)
        ];

        require_once __DIR__ . '/../../views/enquiries.php';
    }

    public function restore() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->restore('enquiries', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function update() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        // Ownership check
        $enquiry = $this->repository->findOne('enquiries', ['id' => $data['id']]);
        if (!$enquiry || !PermissionHelper::canAccessRecord($enquiry, 'enquiries', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Cannot edit this record']); exit;
        }

        // Unlink old photo if replaced
        if (!empty($enquiry['client_photo']) && !empty($data['client_photo']) && $enquiry['client_photo'] !== $data['client_photo']) {
            $oldPath = __DIR__ . '/../../public' . $enquiry['client_photo'];
            if (file_exists($oldPath)) unlink($oldPath);
        }

        // Validation
        $errors = $this->validateData($data);
        if (!empty($errors)) {
            echo json_encode(['status' => 'error', 'errors' => $errors]);
            return;
        }

        $success = $this->repository->updateOne('enquiries', ['id' => $data['id']], $data);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function validate() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        $field = $data['field'] ?? '';
        $value = $data['value'] ?? '';

        $errors = $this->validateData([$field => $value], $field);
        echo json_encode(['status' => empty($errors) ? 'success' : 'error', 'errors' => $errors]);
    }

    private function validateData($data, $specificField = null) {
        $errors = [];

        $rules = [
            'pan' => [
                'regex' => '/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', 
                'message' => 'Invalid PAN format. Must be 10 characters (e.g., ABCDE1234F).'
            ],
            'aadhar' => [
                'regex' => '/^[2-9]{1}[0-9]{11}$/', 
                'message' => 'Invalid Aadhar. Must be 12 digits and cannot start with 0 or 1.'
            ],
            'gst' => [
                'regex' => '/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', 
                'message' => 'Invalid GST format. Must be 15 characters (e.g., 22ABCDE1234F1Z5).'
            ],
            'client_photo' => [
                'regex' => '/^\/uploads\/[a-zA-Z0-9\-_\.]+$/', 
                'message' => 'Invalid client photo path. Must be a valid uploads path.'
            ]
        ];

        foreach ($rules as $field => $rule) {
            if ($specificField && $specificField !== $field) continue;
            if (!empty($data[$field])) {
                if (!preg_match($rule['regex'], $data[$field])) {
                    $errors[$field] = $rule['message'];
                }
            }
        }

        if (!$specificField || $specificField === 'email') {
            if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = 'Invalid email address';
            }
        }

        return $errors;
    }

    public function uploadPhoto() {
        header('Content-Type: application/json');
        if (!isset($_FILES['photo'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'No file uploaded']); exit;
        }

        $file = $_FILES['photo'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid file type']); exit;
        }

        $newName = 'client_' . uniqid() . '.' . $ext;
        $targetPath = __DIR__ . '/../../uploads/' . $newName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            echo json_encode(['status' => 'success', 'url' => '/uploads/' . $newName]);
        } else {
            http_response_code(500); echo json_encode(['status' => 'error', 'message' => 'Failed to save photo']);
        }
    }

    public function bulkUpdate() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids']) || empty($data['updates'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            $enquiry = $this->repository->findOne('enquiries', ['id' => $id]);
            if ($enquiry && PermissionHelper::canAccessRecord($enquiry, 'enquiries', 'edit')) {
                if ($this->repository->updateOne('enquiries', ['id' => $id], $data['updates'])) {
                    $successCount++;
                }
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function bulkDelete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            $enquiry = $this->repository->findOne('enquiries', ['id' => $id]);
            if ($enquiry && PermissionHelper::canAccessRecord($enquiry, 'enquiries', 'delete')) {
                if ($this->repository->deleteOne('enquiries', ['id' => $id])) {
                    $successCount++;
                }
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function store() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }
        
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['client_name']) || empty($data['email'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        // Validation
        $errors = $this->validateData($data);
        if (!empty($errors)) {
            echo json_encode(['status' => 'error', 'errors' => $errors]);
            return;
        }

        // Get Org Settings for numbering and email
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        // Generate Enquiry Number
        $format = $settings['enquiry_format'];
        if ($format['type'] === 'sequential') {
            $enquiryNo = $format['prefix'] . $format['start'];
            // Increment for next time
            $settings['enquiry_format']['start']++;
            $this->repository->updateOne('organization', ['id' => 'org_settings'], $settings);
        } else {
            $enquiryNo = $format['prefix'] . rand(10000, 99999);
        }

        $enquiry = [
            'id' => uniqid(),
            'enquiry_no' => $enquiryNo,
            'client_name' => $data['client_name'],
            'email' => $data['email'],
            'phone' => $data['phone'] ?? '',
            'pan' => $data['pan'] ?? '',
            'aadhar' => $data['aadhar'] ?? '',
            'gst' => $data['gst'] ?? '',
            'client_photo' => $data['client_photo'] ?? '',
            'client_id' => $data['client_id'] ?? '',
            'message' => $data['message'] ?? '',
            'service' => $data['service'] ?? '',
            'budget' => $data['budget'] ?? '',
            'address' => $data['address'] ?? '',
            'state' => $data['state'] ?? '',
            'status' => 'New',
            'assigned_to' => $data['assigned_to'] ?? '',
            'created_by' => $_SESSION['user_id'],
            'created_at' => date('Y-m-d H:i:s')
        ];

        $success = $this->repository->insertOne('enquiries', $enquiry);

        if ($success) {
            \App\Services\NotificationService::getInstance()->notifyAdmins(
                'New Enquiry', 
                "New enquiry from {$enquiry['client_name']} for {$enquiry['service']}",
                'info',
                '/enquiries'
            );
        }

        // Send Email Template
        $tpl = null;
        foreach ($settings['templates'] as $t) {
            if ($t['id'] === 'enquiry_received') {
                $tpl = $t;
                break;
            }
        }

        if ($tpl) {
            $emailService = new EmailService($settings['smtp']);
            $body = $emailService->renderTemplate($tpl['body'], [
                'name' => $enquiry['client_name'],
                'enquiry_no' => $enquiry['enquiry_no']
            ]);
            $emailService->send($enquiry['email'], $tpl['subject'], $body, '', '', 'document.pdf', $enquiry['client_id'] ?? null);
        }

        echo json_encode(['status' => 'success', 'message' => 'Enquiry recorded', 'enquiry_no' => $enquiryNo]);
    }

    public function delete() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        // Check Permission
        if (!PermissionHelper::check('enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        // Check Ownership if scope is "own"
        $enquiry = $this->repository->findOne('enquiries', ['id' => $data['id']]);
        if ($enquiry && !PermissionHelper::canAccessRecord($enquiry, 'enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied: Not your record']); exit;
        }

        $success = $this->repository->deleteOne('enquiries', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }
}
