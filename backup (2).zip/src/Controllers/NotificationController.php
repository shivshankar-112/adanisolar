<?php

namespace App\Controllers;

use App\Services\NotificationService;

class NotificationController {
    public function index() {
        header('Content-Type: application/json');
        $userId = $_SESSION['user_id'] ?? 'system';
        $notifications = NotificationService::getInstance()->getNotifications($userId);
        $unreadCount = NotificationService::getInstance()->getUnreadCount($userId);
        echo json_encode(['notifications' => array_values($notifications), 'unread_count' => $unreadCount]);
    }

    public function markRead() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['id'])) {
            NotificationService::getInstance()->markAsRead($data['id']);
        }
        echo json_encode(['status' => 'success']);
    }
}
