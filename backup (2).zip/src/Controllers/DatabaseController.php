<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class DatabaseController {
    private $repository;
    private $dbPath;

    public function __construct() {
        $this->dbPath = __DIR__ . '/../../storage/db';
        $this->repository = new JsonNoSqlRepository($this->dbPath);
    }

    public function cleanCollection() {
        header('Content-Type: application/json');
        
        // Strictly only admin role (r1) or global settings edit permission
        if ($_SESSION['role_id'] !== 'r1' && !PermissionHelper::check('settings', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        $collections = $data['collections'] ?? [];

        if (empty($collections)) {
            echo json_encode(['status' => 'error', 'message' => 'No collections selected']); exit;
        }

        $validCollections = ['enquiries', 'approvals', 'invoices', 'payments', 'audit_logs', 'email_logs', 'clients'];
        $cleaned = [];
        $uploadDir = __DIR__ . '/../../uploads';

        foreach ($collections as $col) {
            if (in_array($col, $validCollections)) {
                $filePath = "{$this->dbPath}/{$col}.json";
                if (file_exists($filePath)) {
                    file_put_contents($filePath, json_encode([], JSON_PRETTY_PRINT));
                    $cleaned[] = $col;

                    // Unlink module-specific images
                    if (is_dir($uploadDir)) {
                        $files = glob("{$uploadDir}/*");
                        foreach ($files as $file) {
                            $filename = basename($file);
                            // If cleaning clients, remove client_* photos
                            if ($col === 'clients' && strpos($filename, 'client_') === 0) unlink($file);
                            // If cleaning enquiries, remove client_* photos (shared prefix often)
                            if ($col === 'enquiries' && strpos($filename, 'client_') === 0) unlink($file);
                            // Logo/Assets belong to organization, but if org is ever cleaned (not in list yet)
                        }
                    }

                    \App\Services\AuditLogger::getInstance()->log('cleanup', 'database', $col, null, ['action' => 'wipe']);
                }
            }
        }

        echo json_encode(['status' => 'success', 'message' => 'Cleaned collections: ' . implode(', ', $cleaned)]);
    }

    public function clearLogs() {
        header('Content-Type: application/json');
        
        if ($_SESSION['role_id'] !== 'r1' && !PermissionHelper::check('settings', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $type = $_GET['type'] ?? 'audit';
        $collection = ($type === 'email') ? 'email_logs' : 'audit_logs';
        
        $filePath = "{$this->dbPath}/{$collection}.json";
        if (file_exists($filePath)) {
            file_put_contents($filePath, json_encode([], JSON_PRETTY_PRINT));
            \App\Services\AuditLogger::getInstance()->log('cleanup', $collection, 'all', null, ['action' => 'clear']);
            echo json_encode(['status' => 'success', 'message' => 'Logs cleared successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Log file not found']);
        }
    }
}
