<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\EmailService;

class ExternalEnquiryController {
    private $repository;
    private $dbPath;

    public function __construct() {
        $this->dbPath = __DIR__ . '/../../storage/db';
        $this->repository = new JsonNoSqlRepository($this->dbPath);
    }

    private function handleCORS() {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: POST, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type');
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            exit;
        }
    }

    public function store() {
        $this->handleCORS();
        header('Content-Type: application/json');

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['client_name']) || empty($data['email'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Name and Email are required']);
            return;
        }

        // Get Org Settings
        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']);
        
        // Generate Enquiry Number
        $format = $settings['enquiry_format'] ?? ['type' => 'random', 'prefix' => 'ENQ-'];
        if (($format['type'] ?? '') === 'sequential') {
            $enquiryNo = $format['prefix'] . $format['start'];
            $settings['enquiry_format']['start']++;
            $this->repository->updateOne('organization', ['id' => 'org_settings'], $settings);
        } else {
            $enquiryNo = ($format['prefix'] ?? 'ENQ-') . rand(10000, 99999);
        }

        $enquiry = [
            'id' => uniqid(),
            'enquiry_no' => $enquiryNo,
            'client_name' => $data['client_name'],
            'email' => $data['email'],
            'phone' => $data['phone'] ?? '',
            'message' => $data['message'] ?? '',
            'service' => $data['service'] ?? 'External Lead',
            'budget' => $data['budget'] ?? '',
            'address' => $data['address'] ?? '',
            'state' => $data['state'] ?? '',
            'status' => 'New',
            'assigned_to' => '', // Unassigned initially
            'created_by' => 'system',
            'created_at' => date('Y-m-d H:i:s'),
            'source' => $data['source'] ?? $_SERVER['HTTP_REFERER'] ?? 'Unknown'
        ];

        $success = $this->repository->insertOne('enquiries', $enquiry);

        if ($success) {
            \App\Services\NotificationService::getInstance()->notifyAdmins(
                'External Enquiry', 
                "New lead from {$enquiry['client_name']} via Web Form",
                'info',
                '/enquiries'
            );

            // Send Confirmation Email if template exists
            $tpl = null;
            foreach (($settings['templates'] ?? []) as $t) {
                if ($t['id'] === 'enquiry_received') {
                    $tpl = $t;
                    break;
                }
            }

            if ($tpl && !empty($settings['smtp']['host'])) {
                try {
                    $emailService = new EmailService($settings['smtp']);
                    $body = $emailService->renderTemplate($tpl['body'], [
                        'name' => $enquiry['client_name'],
                        'enquiry_no' => $enquiry['enquiry_no']
                    ]);
                    $emailService->send($enquiry['email'], $tpl['subject'], $body);
                } catch (\Exception $e) {
                    // Log error but don't fail the API response
                }
            }
        }

        echo json_encode([
            'status' => $success ? 'success' : 'error',
            'message' => $success ? 'Thank you! Your enquiry has been received.' : 'Failed to save enquiry',
            'enquiry_no' => $enquiryNo
        ]);
    }
}
