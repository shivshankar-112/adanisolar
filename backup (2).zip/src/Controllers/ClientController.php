<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class ClientController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        if (!PermissionHelper::check('enquiries', 'view')) { // reusing enquiries permission for simplicity
            http_response_code(403); die("Access Denied");
        }

        $page = (int)($_GET['page'] ?? 1);
        $perPage = 25;
        $offset = ($page - 1) * $perPage;
        
        $search = $_GET['q'] ?? '';
        $trash = ($_GET['trash'] ?? '') === '1';

        $criteria = [];
        $options = [
            'sort' => ['key' => 'client_name', 'order' => 'asc'],
            'limit' => $perPage,
            'offset' => $offset,
            'includeDeleted' => $trash
        ];

        if ($search) {
            $all = $this->repository->findAll('clients', $criteria, ['includeDeleted' => $trash]);
            $clients = array_filter($all, function($c) use ($search) {
                return strpos(strtolower($c['client_name'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($c['email'] ?? ''), strtolower($search)) !== false ||
                       strpos(strtolower($c['phone'] ?? ''), strtolower($search)) !== false;
            });
            $totalClients = count($clients);
            $clients = array_slice($clients, $offset, $perPage);
        } else {
            $totalClients = $this->repository->count('clients', $criteria, $trash);
            $clients = $this->repository->findAll('clients', $criteria, $options);
        }

        if (strpos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false) {
            header('Content-Type: application/json');
            echo json_encode(['clients' => array_values($clients), 'total' => $totalClients]);
            exit;
        }

        $settings = $this->repository->findOne('organization', ['id' => 'org_settings']) ?: [];
        $pagination = [
            'current_page' => $page,
            'per_page' => $perPage,
            'total' => $totalClients,
            'total_pages' => ceil($totalClients / $perPage)
        ];

        require __DIR__ . '/../../views/clients.php';
    }

    public function restore() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->restore('clients', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function store() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['client_name']) || empty($data['email'])) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        // Validation
        $errors = $this->validateData($data);
        if (!empty($errors)) {
            echo json_encode(['status' => 'error', 'errors' => $errors]);
            return;
        }

        if (empty($data['id'])) {
            $data['id'] = 'cli_' . uniqid();
            $data['created_at'] = date('Y-m-d H:i:s');
            
            // Set default password to a strong random password if not provided
            if (empty($data['password'])) {
                // Generate a strong random password (12 characters: uppercase, lowercase, numbers, special chars)
                $length = 12;
                $charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
                $password = '';
                for ($i = 0; $i < $length; $i++) {
                    $password .= $charset[random_int(0, strlen($charset) - 1)];
                }
                $data['password'] = password_hash($password, PASSWORD_DEFAULT);
                
                // Store the plain password temporarily to return it (in a real app, you'd email this)
                // For security, we won't return it in the response, but you could implement email notification
                $data['plain_password'] = $password; // For internal use only, not to be stored
            } else {
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            }
            
            // Remove temporary plain_password field before saving
            unset($data['plain_password']);
            
            $success = $this->repository->insertOne('clients', $data);
        } else {
            $existing = $this->repository->findOne('clients', ['id' => $data['id']]);
            // Unlink old photo if replaced
            if ($existing && !empty($existing['client_photo']) && !empty($data['client_photo']) && $existing['client_photo'] !== $data['client_photo']) {
                $oldPath = __DIR__ . '/../../public' . $existing['client_photo'];
                if (file_exists($oldPath)) unlink($oldPath);
            }

            if (!empty($data['password'])) {
                $data['password'] = password_hash($data['password'], PASSWORD_DEFAULT);
            } else {
                // Remove password from update if empty to avoid overwriting with null/empty
                unset($data['password']);
            }
            $success = $this->repository->updateOne('clients', ['id' => $data['id']], $data);
        }

        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function validate() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);
        $field = $data['field'] ?? '';
        $value = $data['value'] ?? '';

        $errors = $this->validateData([$field => $value], $field);
        echo json_encode(['status' => empty($errors) ? 'success' : 'error', 'errors' => $errors]);
    }

    private function validateData($data, $specificField = null) {
        $errors = [];

        $rules = [
            'pan' => [
                'regex' => '/^[A-Z]{5}[0-9]{4}[A-Z]{1}$/', 
                'message' => 'Invalid PAN format. Must be 10 characters (e.g., ABCDE1234F).'
            ],
            'aadhar' => [
                'regex' => '/^[2-9]{1}[0-9]{11}$/', 
                'message' => 'Invalid Aadhar. Must be 12 digits and cannot start with 0 or 1.'
            ],
            'gst' => [
                'regex' => '/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/', 
                'message' => 'Invalid GST format. Must be 15 characters (e.g., 22ABCDE1234F1Z5).'
            ],
            'client_photo' => [
                'regex' => '/^\/uploads\/[a-zA-Z0-9\-_\.]+$/',
                'message' => 'Invalid client photo path. Must be a valid uploads path.'
            ],
            'latitude' => [
                'regex' => '/^-?([0-8]?[0-9]\.[0-9]+|90(\.0+)?)$/',
                'message' => 'Invalid latitude. Must be between -90 and 90.'
            ],
            'longitude' => [
                'regex' => '/^-?(([0-1]?[0-9]?[0-9]\.[0-9]+)|180(\.0+)?)$/',
                'message' => 'Invalid longitude. Must be between -180 and 180.'
            ]
        ];

        foreach ($rules as $field => $rule) {
            if ($specificField && $specificField !== $field) continue;
            if (!empty($data[$field])) {
                if (!preg_match($rule['regex'], $data[$field])) {
                    $errors[$field] = $rule['message'];
                }
            }
        }

        if (!$specificField || $specificField === 'email') {
            if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                $errors['email'] = 'Invalid email address';
            }
        }

        return $errors;
    }

    public function convert() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data || empty($data['enquiry_id'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid data']); exit;
        }

        $enquiry = $this->repository->findOne('enquiries', ['id' => $data['enquiry_id']]);
        
        if (!$enquiry) {
            http_response_code(404); echo json_encode(['status' => 'error', 'message' => 'Enquiry not found']); exit;
        }

        if (!empty($enquiry['client_id'])) {
            echo json_encode(['status' => 'error', 'message' => 'Already converted']); exit;
        }

        $clientId = 'cli_' . uniqid();
        $clientData = [
            'id' => $clientId,
            'client_name' => $enquiry['client_name'] ?? '',
            'email' => $enquiry['email'] ?? '',
            'phone' => $enquiry['phone'] ?? '',
            'address' => $enquiry['address'] ?? '',
            'state' => $enquiry['state'] ?? '',
            'pan' => $enquiry['pan'] ?? '',
            'aadhar' => $enquiry['aadhar'] ?? '',
            'gst' => $enquiry['gst'] ?? '',
            'client_photo' => $enquiry['client_photo'] ?? '',
            'created_at' => date('Y-m-d H:i:s')
        ];

        // Set default portal password to a strong random password
        if (!empty($clientData['phone'])) {
            // Generate a strong random password (12 characters: uppercase, lowercase, numbers, special chars)
            $length = 12;
            $charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()';
            $password = '';
            for ($i = 0; $i < $length; $i++) {
                $password .= $charset[random_int(0, strlen($charset) - 1)];
            }
            $clientData['password'] = password_hash($password, PASSWORD_DEFAULT);
            
            // Store the plain password temporarily (in a real app, you'd email this to the user)
            $clientData['plain_password'] = $password; // For internal use only
        }
        
        // Remove temporary plain_password field before saving
        unset($clientData['plain_password']);
        
        $this->repository->insertOne('clients', $clientData);

        // Update Enquiry
        $this->repository->updateOne('enquiries', ['id' => $enquiry['id']], [
            'client_id' => $clientId,
            'status' => 'Converted'
        ]);

        echo json_encode(['status' => 'success', 'client_id' => $clientId]);
    }

    public function bulkDelete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['ids'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $successCount = 0;
        foreach ($data['ids'] as $id) {
            if ($this->repository->deleteOne('clients', ['id' => $id])) {
                $successCount++;
            }
        }

        echo json_encode(['status' => 'success', 'count' => $successCount]);
    }

    public function delete() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('enquiries', 'delete')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = json_decode(file_get_contents('php://input'), true);
        if (!$data || empty($data['id'])) {
            http_response_code(400); echo json_encode(['status' => 'error']); exit;
        }

        $success = $this->repository->deleteOne('clients', ['id' => $data['id']]);
        echo json_encode(['status' => $success ? 'success' : 'error']);
    }

    public function uploadPhoto() {
        header('Content-Type: application/json');
        if (!isset($_FILES['photo'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'No file uploaded']); exit;
        }

        $file = $_FILES['photo'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'Invalid file type']); exit;
        }

        $newName = 'client_' . uniqid() . '.' . $ext;
        $targetPath = __DIR__ . '/../../uploads/' . $newName;

        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            echo json_encode(['status' => 'success', 'url' => '/uploads/' . $newName]);
        } else {
            http_response_code(500); echo json_encode(['status' => 'error', 'message' => 'Failed to save photo']);
        }
    }
}