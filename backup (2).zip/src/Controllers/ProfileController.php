<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\AuditLogger;

class ProfileController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        $user = $this->repository->findOne('users', ['id' => $_SESSION['user_id']]);
        require_once __DIR__ . '/../../views/profile.php';
    }

    public function update() {
        header('Content-Type: application/json');
        $data = json_decode(file_get_contents('php://input'), true);

        if (!$data) {
            http_response_code(400);
            echo json_encode(['status' => 'error', 'message' => 'Invalid data']);
            return;
        }

        $userId = $_SESSION['user_id'];
        $user = $this->repository->findOne('users', ['id' => $userId]);

        $updateData = [
            'name' => $data['name'] ?? $user['name'],
            'email' => $data['email'] ?? $user['email']
        ];

        if (!empty($data['new_password'])) {
            if (empty($data['current_password']) || !password_verify($data['current_password'], $user['password'])) {
                http_response_code(400);
                echo json_encode(['status' => 'error', 'message' => 'Current password incorrect']);
                return;
            }
            $updateData['password'] = password_hash($data['new_password'], PASSWORD_DEFAULT);
        }

        $success = $this->repository->updateOne('users', ['id' => $userId], $updateData);

        if ($success) {
            $_SESSION['name'] = $updateData['name'];
            AuditLogger::getInstance()->log('profile_update', 'users', $userId);
            echo json_encode(['status' => 'success', 'message' => 'Profile updated successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update profile']);
        }
    }
}
