<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class AuditLogController {
    private $repository;

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        if (!PermissionHelper::check('settings', 'view')) {
            http_response_code(403); die("Access Denied");
        }

        $logs = $this->repository->findAll('audit_logs');
        
        // Sort by timestamp descending
        usort($logs, function($a, $b) {
            return strcmp($b['timestamp'], $a['timestamp']);
        });

        // Limit to last 500 logs for performance
        $logs = array_slice($logs, 0, 500);

        header('Content-Type: application/json');
        echo json_encode(['logs' => $logs]);
    }
}
