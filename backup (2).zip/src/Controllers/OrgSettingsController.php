<?php

namespace App\Controllers;

use App\Repositories\JsonNoSqlRepository;
use App\Services\PermissionHelper;

class OrgSettingsController {
    private $repository;
    private $collection = 'organization';

    public function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function index() {
        if (!PermissionHelper::check('settings', 'view')) {
            http_response_code(403); echo "Access Denied"; exit;
        }

        $settings = $this->repository->findOne($this->collection, ['id' => 'org_settings']);
        
        $defaults = [
            'id' => 'org_settings',
            'org_name' => 'My Simple CRM',
            'website_url' => 'https://example.com',
            'email' => 'info@example.com',
            'phone' => '1234567890',
            'logo_url' => '',
            'enquiry_format' => ['prefix' => 'ENQ-', 'start' => 1001, 'type' => 'sequential'],
            'approval_format' => ['prefix' => 'PROP-', 'start' => 2001, 'type' => 'sequential'],
            'invoice_format' => ['prefix' => 'INV-', 'start' => 3001, 'type' => 'sequential'],
            'payment_format' => ['prefix' => 'PAY-', 'start' => 4001, 'type' => 'sequential'],
            'smtp' => [
                'host' => '', 
                'port' => 587, 
                'user' => '', 
                'pass' => '', 
                'encryption' => 'tls',
                'from_email' => '',
                'from_name' => 'iAdmin CRM'
            ],
            'services' => [],
            'budgets' => [],
            'bank_accounts' => [],
            'approval_templates' => [
                [
                    'id' => 'tpl_industry_standard',
                    'name' => 'Industry Standard',
                    'content' => '<table style="width: 100%; border-bottom: 3px solid #1a73e8; padding-bottom: 20px; margin-bottom: 20px;"><tr><td style="width: 50%; vertical-align: top;"><h1 style="margin: 0; font-size: 24px; color: #1a73e8;">Approval: {{approval_no}}</h1><p style="margin: 5px 0 0 0; font-size: 14px; color: #666;">Date: {{date}}</p></td><td style="width: 50%; text-align: right; vertical-align: top;">{{org_logo}}<div style="margin-top: 10px; text-align: right;"><h3 style="margin: 0; font-size: 16px; font-weight: bold; color: #000;">{{org_name}}</h3><p style="margin: 3px 0; font-size: 13px; color: #444;">Phone: {{org_phone}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">Email: {{org_email}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">Website: {{org_website}}</p></div></td></tr></table><table style="width: 100%; margin-bottom: 20px;"><tr><td style="width: 50%; vertical-align: top; padding-right: 20px;"><h3 style="margin: 0 0 10px 0; font-size: 14px; color: #666; text-transform: uppercase;">Prepared For</h3><p style="margin: 0; font-size: 16px; font-weight: bold; color: #000;">{{client_name}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">{{email}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">{{phone}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">{{address}}, {{state}}</p></td></tr></table><h2 style="margin: 30px 0 10px 0; font-size: 18px; color: #1a73e8;">Subject: {{subject}}</h2><p style="margin: 0 0 20px 0; font-size: 14px;">Dear {{client_name}},</p><p style="margin: 0 0 20px 0; font-size: 14px;">We are pleased to present this approval for <strong>{{service}}</strong>.</p><h3 style="color: #1a73e8; font-size: 16px; margin: 20px 0 10px 0;">Scope of Services</h3><p style="margin: 0 0 20px 0; font-size: 14px;">Our comprehensive service offering includes:</p>{{items}}<h3 style="color: #1a73e8; font-size: 16px; margin: 20px 0 10px 0;">Investment</h3><p style="margin: 0 0 20px 0; font-size: 14px;">The total investment for this project is <strong style="color: #1a73e8;">₹{{amount}}</strong>.</p><div style="margin-top: 30px; padding: 20px; background: #f8f9fa; border-left: 4px solid #1a73e8;"><p style="margin: 0; font-size: 14px;">We appreciate the opportunity to work with you. Please feel free to contact us with any questions.</p></div><p style="margin-top: 20px; font-size: 14px;">Best regards,</p><p style="margin: 0; font-weight: bold;">{{org_name}}</p>',
                    'bg_graphic' => '',
                    'header_graphic' => '',
                    'footer_graphic' => '',
                    'stamp_sign' => ''
                ]
            ],
            'invoice_templates' => [
                [
                    'id' => 'tpl_invoice_standard',
                    'name' => 'Standard Invoice',
                    'content' => '<table style="width: 100%; border-bottom: 3px solid #1a73e8; padding-bottom: 20px; margin-bottom: 20px;"><tr><td style="width: 50%; vertical-align: top;"><p style="margin: 0; font-size: 14px; color: #666; text-transform: uppercase; font-weight: bold;">Bill To,</p><p style="margin: 5px 0 0 0; font-size: 18px; font-weight: bold; color: #000;">{{client_name}}</p><p style="margin: 2px 0 0 0; font-size: 14px; color: #444;">{{email}}</p><p style="margin: 2px 0 0 0; font-size: 14px; color: #444;">{{phone}}</p></td><td style="width: 50%; text-align: right; vertical-align: top;">{{org_logo}}<div style="margin-top: 10px; text-align: right;"><h3 style="margin: 0; font-size: 16px; font-weight: bold; color: #000;">{{org_name}}</h3><p style="margin: 3px 0; font-size: 13px; color: #444;">Phone: {{org_phone}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">Email: {{org_email}}</p><p style="margin: 3px 0; font-size: 13px; color: #444;">Website: {{org_website}}</p></div></td></tr></table><h1 style="text-align: center; color: #1a73e8; margin-top: 30px; margin-bottom: 10px;">Invoice</h1><p style="text-align: center; font-size: 16px; font-weight: bold; color: #444; margin-bottom: 40px;">Subject: {{subject}}</p><div>{{items}}</div><div style="margin-top: 30px; padding-top: 20px; border-top: 2px solid #1a73e8; text-align: right;"><p style="font-size: 18px; font-weight: bold;">Total Amount: <span style="color: #1a73e8;">₹{{amount}}</span></p></div><div style="margin-top: 40px; padding: 20px; background: #f8f9fa;"><p style="margin: 0 0 10px 0; font-size: 14px;">Thank you for your business!</p><div style="margin-top: 20px;"><p style="margin: 0; font-weight: bold;">{{org_name}}</p><p style="margin: 0; font-size: 13px;">Phone: {{org_phone}}</p><p style="margin: 0; font-size: 13px;">Email: {{org_email}}</p><p style="margin: 0; font-size: 13px;">Website: {{org_website}}</p></div></div>',
                    'bg_graphic' => '',
                    'header_graphic' => '',
                    'footer_graphic' => '',
                    'stamp_sign' => ''
                ]
            ],
            'templates' => [
                ['id' => 'enquiry_received', 'name' => 'Enquiry Received', 'subject' => 'We received your enquiry', 'body' => 'Hi {{name}}, we have received your enquiry regarding {{subject}}. We will get back to you soon.'],
                ['id' => 'approval_sent', 'name' => 'Approval Sent', 'subject' => 'Approval: {{approval_no}}', 'body' => 'Please find the attached approval {{approval_no}} for your review.'],
                ['id' => 'approval_accepted', 'name' => 'Approval Accepted', 'subject' => 'Confirmation: Approval {{approval_no}} Accepted', 'body' => 'Hi {{name}}, thank you for accepting approval {{approval_no}}. We will proceed with the next steps.'],
                ['id' => 'approval_rejected', 'name' => 'Approval Rejected', 'subject' => 'Feedback: Approval {{approval_no}}', 'body' => 'Hi {{name}}, we are sorry to hear that you rejected approval {{approval_no}}. Please let us know if there is anything we can improve.'],
                ['id' => 'invoice_sent', 'name' => 'Invoice Sent', 'subject' => 'Invoice: {{invoice_no}}', 'body' => 'Your invoice {{invoice_no}} is ready. Total amount: {{amount}}.'],
                ['id' => 'invoice_cancelled', 'name' => 'Invoice Cancelled', 'subject' => 'Update: Invoice {{invoice_no}} Cancelled', 'body' => 'Hi {{name}}, your invoice {{invoice_no}} has been cancelled.'],
                ['id' => 'payment_received', 'name' => 'Payment Received', 'subject' => 'Payment Confirmation: {{invoice_no}}', 'body' => 'Hi {{name}}, we have received your payment for invoice {{invoice_no}}. Thank you!'],
                ['id' => 'payslip_sent', 'name' => 'Payslip Sent', 'subject' => 'Payslip for {{month}}: {{payslip_no}}', 'body' => 'Hi {{name}}, please find attached your payslip for {{month}}. Net Salary: {{amount}}.'],
            ]
        ];

        if (!$settings) {
            $settings = $defaults;
            $this->repository->insertOne($this->collection, $settings);
        } else {
            // Ensure missing keys are filled (including nested formats)
            $changed = false;
            foreach ($defaults as $key => $value) {
                if (!isset($settings[$key])) {
                    $settings[$key] = $value;
                    $changed = true;
                } elseif (is_array($value) && !empty($value) && isset($value['prefix'])) {
                    // It's a format object, check sub-keys
                    foreach ($value as $subKey => $subValue) {
                        if (!isset($settings[$key][$subKey])) {
                            $settings[$key][$subKey] = $subValue;
                            $changed = true;
                        }
                    }
                }
            }
            if ($changed) {
                $this->repository->updateOne($this->collection, ['id' => 'org_settings'], $settings);
            }
        }
        
        require_once __DIR__ . '/../../views/settings.php';
    }

    public function update() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('settings', 'edit')) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Access Denied']);
            return;
        }

        $raw = file_get_contents('php://input');
        $data = $this->decodeJsonInput($raw);

        if ($data === null) {
            http_response_code(400);
            echo json_encode([
                'status' => 'error',
                'message' => 'Invalid data. Payload might be too large or malformed.',
                'diagnostics' => [
                    'json_error' => json_last_error_msg(),
                    'content_length_header' => $_SERVER['CONTENT_LENGTH'] ?? 'not sent',
                    'received_bytes' => strlen((string)$raw),
                    'post_max_size' => ini_get('post_max_size'),
                    'upload_max_filesize' => ini_get('upload_max_filesize'),
                    'memory_limit' => ini_get('memory_limit'),
                ]
            ]);
            return;
        }

        $success = $this->repository->updateOne($this->collection, ['id' => 'org_settings'], $data);

        if ($success) {
            echo json_encode(['status' => 'success', 'message' => 'Settings updated successfully']);
            return;
        }

        // Write failed - collect detailed diagnostics so the real cause surfaces
        $dirPath = __DIR__ . '/../../storage/db';
        $filePath = $dirPath . '/organization.json';
        $err = error_get_last();
        $freeBytes = function_exists('disk_free_space') ? @disk_free_space($dirPath) : null;
        echo json_encode([
            'status' => 'error',
            'message' => 'Failed to write settings to disk. See diagnostics below.',
            'diagnostics' => [
                'last_error' => $err['message'] ?? null,
                'dir_exists' => is_dir($dirPath),
                'dir_writable' => is_writable($dirPath),
                'file_exists' => file_exists($filePath),
                'file_writable' => is_writable($filePath),
                'disk_free_bytes' => $freeBytes === false ? null : $freeBytes,
                'php_user' => function_exists('posix_getpwuid') && function_exists('posix_geteuid') ? (posix_getpwuid(posix_geteuid())['name'] ?? null) : null,
            ]
        ]);
    }

    /**
     * Decode the JSON request body. Accepts either a plain JSON body or a
     * base64-encoded JSON body (used to bypass ModSecurity false positives
     * triggered by HTML content inside the settings payload on some hosts).
     */
    private function decodeJsonInput(?string $raw = null): ?array {
        if ($raw === null) {
            $raw = file_get_contents('php://input');
        }

        $data = null;
        $decoded = base64_decode($raw, true);
        if ($decoded !== false && $decoded !== '') {
            $data = json_decode($decoded, true);
        }
        if (!is_array($data)) {
            $data = json_decode($raw, true);
        }
        return is_array($data) ? $data : null;
    }

    public function uploadLogo() {
        header('Content-Type: application/json');
        if (!isset($_FILES['logo'])) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'No file']); exit;
        }

        $file = $_FILES['logo'];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $newName = 'logo_' . time() . '.' . $ext;
        $targetDir = __DIR__ . '/../../uploads/';
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $target = $targetDir . $newName;

        // Unlink old logo
        $settings = $this->repository->findOne($this->collection, ['id' => 'org_settings']);
        if (!empty($settings['logo_url'])) {
            $oldPath = __DIR__ . '/../../' . ltrim($settings['logo_url'], '/');
            if (file_exists($oldPath)) unlink($oldPath);
        }

        if (move_uploaded_file($file['tmp_name'], $target)) {
            echo json_encode(['status' => 'success', 'logo_url' => '/uploads/' . $newName]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to move uploaded file']);
        }
    }

    public function uploadAsset() {
        header('Content-Type: application/json');
        // Check for 'asset' or 'logo' key to be flexible
        $fileKey = isset($_FILES['asset']) ? 'asset' : (isset($_FILES['logo']) ? 'logo' : null);
        
        if (!$fileKey) {
            http_response_code(400); echo json_encode(['status' => 'error', 'message' => 'No file']); exit;
        }

        // Optional old_url to unlink
        $oldUrl = $_POST['old_url'] ?? '';
        if (!empty($oldUrl)) {
            $oldPath = __DIR__ . '/../../' . ltrim($oldUrl, '/');
            if (file_exists($oldPath)) unlink($oldPath);
        }

        $file = $_FILES[$fileKey];
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $newName = 'asset_' . time() . '.' . $ext;
        $targetDir = __DIR__ . '/../../uploads/';
        if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
        $target = $targetDir . $newName;

        if (move_uploaded_file($file['tmp_name'], $target)) {
            echo json_encode(['status' => 'success', 'url' => '/uploads/' . $newName]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to move uploaded file']);
        }
    }

    public function getEmailLogs() {
        if (!PermissionHelper::check('settings', 'view')) {
            http_response_code(403); die("Access Denied");
        }

        $logs = $this->repository->findAll('email_logs');
        
        // Sort by timestamp descending
        usort($logs, function($a, $b) {
            return strcmp($b['timestamp'] ?? '', $a['timestamp'] ?? '');
        });

        // Limit to last 500 logs
        $logs = array_slice($logs, 0, 500);

        header('Content-Type: application/json');
        echo json_encode(['logs' => array_values($logs)]);
    }

    public function testSmtp() {
        header('Content-Type: application/json');
        
        // Log request receipt
        file_put_contents(__DIR__ . '/../../smtp_debug.log', "Test SMTP request received at " . date('Y-m-d H:i:s') . "\n", FILE_APPEND);

        if (!PermissionHelper::check('settings', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $data = $this->decodeJsonInput();
        $testEmail = $data['test_email'] ?? '';
        $smtpConfig = $data['smtp'] ?? null;

        if (!$testEmail || !$smtpConfig) {
            file_put_contents(__DIR__ . '/../../smtp_debug.log', "Error: Missing data\n", FILE_APPEND);
            echo json_encode(['status' => 'error', 'message' => 'Test email and SMTP config required']);
            return;
        }

        // Log config
        file_put_contents(__DIR__ . '/../../smtp_debug.log', "Config: " . json_encode($smtpConfig) . "\n", FILE_APPEND);

        // Ensure a fallback from_email exists
        if (empty($smtpConfig['from_email'])) {
            $settings = $this->repository->findOne($this->collection, ['id' => 'org_settings']);
            $smtpConfig['from_email'] = $settings['email'] ?? 'no-reply@crm.com';
        }

        $emailService = new \App\Services\EmailService($smtpConfig);
        $subject = "SMTP Test Connection - " . ($smtpConfig['from_name'] ?? 'iAdmin CRM');
        $body = "<h2>SMTP Connection Successful</h2><p>This is a test email to verify your SMTP settings in iAdmin CRM.</p><p>Sent at: " . date('Y-m-d H:i:s') . "</p>";
        
        $success = $emailService->send($testEmail, $subject, $body);

        file_put_contents(__DIR__ . '/../../smtp_debug.log', "Result: " . ($success ? 'Success' : 'Failed') . "\n\n", FILE_APPEND);

        if ($success) {
            echo json_encode(['status' => 'success', 'message' => 'Test email sent successfully to ' . $testEmail]);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to send test email. Check server logs or SMTP logs.']);
        }
    }

    public function generateSampleData() {
        header('Content-Type: application/json');
        if (!PermissionHelper::check('settings', 'edit')) {
            http_response_code(403); echo json_encode(['status' => 'error', 'message' => 'Access Denied']); exit;
        }

        $clients = [
            ['id' => 'c1', 'client_name' => 'Sample Corp', 'email' => 'contact@samplecorp.com', 'phone' => '9999911111', 'address' => '123 Business Ave', 'city' => 'New York', 'state' => 'NY', 'type' => 'Client', 'created_at' => date('Y-m-d')],
            ['id' => 'c2', 'client_name' => 'Tech Innovators', 'email' => 'hello@techinn.io', 'phone' => '9999922222', 'address' => '456 Startup Blvd', 'city' => 'San Francisco', 'state' => 'CA', 'type' => 'Client', 'created_at' => date('Y-m-d')],
            ['id' => 'c3', 'client_name' => 'Global Logistics', 'email' => 'ops@globallog.com', 'phone' => '9999933333', 'address' => '789 Harbor Dr', 'city' => 'Chicago', 'state' => 'IL', 'type' => 'Client', 'created_at' => date('Y-m-d')],
            ['id' => 'c4', 'client_name' => 'Design Foundry', 'email' => 'art@designfoundry.com', 'phone' => '9999944444', 'address' => '101 Studio Ln', 'city' => 'Austin', 'state' => 'TX', 'type' => 'Client', 'created_at' => date('Y-m-d')],
            ['id' => 'c5', 'client_name' => 'Acme Retail', 'email' => 'support@acmeretail.com', 'phone' => '9999955555', 'address' => '202 Mall Rd', 'city' => 'Seattle', 'state' => 'WA', 'type' => 'Client', 'created_at' => date('Y-m-d')],
        ];

        foreach ($clients as $c) {
            if (!$this->repository->findOne('clients', ['id' => $c['id']])) {
                $this->repository->insertOne('clients', $c);
            }
        }

        $enquiries = [];
        for ($i = 1; $i <= 5; $i++) {
            $enquiries[] = [
                'id' => 'e' . $i,
                'enquiry_no' => 'ENQ-SAMPLE-' . (1000 + $i),
                'client_name' => $clients[$i-1]['client_name'],
                'email' => $clients[$i-1]['email'],
                'phone' => $clients[$i-1]['phone'],
                'subject' => 'Project Inquiry #' . $i,
                'message' => 'This is a sample enquiry message for testing purposes.',
                'status' => 'New',
                'created_at' => date('Y-m-d H:i:s')
            ];
        }
        foreach ($enquiries as $e) {
            if (!$this->repository->findOne('enquiries', ['id' => $e['id']])) {
                $this->repository->insertOne('enquiries', $e);
            }
        }

        $approvals = [];
        for ($i = 1; $i <= 5; $i++) {
            $approvals[] = [
                'id' => 'p' . $i,
                'approval_no' => 'PROP-SAMPLE-' . (2000 + $i),
                'client_id' => $clients[$i-1]['id'],
                'client_name' => $clients[$i-1]['client_name'],
                'subject' => 'Website Development Approval #' . $i,
                'amount' => 5000 * $i,
                'status' => 'Sent',
                'created_at' => date('Y-m-d'),
                'valid_until' => date('Y-m-d', strtotime('+30 days')),
                'items' => [['service' => 'Web Design', 'price' => 2000 * $i], ['service' => 'Development', 'price' => 3000 * $i]]
            ];
        }
        foreach ($approvals as $p) {
            if (!$this->repository->findOne('approvals', ['id' => $p['id']])) {
                $this->repository->insertOne('approvals', $p);
            }
        }

        $invoices = [];
        for ($i = 1; $i <= 5; $i++) {
            $invoices[] = [
                'id' => 'inv' . $i,
                'invoice_no' => 'INV-SAMPLE-' . (3000 + $i),
                'approval_id' => $approvals[$i-1]['id'],
                'client_id' => $clients[$i-1]['id'],
                'client_name' => $clients[$i-1]['client_name'],
                'amount' => 5000 * $i,
                'status' => ($i % 2 === 0) ? 'Paid' : 'Sent',
                'created_at' => date('Y-m-d'),
                'due_date' => date('Y-m-d', strtotime('+15 days')),
                'items' => $approvals[$i-1]['items']
            ];
        }
        foreach ($invoices as $inv) {
            if (!$this->repository->findOne('invoices', ['id' => $inv['id']])) {
                $this->repository->insertOne('invoices', $inv);
            }
        }

        $payments = [];
        for ($i = 1; $i <= 2; $i++) {
            $payments[] = [
                'id' => 'pay' . $i,
                'payment_no' => 'PAY-SAMPLE-' . (4000 + $i),
                'invoice_id' => 'inv' . ($i * 2),
                'client_id' => 'c' . ($i * 2),
                'amount' => 5000 * ($i * 2),
                'method' => 'Bank Transfer',
                'transaction_id' => 'TXN' . rand(100000, 999999),
                'date' => date('Y-m-d'),
                'created_at' => date('Y-m-d H:i:s')
            ];
        }
        foreach ($payments as $pay) {
            if (!$this->repository->findOne('payments', ['id' => $pay['id']])) {
                $this->repository->insertOne('payments', $pay);
            }
        }

        echo json_encode(['status' => 'success', 'message' => '5 Sample records generated for each module.']);
    }
}
