<?php

namespace App\Services;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailService {
    private $config;

    private $repository;

    public function __construct(array $smtpConfig) {
        $this->config = $smtpConfig;
        $this->repository = new \App\Repositories\JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public function send(string $to, string $subject, string $body, string $cc = '', string $attachmentBase64 = '', string $attachmentName = 'document.pdf', string $clientId = null): bool {
        $mail = new PHPMailer(true);
        $status = 'failed';
        $error = '';

        try {
            $mail->isSMTP();
            $mail->Host       = $this->config['host'] ?? '';
            $mail->SMTPAuth   = true;
            $mail->Username   = $this->config['user'] ?? '';
            $mail->Password   = $this->config['pass'] ?? '';
            
            $encryption = $this->config['encryption'] ?? 'tls';
            if ($encryption === 'ssl') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            } elseif ($encryption === 'tls') {
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            } else {
                $mail->SMTPSecure = '';
                $mail->SMTPAutoTLS = false;
            }

            $mail->Port = $this->config['port'] ?? 587;

            $senderEmail = $this->config['from_email'] ?? ($this->config['user'] ?? 'no-reply@crm.com');
            $senderName  = $this->config['from_name'] ?? 'iAdmin CRM';
            
            $mail->setFrom($senderEmail, $senderName);
            $mail->addAddress($to);
            if ($cc) {
                $mail->addCC($cc);
            }

            if ($attachmentBase64) {
                $data = explode(',', $attachmentBase64);
                $content = base64_decode(end($data));
                $mail->addStringAttachment($content, $attachmentName);
            }

            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body    = $body;

            $sent = $mail->send();
            $status = $sent ? 'sent' : 'failed';
            return $sent;
        } catch (Exception $e) {
            $error = $mail->ErrorInfo;
            error_log("Email sending failed. Exception: " . $e->getMessage() . ". PHPMailer Error: {$error}");
            return false;
        } finally {
            $this->repository->insertOne('email_logs', [
                'id' => uniqid('email_'),
                'client_id' => $clientId,
                'recipient' => $to,
                'cc' => $cc,
                'subject' => $subject,
                'status' => $status,
                'error' => $error,
                'timestamp' => date('Y-m-d H:i:s'),
                'user_id' => $_SESSION['user_id'] ?? 'system'
            ]);
        }
    }

    public function renderTemplate(string $template, array $data): string {
        foreach ($data as $key => $value) {
            // Use preg_replace to handle optional whitespace around the key: {{key}}, {{ key }}, etc.
            $template = preg_replace('/\{\{\s*' . preg_quote($key) . '\s*\}\}/', (string)$value, $template);
        }
        return $template;
    }
}
