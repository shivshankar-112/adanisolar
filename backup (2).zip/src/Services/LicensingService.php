<?php

namespace App\Services;

class LicensingService {
    private $licensePath;
    private $secretKey = '8a027522690d6679987e6196f2217a1509dc5280aefa2dcf2460373c144a0f1f';

    public function __construct() {
        $this->licensePath = __DIR__ . '/../../storage/db/license.key';
    }

    public function isValid() {
        if (!file_exists($this->licensePath)) {
            return false;
        }

        $encryptedLicense = file_get_contents($this->licensePath);
        $decryptedData = $this->decrypt($encryptedLicense);

        if (!$decryptedData) {
            return false;
        }

        // Extract hostname from URL or use as-is
        $decryptedDomain = $decryptedData;
        if (filter_var($decryptedData, FILTER_VALIDATE_URL)) {
            $parsed = parse_url($decryptedData);
            $decryptedDomain = $parsed['host'] ?? $decryptedData;
        }

        // Final check: the current host must match the domain stored in the license key
        // (scheme, port and leading www. are ignored).
        $host = $_SERVER['HTTP_HOST'];
        if (false !== $pos = strpos($host, ':')) {
            $host = substr($host, 0, $pos);
        }
        $host = $this->normalizeHost($host);
        return $host === $this->normalizeHost($decryptedDomain);
    }

    private function normalizeHost($host) {
        $host = strtolower(trim($host));
        if (strpos($host, 'www.') === 0) {
            $host = substr($host, 4);
        }
        return $host;
    }

    private function decrypt($data) {
        // Simple decryption logic using the secret key
        $key = substr(hash('sha256', $this->secretKey), 0, 32);
        $decoded = base64_decode($data);
        if (!$decoded) return false;
        
        $iv = substr($decoded, 0, 16);
        $encrypted = substr($decoded, 16);
        
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }
}
