<?php

namespace App\Services;

use App\Repositories\JsonNoSqlRepository;

class AuditLogger {
    private static $instance = null;
    private $repository;

    private function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function log(string $action, string $collection, $id, array $oldData = null, array $newData = null) {
        if ($collection === 'audit_logs') {
            return;
        }

        $logEntry = [
            'id' => uniqid('log_'),
            'timestamp' => date('Y-m-d H:i:s'),
            'user_id' => $_SESSION['user_id'] ?? 'system',
            'username' => $_SESSION['username'] ?? 'system',
            'action' => $action,
            'collection' => $collection,
            'record_id' => $id,
            'old_data' => $this->sanitizeData($oldData),
            'new_data' => $this->sanitizeData($newData),
            'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
        ];

        $this->repository->insertOne('audit_logs', $logEntry);
    }

    private function sanitizeData(?array $data): ?array {
        if ($data === null) return null;
        
        $sensitiveFields = ['password', 'token', 'secret'];
        foreach ($sensitiveFields as $field) {
            if (isset($data[$field])) {
                $data[$field] = '********';
            }
        }
        return $data;
    }
}
