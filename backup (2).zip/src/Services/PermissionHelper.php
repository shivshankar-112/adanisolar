<?php

namespace App\Services;

class PermissionHelper {
    public static function can(string $module, string $action): string {
        // Fallback logic for renaming transition (payments <-> payslips, proposals <-> approvals)
        if (!isset($_SESSION['permissions'][$module][$action])) {
            if ($module === 'payments' && isset($_SESSION['permissions']['payslips'][$action])) {
                return $_SESSION['permissions']['payslips'][$action];
            }
            if ($module === 'payslips' && isset($_SESSION['permissions']['payments'][$action])) {
                return $_SESSION['permissions']['payments'][$action];
            }
            if ($module === 'approvals' && isset($_SESSION['permissions']['proposals'][$action])) {
                return $_SESSION['permissions']['proposals'][$action];
            }
            if ($module === 'proposals' && isset($_SESSION['permissions']['approvals'][$action])) {
                return $_SESSION['permissions']['approvals'][$action];
            }
            return 'none';
        }
        return $_SESSION['permissions'][$module][$action];
    }

    public static function check(string $module, string $action): bool {
        return self::can($module, $action) !== 'none';
    }

    public static function isGlobal(string $module, string $action): bool {
        return self::can($module, $action) === 'global';
    }

    public static function isOwn(string $module, string $action): bool {
        return self::can($module, $action) === 'own';
    }

    public static function filterByOwnership(array $items, string $module, string $action, string $ownerField = 'created_by'): array {
        $perm = self::can($module, $action);
        if ($perm === 'global') return $items;
        
        $userId = $_SESSION['user_id'] ?? null;
        $roleId = $_SESSION['role_id'] ?? null;

        return array_filter($items, function($item) use ($perm, $ownerField, $userId, $roleId) {
            // Check ownership if 'own'
            if ($perm === 'own' && isset($item[$ownerField]) && $item[$ownerField] === $userId) {
                return true;
            }
            
            // Check assignment (Always allow if assigned to user or their role)
            if (isset($item['assigned_to'])) {
                if ($userId && $item['assigned_to'] === $userId) return true;
                if ($roleId && $item['assigned_to'] === $roleId) return true;
            }
            
            return false;
        });
    }

    public static function canAccessRecord(array $record, string $module, string $action, string $ownerField = 'created_by'): bool {
        $perm = self::can($module, $action);
        if ($perm === 'global') return true;
        
        $userId = $_SESSION['user_id'] ?? null;
        $roleId = $_SESSION['role_id'] ?? null;

        if ($perm === 'own' && isset($record[$ownerField]) && $record[$ownerField] === $userId) {
            return true;
        }

        if (isset($record['assigned_to'])) {
            if ($userId && $record['assigned_to'] === $userId) return true;
            if ($roleId && $record['assigned_to'] === $roleId) return true;
        }

        return false;
    }
}
