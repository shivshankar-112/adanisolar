<?php

namespace App\Services;

use App\Repositories\JsonNoSqlRepository;

class NotificationService {
    private static $instance = null;
    private $repository;

    private function __construct() {
        $this->repository = new JsonNoSqlRepository(__DIR__ . '/../../storage/db');
    }

    public static function getInstance(): self {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function notify(string $userId, string $title, string $message, string $type = 'info', string $link = '#') {
        $notification = [
            'id' => uniqid('notif_'),
            'user_id' => $userId, // 'admin', 'all', or specific ID
            'title' => $title,
            'message' => $message,
            'type' => $type, // info, success, warning, error
            'link' => $link,
            'is_read' => false,
            'created_at' => date('Y-m-d H:i:s')
        ];

        $this->repository->insertOne('notifications', $notification);
    }

    public function notifyAdmins(string $title, string $message, string $type = 'info', string $link = '#') {
        $this->notify('admin', $title, $message, $type, $link);
    }

    public function getUnreadCount(string $userId): int {
        $notifications = $this->repository->findAll('notifications', ['is_read' => false]);
        return count(array_filter($notifications, function($n) use ($userId) {
            return $n['user_id'] === $userId || $n['user_id'] === 'admin' || $n['user_id'] === 'all';
        }));
    }

    public function getNotifications(string $userId, int $limit = 50): array {
        $notifications = $this->repository->findAll('notifications', [], [
            'sort' => ['key' => 'created_at', 'order' => 'desc'],
            'limit' => $limit
        ]);
        
        return array_filter($notifications, function($n) use ($userId) {
            return $n['user_id'] === $userId || $n['user_id'] === 'admin' || $n['user_id'] === 'all';
        });
    }

    public function markAsRead(string $id) {
        $this->repository->updateOne('notifications', ['id' => $id], ['is_read' => true]);
    }
}
